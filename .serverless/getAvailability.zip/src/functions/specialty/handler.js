var __create = Object.create;
var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, copyDefault, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && (copyDefault || key !== "default"))
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toESM = (module2, isNodeMode) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", !isNodeMode && module2 && module2.__esModule ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
var __toCommonJS = /* @__PURE__ */ ((cache) => {
  return (module2, temp) => {
    return cache && cache.get(module2) || (temp = __reExport(__markAsModule({}), module2, 1), cache && cache.set(module2, temp), temp);
  };
})(typeof WeakMap !== "undefined" ? /* @__PURE__ */ new WeakMap() : 0);
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result)
    __defProp(target, key, result);
  return result;
};

// node_modules/@middy/core/index.js
var require_core = __commonJS({
  "node_modules/@middy/core/index.js"(exports, module2) {
    "use strict";
    var middy2 = (baseHandler = () => {
    }, plugin) => {
      var _plugin$beforePrefetc;
      plugin === null || plugin === void 0 ? void 0 : (_plugin$beforePrefetc = plugin.beforePrefetch) === null || _plugin$beforePrefetc === void 0 ? void 0 : _plugin$beforePrefetc.call(plugin);
      const beforeMiddlewares = [];
      const afterMiddlewares = [];
      const onErrorMiddlewares = [];
      const instance = (event = {}, context = {}) => {
        var _plugin$requestStart;
        plugin === null || plugin === void 0 ? void 0 : (_plugin$requestStart = plugin.requestStart) === null || _plugin$requestStart === void 0 ? void 0 : _plugin$requestStart.call(plugin);
        const request = {
          event,
          context,
          response: void 0,
          error: void 0,
          internal: {}
        };
        return runRequest(request, [...beforeMiddlewares], baseHandler, [...afterMiddlewares], [...onErrorMiddlewares], plugin);
      };
      instance.use = (middlewares) => {
        if (Array.isArray(middlewares)) {
          for (const middleware of middlewares) {
            instance.applyMiddleware(middleware);
          }
          return instance;
        }
        return instance.applyMiddleware(middlewares);
      };
      instance.applyMiddleware = (middleware) => {
        const {
          before,
          after,
          onError
        } = middleware;
        if (!before && !after && !onError) {
          throw new Error('Middleware must be an object containing at least one key among "before", "after", "onError"');
        }
        if (before)
          instance.before(before);
        if (after)
          instance.after(after);
        if (onError)
          instance.onError(onError);
        return instance;
      };
      instance.before = (beforeMiddleware) => {
        beforeMiddlewares.push(beforeMiddleware);
        return instance;
      };
      instance.after = (afterMiddleware) => {
        afterMiddlewares.unshift(afterMiddleware);
        return instance;
      };
      instance.onError = (onErrorMiddleware) => {
        onErrorMiddlewares.push(onErrorMiddleware);
        return instance;
      };
      instance.__middlewares = {
        before: beforeMiddlewares,
        after: afterMiddlewares,
        onError: onErrorMiddlewares
      };
      return instance;
    };
    var runRequest = async (request, beforeMiddlewares, baseHandler, afterMiddlewares, onErrorMiddlewares, plugin) => {
      try {
        await runMiddlewares(request, beforeMiddlewares, plugin);
        if (request.response === void 0) {
          var _plugin$beforeHandler, _plugin$afterHandler;
          plugin === null || plugin === void 0 ? void 0 : (_plugin$beforeHandler = plugin.beforeHandler) === null || _plugin$beforeHandler === void 0 ? void 0 : _plugin$beforeHandler.call(plugin);
          request.response = await baseHandler(request.event, request.context);
          plugin === null || plugin === void 0 ? void 0 : (_plugin$afterHandler = plugin.afterHandler) === null || _plugin$afterHandler === void 0 ? void 0 : _plugin$afterHandler.call(plugin);
          await runMiddlewares(request, afterMiddlewares, plugin);
        }
      } catch (e) {
        request.response = void 0;
        request.error = e;
        try {
          await runMiddlewares(request, onErrorMiddlewares, plugin);
        } catch (e2) {
          e2.originalError = request.error;
          request.error = e2;
          throw request.error;
        }
        if (request.response === void 0)
          throw request.error;
      } finally {
        var _plugin$requestEnd;
        await (plugin === null || plugin === void 0 ? void 0 : (_plugin$requestEnd = plugin.requestEnd) === null || _plugin$requestEnd === void 0 ? void 0 : _plugin$requestEnd.call(plugin, request));
      }
      return request.response;
    };
    var runMiddlewares = async (request, middlewares, plugin) => {
      for (const nextMiddleware of middlewares) {
        var _plugin$beforeMiddlew, _plugin$afterMiddlewa;
        plugin === null || plugin === void 0 ? void 0 : (_plugin$beforeMiddlew = plugin.beforeMiddleware) === null || _plugin$beforeMiddlew === void 0 ? void 0 : _plugin$beforeMiddlew.call(plugin, nextMiddleware === null || nextMiddleware === void 0 ? void 0 : nextMiddleware.name);
        const res = await (nextMiddleware === null || nextMiddleware === void 0 ? void 0 : nextMiddleware(request));
        plugin === null || plugin === void 0 ? void 0 : (_plugin$afterMiddlewa = plugin.afterMiddleware) === null || _plugin$afterMiddlewa === void 0 ? void 0 : _plugin$afterMiddlewa.call(plugin, nextMiddleware === null || nextMiddleware === void 0 ? void 0 : nextMiddleware.name);
        if (res !== void 0) {
          request.response = res;
          return;
        }
      }
    };
    module2.exports = middy2;
  }
});

// node_modules/@middy/util/codes.json
var require_codes = __commonJS({
  "node_modules/@middy/util/codes.json"(exports, module2) {
    module2.exports = {
      "100": "Continue",
      "101": "Switching Protocols",
      "102": "Processing",
      "103": "Early Hints",
      "200": "OK",
      "201": "Created",
      "202": "Accepted",
      "203": "Non-Authoritative Information",
      "204": "No Content",
      "205": "Reset Content",
      "206": "Partial Content",
      "207": "Multi-Status",
      "208": "Already Reported",
      "226": "IM Used",
      "300": "Multiple Choices",
      "301": "Moved Permanently",
      "302": "Found",
      "303": "See Other",
      "304": "Not Modified",
      "305": "Use Proxy",
      "306": "(Unused)",
      "307": "Temporary Redirect",
      "308": "Permanent Redirect",
      "400": "Bad Request",
      "401": "Unauthorized",
      "402": "Payment Required",
      "403": "Forbidden",
      "404": "Not Found",
      "405": "Method Not Allowed",
      "406": "Not Acceptable",
      "407": "Proxy Authentication Required",
      "408": "Request Timeout",
      "409": "Conflict",
      "410": "Gone",
      "411": "Length Required",
      "412": "Precondition Failed",
      "413": "Payload Too Large",
      "414": "URI Too Long",
      "415": "Unsupported Media Type",
      "416": "Range Not Satisfiable",
      "417": "Expectation Failed",
      "418": "I'm a teapot",
      "421": "Misdirected Request",
      "422": "Unprocessable Entity",
      "423": "Locked",
      "424": "Failed Dependency",
      "425": "Unordered Collection",
      "426": "Upgrade Required",
      "428": "Precondition Required",
      "429": "Too Many Requests",
      "431": "Request Header Fields Too Large",
      "451": "Unavailable For Legal Reasons",
      "500": "Internal Server Error",
      "501": "Not Implemented",
      "502": "Bad Gateway",
      "503": "Service Unavailable",
      "504": "Gateway Timeout",
      "505": "HTTP Version Not Supported",
      "506": "Variant Also Negotiates",
      "507": "Insufficient Storage",
      "508": "Loop Detected",
      "509": "Bandwidth Limit Exceeded",
      "510": "Not Extended",
      "511": "Network Authentication Required"
    };
  }
});

// node_modules/@middy/util/index.js
var require_util = __commonJS({
  "node_modules/@middy/util/index.js"(exports, module2) {
    "use strict";
    var {
      Agent
    } = require("https");
    var awsClientDefaultOptions = {
      httpOptions: {
        agent: new Agent({
          secureProtocol: "TLSv1_2_method"
        })
      }
    };
    var createPrefetchClient = (options) => {
      const awsClientOptions = __spreadValues(__spreadValues({}, awsClientDefaultOptions), options.awsClientOptions);
      const client = new options.AwsClient(awsClientOptions);
      if (options.awsClientCapture) {
        return options.awsClientCapture(client);
      }
      return client;
    };
    var createClient = async (options, request) => {
      let awsClientCredentials = {};
      if (options.awsClientAssumeRole) {
        if (!request)
          throw new Error("Request required when assuming role");
        awsClientCredentials = await getInternal({
          credentials: options.awsClientAssumeRole
        }, request);
      }
      awsClientCredentials = __spreadValues(__spreadValues({}, awsClientCredentials), options.awsClientOptions);
      return createPrefetchClient(__spreadProps(__spreadValues({}, options), {
        awsClientOptions: awsClientCredentials
      }));
    };
    var canPrefetch = (options) => {
      return !(options !== null && options !== void 0 && options.awsClientAssumeRole) && !(options !== null && options !== void 0 && options.disablePrefetch);
    };
    var getInternal = async (variables, request) => {
      if (!variables || !request)
        return {};
      let keys = [];
      let values = [];
      if (variables === true) {
        keys = values = Object.keys(request.internal);
      } else if (typeof variables === "string") {
        keys = values = [variables];
      } else if (Array.isArray(variables)) {
        keys = values = variables;
      } else if (typeof variables === "object") {
        keys = Object.keys(variables);
        values = Object.values(variables);
      }
      const promises = [];
      for (const internalKey of values) {
        var _valuePromise;
        const pathOptionKey = internalKey.split(".");
        const rootOptionKey = pathOptionKey.shift();
        let valuePromise = request.internal[rootOptionKey];
        if (typeof ((_valuePromise = valuePromise) === null || _valuePromise === void 0 ? void 0 : _valuePromise.then) !== "function") {
          valuePromise = Promise.resolve(valuePromise);
        }
        promises.push(valuePromise.then((value) => pathOptionKey.reduce((p, c) => p === null || p === void 0 ? void 0 : p[c], value)));
      }
      values = await Promise.allSettled(promises);
      const errors = values.filter((res) => res.status === "rejected").map((res) => res.reason.message);
      if (errors.length)
        throw new Error(JSON.stringify(errors));
      return keys.reduce((obj, key, index) => __spreadProps(__spreadValues({}, obj), {
        [sanitizeKey(key)]: values[index].value
      }), {});
    };
    var sanitizeKeyPrefixLeadingNumber = /^([0-9])/;
    var sanitizeKeyRemoveDisallowedChar = /[^a-zA-Z0-9]+/g;
    var sanitizeKey = (key) => {
      return key.replace(sanitizeKeyPrefixLeadingNumber, "_$1").replace(sanitizeKeyRemoveDisallowedChar, "_");
    };
    var cache = {};
    var processCache = (options, fetch = () => void 0, request) => {
      const {
        cacheExpiry,
        cacheKey
      } = options;
      if (cacheExpiry) {
        const cached = getCache(cacheKey);
        const unexpired = cached && (cacheExpiry < 0 || cached.expiry > Date.now());
        if (unexpired && cached.modified) {
          const value2 = fetch(request, cached.value);
          cache[cacheKey] = {
            value: __spreadValues(__spreadValues({}, cached.value), value2),
            expiry: cached.expiry
          };
          return cache[cacheKey];
        }
        if (unexpired) {
          return __spreadProps(__spreadValues({}, cached), {
            cache: true
          });
        }
      }
      const value = fetch(request);
      const expiry = Date.now() + cacheExpiry;
      if (cacheExpiry) {
        cache[cacheKey] = {
          value,
          expiry
        };
      }
      return {
        value,
        expiry
      };
    };
    var getCache = (key) => {
      return cache[key];
    };
    var modifyCache = (cacheKey, value) => {
      if (!cache[cacheKey])
        return;
      cache[cacheKey] = __spreadProps(__spreadValues({}, cache[cacheKey]), {
        value,
        modified: true
      });
    };
    var clearCache = (keys = null) => {
      var _keys;
      keys = (_keys = keys) !== null && _keys !== void 0 ? _keys : Object.keys(cache);
      if (!Array.isArray(keys))
        keys = [keys];
      for (const cacheKey of keys) {
        cache[cacheKey] = void 0;
      }
    };
    var jsonSafeParse = (string, reviver) => {
      if (typeof string !== "string")
        return string;
      const firstChar = string[0];
      if (firstChar !== "{" && firstChar !== "[" && firstChar !== '"')
        return string;
      try {
        return JSON.parse(string, reviver);
      } catch (e) {
      }
      return string;
    };
    var normalizeHttpResponse = (response) => {
      var _response$headers, _response;
      if (response === void 0) {
        response = {};
      } else if (Array.isArray(response) || typeof response !== "object" || response === null) {
        response = {
          body: response
        };
      }
      response.headers = (_response$headers = (_response = response) === null || _response === void 0 ? void 0 : _response.headers) !== null && _response$headers !== void 0 ? _response$headers : {};
      return response;
    };
    var statuses = require_codes();
    var {
      inherits
    } = require("util");
    var createErrorRegexp = /[^a-zA-Z]/g;
    var createError = (code, message, properties = {}) => {
      const name = statuses[code].replace(createErrorRegexp, "");
      const className = name.substr(-5) !== "Error" ? name + "Error" : name;
      function HttpError(message2) {
        const msg = message2 !== null && message2 !== void 0 ? message2 : statuses[code];
        const err = new Error(msg);
        Error.captureStackTrace(err, HttpError);
        Object.setPrototypeOf(err, HttpError.prototype);
        Object.defineProperty(err, "message", {
          enumerable: true,
          configurable: true,
          value: msg,
          writable: true
        });
        Object.defineProperty(err, "name", {
          enumerable: false,
          configurable: true,
          value: className,
          writable: true
        });
        return err;
      }
      inherits(HttpError, Error);
      const desc = Object.getOwnPropertyDescriptor(HttpError, "name");
      desc.value = className;
      Object.defineProperty(HttpError, "name", desc);
      Object.assign(HttpError.prototype, {
        status: code,
        statusCode: code,
        expose: code < 500
      }, properties);
      return new HttpError(message);
    };
    module2.exports = {
      createPrefetchClient,
      createClient,
      canPrefetch,
      getInternal,
      sanitizeKey,
      processCache,
      getCache,
      modifyCache,
      clearCache,
      jsonSafeParse,
      normalizeHttpResponse,
      createError
    };
  }
});

// node_modules/@middy/http-json-body-parser/index.js
var require_http_json_body_parser = __commonJS({
  "node_modules/@middy/http-json-body-parser/index.js"(exports, module2) {
    "use strict";
    var mimePattern = /^application\/(.+\+)?json(;.*)?$/;
    var defaults = {
      reviver: void 0
    };
    var httpJsonBodyParserMiddleware = (opts = {}) => {
      const options = __spreadValues(__spreadValues({}, defaults), opts);
      const httpJsonBodyParserMiddlewareBefore = async (request) => {
        var _headers$ContentType;
        const {
          headers,
          body
        } = request.event;
        const contentTypeHeader = (_headers$ContentType = headers === null || headers === void 0 ? void 0 : headers["Content-Type"]) !== null && _headers$ContentType !== void 0 ? _headers$ContentType : headers === null || headers === void 0 ? void 0 : headers["content-type"];
        if (mimePattern.test(contentTypeHeader)) {
          try {
            const data = request.event.isBase64Encoded ? Buffer.from(body, "base64").toString() : body;
            request.event.rawBody = body;
            request.event.body = JSON.parse(data, options.reviver);
          } catch (err) {
            const {
              createError
            } = require_util();
            throw createError(422, "Content type defined as JSON but an invalid JSON was provided");
          }
        }
      };
      return {
        before: httpJsonBodyParserMiddlewareBefore
      };
    };
    module2.exports = httpJsonBodyParserMiddleware;
  }
});

// node_modules/tslib/tslib.js
var require_tslib = __commonJS({
  "node_modules/tslib/tslib.js"(exports, module2) {
    var __extends;
    var __assign;
    var __rest;
    var __decorate;
    var __param;
    var __metadata;
    var __awaiter;
    var __generator;
    var __exportStar;
    var __values;
    var __read;
    var __spread;
    var __spreadArrays;
    var __await;
    var __asyncGenerator;
    var __asyncDelegator;
    var __asyncValues;
    var __makeTemplateObject;
    var __importStar;
    var __importDefault;
    var __classPrivateFieldGet;
    var __classPrivateFieldSet;
    var __createBinding;
    (function(factory) {
      var root = typeof global === "object" ? global : typeof self === "object" ? self : typeof this === "object" ? this : {};
      if (typeof define === "function" && define.amd) {
        define("tslib", ["exports"], function(exports2) {
          factory(createExporter(root, createExporter(exports2)));
        });
      } else if (typeof module2 === "object" && typeof module2.exports === "object") {
        factory(createExporter(root, createExporter(module2.exports)));
      } else {
        factory(createExporter(root));
      }
      function createExporter(exports2, previous) {
        if (exports2 !== root) {
          if (typeof Object.create === "function") {
            Object.defineProperty(exports2, "__esModule", { value: true });
          } else {
            exports2.__esModule = true;
          }
        }
        return function(id, v) {
          return exports2[id] = previous ? previous(id, v) : v;
        };
      }
    })(function(exporter) {
      var extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
        d.__proto__ = b;
      } || function(d, b) {
        for (var p in b)
          if (b.hasOwnProperty(p))
            d[p] = b[p];
      };
      __extends = function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p))
              t[p] = s[p];
        }
        return t;
      };
      __rest = function(s, e) {
        var t = {};
        for (var p in s)
          if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
          for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
              t[p[i]] = s[p[i]];
          }
        return t;
      };
      __decorate = function(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
          r = Reflect.decorate(decorators, target, key, desc);
        else
          for (var i = decorators.length - 1; i >= 0; i--)
            if (d = decorators[i])
              r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
      };
      __param = function(paramIndex, decorator) {
        return function(target, key) {
          decorator(target, key, paramIndex);
        };
      };
      __metadata = function(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
          return Reflect.metadata(metadataKey, metadataValue);
      };
      __awaiter = function(thisArg, _arguments, P, generator) {
        function adopt(value) {
          return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
          });
        }
        return new (P || (P = Promise))(function(resolve, reject) {
          function fulfilled(value) {
            try {
              step(generator.next(value));
            } catch (e) {
              reject(e);
            }
          }
          function rejected(value) {
            try {
              step(generator["throw"](value));
            } catch (e) {
              reject(e);
            }
          }
          function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
          }
          step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
      };
      __generator = function(thisArg, body) {
        var _ = { label: 0, sent: function() {
          if (t[0] & 1)
            throw t[1];
          return t[1];
        }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
          return this;
        }), g;
        function verb(n) {
          return function(v) {
            return step([n, v]);
          };
        }
        function step(op) {
          if (f)
            throw new TypeError("Generator is already executing.");
          while (_)
            try {
              if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                return t;
              if (y = 0, t)
                op = [op[0] & 2, t.value];
              switch (op[0]) {
                case 0:
                case 1:
                  t = op;
                  break;
                case 4:
                  _.label++;
                  return { value: op[1], done: false };
                case 5:
                  _.label++;
                  y = op[1];
                  op = [0];
                  continue;
                case 7:
                  op = _.ops.pop();
                  _.trys.pop();
                  continue;
                default:
                  if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                    _ = 0;
                    continue;
                  }
                  if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                    _.label = op[1];
                    break;
                  }
                  if (op[0] === 6 && _.label < t[1]) {
                    _.label = t[1];
                    t = op;
                    break;
                  }
                  if (t && _.label < t[2]) {
                    _.label = t[2];
                    _.ops.push(op);
                    break;
                  }
                  if (t[2])
                    _.ops.pop();
                  _.trys.pop();
                  continue;
              }
              op = body.call(thisArg, _);
            } catch (e) {
              op = [6, e];
              y = 0;
            } finally {
              f = t = 0;
            }
          if (op[0] & 5)
            throw op[1];
          return { value: op[0] ? op[1] : void 0, done: true };
        }
      };
      __createBinding = function(o, m, k, k2) {
        if (k2 === void 0)
          k2 = k;
        o[k2] = m[k];
      };
      __exportStar = function(m, exports2) {
        for (var p in m)
          if (p !== "default" && !exports2.hasOwnProperty(p))
            exports2[p] = m[p];
      };
      __values = function(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
          return m.call(o);
        if (o && typeof o.length === "number")
          return {
            next: function() {
              if (o && i >= o.length)
                o = void 0;
              return { value: o && o[i++], done: !o };
            }
          };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
      };
      __read = function(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
          return o;
        var i = m.call(o), r, ar = [], e;
        try {
          while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
            ar.push(r.value);
        } catch (error) {
          e = { error };
        } finally {
          try {
            if (r && !r.done && (m = i["return"]))
              m.call(i);
          } finally {
            if (e)
              throw e.error;
          }
        }
        return ar;
      };
      __spread = function() {
        for (var ar = [], i = 0; i < arguments.length; i++)
          ar = ar.concat(__read(arguments[i]));
        return ar;
      };
      __spreadArrays = function() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
          s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
          for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
        return r;
      };
      __await = function(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
      };
      __asyncGenerator = function(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
          throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
          return this;
        }, i;
        function verb(n) {
          if (g[n])
            i[n] = function(v) {
              return new Promise(function(a, b) {
                q.push([n, v, a, b]) > 1 || resume(n, v);
              });
            };
        }
        function resume(n, v) {
          try {
            step(g[n](v));
          } catch (e) {
            settle(q[0][3], e);
          }
        }
        function step(r) {
          r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
        }
        function fulfill(value) {
          resume("next", value);
        }
        function reject(value) {
          resume("throw", value);
        }
        function settle(f, v) {
          if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]);
        }
      };
      __asyncDelegator = function(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function(e) {
          throw e;
        }), verb("return"), i[Symbol.iterator] = function() {
          return this;
        }, i;
        function verb(n, f) {
          i[n] = o[n] ? function(v) {
            return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v;
          } : f;
        }
      };
      __asyncValues = function(o) {
        if (!Symbol.asyncIterator)
          throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
          return this;
        }, i);
        function verb(n) {
          i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
              v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
          };
        }
        function settle(resolve, reject, d, v) {
          Promise.resolve(v).then(function(v2) {
            resolve({ value: v2, done: d });
          }, reject);
        }
      };
      __makeTemplateObject = function(cooked, raw) {
        if (Object.defineProperty) {
          Object.defineProperty(cooked, "raw", { value: raw });
        } else {
          cooked.raw = raw;
        }
        return cooked;
      };
      __importStar = function(mod) {
        if (mod && mod.__esModule)
          return mod;
        var result = {};
        if (mod != null) {
          for (var k in mod)
            if (Object.hasOwnProperty.call(mod, k))
              result[k] = mod[k];
        }
        result["default"] = mod;
        return result;
      };
      __importDefault = function(mod) {
        return mod && mod.__esModule ? mod : { "default": mod };
      };
      __classPrivateFieldGet = function(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
          throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
      };
      __classPrivateFieldSet = function(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
          throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
      };
      exporter("__extends", __extends);
      exporter("__assign", __assign);
      exporter("__rest", __rest);
      exporter("__decorate", __decorate);
      exporter("__param", __param);
      exporter("__metadata", __metadata);
      exporter("__awaiter", __awaiter);
      exporter("__generator", __generator);
      exporter("__exportStar", __exportStar);
      exporter("__createBinding", __createBinding);
      exporter("__values", __values);
      exporter("__read", __read);
      exporter("__spread", __spread);
      exporter("__spreadArrays", __spreadArrays);
      exporter("__await", __await);
      exporter("__asyncGenerator", __asyncGenerator);
      exporter("__asyncDelegator", __asyncDelegator);
      exporter("__asyncValues", __asyncValues);
      exporter("__makeTemplateObject", __makeTemplateObject);
      exporter("__importStar", __importStar);
      exporter("__importDefault", __importDefault);
      exporter("__classPrivateFieldGet", __classPrivateFieldGet);
      exporter("__classPrivateFieldSet", __classPrivateFieldSet);
    });
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/constants.js
var require_constants = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/constants.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.VERSION = "0.4.0";
    exports.MAX_WRITE_BATCH_SIZE = 25;
    exports.MAX_READ_BATCH_SIZE = 100;
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/ItemNotFoundException.js
var require_ItemNotFoundException = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/ItemNotFoundException.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var ItemNotFoundException = function(_super) {
      tslib_1.__extends(ItemNotFoundException2, _super);
      function ItemNotFoundException2(itemSought, message) {
        if (message === void 0) {
          message = defaultErrorMessage(itemSought);
        }
        var _this = _super.call(this, message) || this;
        _this.itemSought = itemSought;
        _this.name = "ItemNotFoundException";
        return _this;
      }
      return ItemNotFoundException2;
    }(Error);
    exports.ItemNotFoundException = ItemNotFoundException;
    function defaultErrorMessage(itemSought) {
      return "No item with the key " + JSON.stringify(itemSought.Key) + " found in the " + itemSought.TableName + " table.";
    }
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/asyncIteratorSymbolPolyfill.js
var require_asyncIteratorSymbolPolyfill = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/asyncIteratorSymbolPolyfill.js"() {
    "use strict";
    if (Symbol && !Symbol.asyncIterator) {
      Symbol.asyncIterator = Symbol.for("__@@asyncIterator__");
    }
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/Iterator.js
var require_Iterator = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/Iterator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    require_asyncIteratorSymbolPolyfill();
    var Iterator = function() {
      function Iterator2(paginator) {
        this.paginator = paginator;
        this._count = 0;
        this.lastResolved = Promise.resolve();
        this.pending = [];
      }
      Iterator2.prototype[Symbol.asyncIterator] = function() {
        return this;
      };
      Iterator2.prototype.next = function() {
        var _this = this;
        this.lastResolved = this.lastResolved.then(function() {
          return _this.getNext();
        });
        return this.lastResolved;
      };
      Iterator2.prototype.pages = function() {
        this.lastResolved = Promise.reject(new Error("The underlying paginator has been detached from this iterator."));
        this.lastResolved.catch(function() {
        });
        return this.paginator;
      };
      Iterator2.prototype.return = function() {
        this.lastResolved = Promise.reject(new Error("Iteration has been manually interrupted and may not be resumed"));
        this.lastResolved.catch(function() {
        });
        this.pending.length = 0;
        return this.paginator.return();
      };
      Object.defineProperty(Iterator2.prototype, "consumedCapacity", {
        get: function() {
          return this.paginator.consumedCapacity;
        },
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(Iterator2.prototype, "count", {
        get: function() {
          return this._count;
        },
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(Iterator2.prototype, "scannedCount", {
        get: function() {
          return this.paginator.scannedCount;
        },
        enumerable: true,
        configurable: true
      });
      Iterator2.prototype.getNext = function() {
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var _this = this;
          return tslib_1.__generator(this, function(_a) {
            if (this.pending.length > 0) {
              this.lastYielded = this.pending.shift();
              this._count++;
              return [2, {
                done: false,
                value: this.lastYielded
              }];
            }
            return [2, this.paginator.next().then(function(_a2) {
              var _b = _a2.value, value = _b === void 0 ? [] : _b, done = _a2.done;
              var _c;
              if (!done) {
                (_c = _this.pending).push.apply(_c, tslib_1.__spread(value));
                return _this.getNext();
              }
              _this.lastYielded = void 0;
              return { done: true };
            })];
          });
        });
      };
      return Iterator2;
    }();
    exports.Iterator = Iterator;
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/InvalidSchemaError.js
var require_InvalidSchemaError = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/InvalidSchemaError.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var InvalidSchemaError = function(_super) {
      tslib_1.__extends(InvalidSchemaError2, _super);
      function InvalidSchemaError2(node, message) {
        var _this = _super.call(this, message) || this;
        _this.node = node;
        return _this;
      }
      return InvalidSchemaError2;
    }(Error);
    exports.InvalidSchemaError = InvalidSchemaError;
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/InvalidValueError.js
var require_InvalidValueError = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/InvalidValueError.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var InvalidValueError = function(_super) {
      tslib_1.__extends(InvalidValueError2, _super);
      function InvalidValueError2(invalidValue, message) {
        var _this = _super.call(this, message) || this;
        _this.invalidValue = invalidValue;
        return _this;
      }
      return InvalidValueError2;
    }(Error);
    exports.InvalidValueError = InvalidValueError;
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/isKey.js
var require_isKey = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/isKey.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function isKey(fieldSchema, indexName) {
      if (fieldSchema.type === "Binary" || fieldSchema.type === "Custom" || fieldSchema.type === "Date" || fieldSchema.type === "Number" || fieldSchema.type === "String") {
        return indexName !== void 0 ? Boolean(fieldSchema.indexKeyConfigurations && fieldSchema.indexKeyConfigurations[indexName]) : Boolean(fieldSchema.keyType);
      }
      return false;
    }
    exports.isKey = isKey;
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/keysFromSchema.js
var require_keysFromSchema = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/keysFromSchema.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    function keysFromSchema(schema) {
      var e_1, _a, e_2, _b;
      var attributes = {};
      var tableKeys = {};
      var indexKeys = {};
      try {
        for (var _c = tslib_1.__values(Object.keys(schema)), _d = _c.next(); !_d.done; _d = _c.next()) {
          var propertyName = _d.value;
          var fieldSchema = schema[propertyName];
          if (fieldSchema.type === "Binary" || fieldSchema.type === "Custom" || fieldSchema.type === "Date" || fieldSchema.type === "Number" || fieldSchema.type === "String") {
            var _e = fieldSchema.attributeName, attributeName = _e === void 0 ? propertyName : _e;
            if (fieldSchema.keyType) {
              attributes[attributeName] = attributeType(fieldSchema);
              tableKeys[attributeName] = fieldSchema.keyType;
            }
            if (fieldSchema.indexKeyConfigurations && Object.keys(fieldSchema.indexKeyConfigurations).length > 0) {
              attributes[attributeName] = attributeType(fieldSchema);
              try {
                for (var _f = tslib_1.__values(Object.keys(fieldSchema.indexKeyConfigurations)), _g = _f.next(); !_g.done; _g = _f.next()) {
                  var indexName = _g.value;
                  if (!(indexName in indexKeys)) {
                    indexKeys[indexName] = {};
                  }
                  indexKeys[indexName][attributeName] = fieldSchema.indexKeyConfigurations[indexName];
                }
              } catch (e_2_1) {
                e_2 = { error: e_2_1 };
              } finally {
                try {
                  if (_g && !_g.done && (_b = _f.return))
                    _b.call(_f);
                } finally {
                  if (e_2)
                    throw e_2.error;
                }
              }
            }
          }
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_d && !_d.done && (_a = _c.return))
            _a.call(_c);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return { attributes, tableKeys, indexKeys };
    }
    exports.keysFromSchema = keysFromSchema;
    function attributeType(fieldSchema) {
      switch (fieldSchema.type) {
        case "Binary":
          return "B";
        case "Custom":
          if (!fieldSchema.attributeType) {
            throw new Error("Invalid schema: no attribute type defined for custom field");
          }
          return fieldSchema.attributeType;
        case "Date":
        case "Number":
          return "N";
        case "String":
          return "S";
      }
    }
  }
});

// node_modules/@aws/dynamodb-expressions/build/AttributePath.js
var require_AttributePath = __commonJS({
  "node_modules/@aws/dynamodb-expressions/build/AttributePath.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var ATTRIBUTE_PATH_TAG = "AmazonDynamoDbAttributePath";
    var EXPECTED_TAG = "[object " + ATTRIBUTE_PATH_TAG + "]";
    var AttributePath = function() {
      function AttributePath2(path) {
        this[Symbol.toStringTag] = ATTRIBUTE_PATH_TAG;
        if (typeof path === "string") {
          this.elements = parsePath(path);
        } else {
          this.elements = tslib_1.__spread(path);
        }
      }
      AttributePath2.isAttributePath = function(arg) {
        return arg instanceof AttributePath2 || Object.prototype.toString.call(arg) === EXPECTED_TAG;
      };
      return AttributePath2;
    }();
    exports.AttributePath = AttributePath;
    var LEFT_BRACKET = "[";
    var RIGHT_BRACKET = "]";
    var PATH_DELIMITER = ".";
    var ESCAPE_CHARACTER = "\\";
    function parsePath(path) {
      var elements = [];
      var state = 1001;
      var collected = "";
      for (var iter = path[Symbol.iterator](), curr = iter.next(), peek = iter.next(); curr.done === false; curr = peek, peek = iter.next()) {
        if (state === 1001) {
          switch (curr.value) {
            case LEFT_BRACKET:
              state = 1002;
            case PATH_DELIMITER:
              if (collected === "") {
                throw new Error("Invalid control character encountered in path: " + path);
              }
              elements.push({ type: "AttributeName", name: collected });
              collected = "";
              break;
            case ESCAPE_CHARACTER:
              if (peek.value === PATH_DELIMITER || peek.value === LEFT_BRACKET || peek.value === ESCAPE_CHARACTER) {
                curr = peek;
                peek = iter.next();
              }
            default:
              collected += curr.value;
          }
        } else if (state === 1002) {
          switch (curr.value) {
            case RIGHT_BRACKET:
              var intVal = parseInt(collected);
              if (!isFinite(intVal)) {
                throw new Error("Invalid array index (" + collected + ") encountered in path: " + path);
              }
              elements.push({ type: "ListIndex", index: intVal });
              collected = "";
              state = 1e3;
              break;
            case "0":
            case "1":
            case "2":
            case "3":
            case "4":
            case "5":
            case "6":
            case "7":
            case "8":
            case "9":
              collected += curr.value;
              break;
            default:
              throw new Error("Invalid array index character (" + curr.value + ") encountered in path: " + path);
          }
        } else {
          switch (curr.value) {
            case LEFT_BRACKET:
              state = 1002;
              break;
            case PATH_DELIMITER:
              state = 1001;
              break;
            default:
              throw new Error("Bare identifier encountered between list index accesses in path: " + path);
          }
        }
      }
      if (collected.length > 0) {
        elements.push({ type: "AttributeName", name: collected });
      }
      return elements;
    }
  }
});

// node_modules/@aws/dynamodb-expressions/build/AttributeValue.js
var require_AttributeValue = __commonJS({
  "node_modules/@aws/dynamodb-expressions/build/AttributeValue.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var MARSHALLED_ATTRIBUTE_VALUE_TAG = "AmazonDynamoDbAttributeValue";
    var EXPECTED_TOSTRING = "[object " + MARSHALLED_ATTRIBUTE_VALUE_TAG + "]";
    var AttributeValue = function() {
      function AttributeValue2(marshalled) {
        this.marshalled = marshalled;
        this[Symbol.toStringTag] = MARSHALLED_ATTRIBUTE_VALUE_TAG;
      }
      AttributeValue2.isAttributeValue = function(arg) {
        return arg instanceof AttributeValue2 || Object.prototype.toString.call(arg) === EXPECTED_TOSTRING;
      };
      return AttributeValue2;
    }();
    exports.AttributeValue = AttributeValue;
  }
});

// node_modules/@aws/dynamodb-expressions/build/FunctionExpression.js
var require_FunctionExpression = __commonJS({
  "node_modules/@aws/dynamodb-expressions/build/FunctionExpression.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var AttributePath_1 = require_AttributePath();
    var FUNCTION_EXPRESSION_TAG = "AmazonDynamoDbFunctionExpression";
    var EXPECTED_TOSTRING = "[object " + FUNCTION_EXPRESSION_TAG + "]";
    var FunctionExpression = function() {
      function FunctionExpression2(name) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
          args[_i - 1] = arguments[_i];
        }
        this.name = name;
        this[Symbol.toStringTag] = FUNCTION_EXPRESSION_TAG;
        this.args = args;
      }
      FunctionExpression2.prototype.serialize = function(attributes) {
        var expressionSafeArgs = this.args.map(function(arg) {
          return AttributePath_1.AttributePath.isAttributePath(arg) ? attributes.addName(arg) : attributes.addValue(arg);
        });
        return this.name + "(" + expressionSafeArgs.join(", ") + ")";
      };
      FunctionExpression2.isFunctionExpression = function(arg) {
        return arg instanceof FunctionExpression2 || Object.prototype.toString.call(arg) === EXPECTED_TOSTRING;
      };
      return FunctionExpression2;
    }();
    exports.FunctionExpression = FunctionExpression;
  }
});

// node_modules/@aws/dynamodb-expressions/build/ConditionExpression.js
var require_ConditionExpression = __commonJS({
  "node_modules/@aws/dynamodb-expressions/build/ConditionExpression.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var AttributePath_1 = require_AttributePath();
    var FunctionExpression_1 = require_FunctionExpression();
    function equals(operand) {
      return {
        type: "Equals",
        object: operand
      };
    }
    exports.equals = equals;
    function notEquals(operand) {
      return {
        type: "NotEquals",
        object: operand
      };
    }
    exports.notEquals = notEquals;
    function lessThan(operand) {
      return {
        type: "LessThan",
        object: operand
      };
    }
    exports.lessThan = lessThan;
    function lessThanOrEqualTo(operand) {
      return {
        type: "LessThanOrEqualTo",
        object: operand
      };
    }
    exports.lessThanOrEqualTo = lessThanOrEqualTo;
    function greaterThan(operand) {
      return {
        type: "GreaterThan",
        object: operand
      };
    }
    exports.greaterThan = greaterThan;
    function greaterThanOrEqualTo(operand) {
      return {
        type: "GreaterThanOrEqualTo",
        object: operand
      };
    }
    exports.greaterThanOrEqualTo = greaterThanOrEqualTo;
    function between(lowerBound, upperBound) {
      return {
        type: "Between",
        lowerBound,
        upperBound
      };
    }
    exports.between = between;
    function inList() {
      var operands = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        operands[_i] = arguments[_i];
      }
      return {
        type: "Membership",
        values: operands
      };
    }
    exports.inList = inList;
    function attributeExists() {
      return {
        type: "Function",
        name: "attribute_exists"
      };
    }
    exports.attributeExists = attributeExists;
    function attributeNotExists() {
      return {
        type: "Function",
        name: "attribute_not_exists"
      };
    }
    exports.attributeNotExists = attributeNotExists;
    function attributeType(expected) {
      return {
        type: "Function",
        name: "attribute_type",
        expected
      };
    }
    exports.attributeType = attributeType;
    function beginsWith(expected) {
      return {
        type: "Function",
        name: "begins_with",
        expected
      };
    }
    exports.beginsWith = beginsWith;
    function contains(expected) {
      return {
        type: "Function",
        name: "contains",
        expected
      };
    }
    exports.contains = contains;
    function isConditionExpressionPredicate(arg) {
      if (arg && typeof arg === "object") {
        switch (arg.type) {
          case "Equals":
          case "NotEquals":
          case "LessThan":
          case "LessThanOrEqualTo":
          case "GreaterThan":
          case "GreaterThanOrEqualTo":
            return arg.object !== void 0;
          case "Between":
            return arg.lowerBound !== void 0 && arg.upperBound !== void 0;
          case "Membership":
            return Array.isArray(arg.values);
          case "Function":
            switch (arg.name) {
              case "attribute_exists":
              case "attribute_not_exists":
                return true;
              case "attribute_type":
              case "begins_with":
              case "contains":
                return typeof arg.expected === "string";
            }
        }
      }
      return false;
    }
    exports.isConditionExpressionPredicate = isConditionExpressionPredicate;
    function isConditionExpressionSubject(arg) {
      return Boolean(arg) && typeof arg === "object" && (typeof arg.subject === "string" || AttributePath_1.AttributePath.isAttributePath(arg.subject));
    }
    exports.isConditionExpressionSubject = isConditionExpressionSubject;
    function isConditionExpression(arg) {
      var e_1, _a;
      if (FunctionExpression_1.FunctionExpression.isFunctionExpression(arg)) {
        return true;
      }
      if (Boolean(arg) && typeof arg === "object") {
        switch (arg.type) {
          case "Not":
            return isConditionExpression(arg.condition);
          case "And":
          case "Or":
            if (Array.isArray(arg.conditions)) {
              try {
                for (var _b = tslib_1.__values(arg.conditions), _c = _b.next(); !_c.done; _c = _b.next()) {
                  var condition = _c.value;
                  if (!isConditionExpression(condition)) {
                    return false;
                  }
                }
              } catch (e_1_1) {
                e_1 = { error: e_1_1 };
              } finally {
                try {
                  if (_c && !_c.done && (_a = _b.return))
                    _a.call(_b);
                } finally {
                  if (e_1)
                    throw e_1.error;
                }
              }
              return true;
            }
            return false;
          default:
            return isConditionExpressionSubject(arg) && isConditionExpressionPredicate(arg);
        }
      }
      return false;
    }
    exports.isConditionExpression = isConditionExpression;
    function serializeConditionExpression(condition, attributes) {
      if (FunctionExpression_1.FunctionExpression.isFunctionExpression(condition)) {
        return condition.serialize(attributes);
      }
      switch (condition.type) {
        case "Equals":
          return serializeBinaryComparison(condition, attributes, "=");
        case "NotEquals":
          return serializeBinaryComparison(condition, attributes, "<>");
        case "LessThan":
          return serializeBinaryComparison(condition, attributes, "<");
        case "LessThanOrEqualTo":
          return serializeBinaryComparison(condition, attributes, "<=");
        case "GreaterThan":
          return serializeBinaryComparison(condition, attributes, ">");
        case "GreaterThanOrEqualTo":
          return serializeBinaryComparison(condition, attributes, ">=");
        case "Between":
          return attributes.addName(condition.subject) + " BETWEEN " + serializeOperand(condition.lowerBound, attributes) + " AND " + serializeOperand(condition.upperBound, attributes);
        case "Membership":
          return attributes.addName(condition.subject) + " IN (" + condition.values.map(function(val) {
            return serializeOperand(val, attributes);
          }).join(", ") + ")";
        case "Function":
          var subject = AttributePath_1.AttributePath.isAttributePath(condition.subject) ? condition.subject : new AttributePath_1.AttributePath(condition.subject);
          switch (condition.name) {
            case "attribute_exists":
            case "attribute_not_exists":
              return new FunctionExpression_1.FunctionExpression(condition.name, subject).serialize(attributes);
            case "attribute_type":
            case "begins_with":
            case "contains":
              return new FunctionExpression_1.FunctionExpression(condition.name, subject, condition.expected).serialize(attributes);
          }
        case "Not":
          return "NOT (" + serializeConditionExpression(condition.condition, attributes) + ")";
        case "And":
        case "Or":
          if (condition.conditions.length === 1) {
            return serializeConditionExpression(condition.conditions[0], attributes);
          }
          return condition.conditions.map(function(cond) {
            return "(" + serializeConditionExpression(cond, attributes) + ")";
          }).join(" " + condition.type.toUpperCase() + " ");
      }
    }
    exports.serializeConditionExpression = serializeConditionExpression;
    function serializeBinaryComparison(cond, attributes, comparator) {
      return attributes.addName(cond.subject) + " " + comparator + " " + serializeOperand(cond.object, attributes);
    }
    function serializeOperand(operand, attributes) {
      if (FunctionExpression_1.FunctionExpression.isFunctionExpression(operand)) {
        return operand.serialize(attributes);
      }
      return AttributePath_1.AttributePath.isAttributePath(operand) ? attributes.addName(operand) : attributes.addValue(operand);
    }
  }
});

// node_modules/@aws/dynamodb-auto-marshaller/build/ObjectSet.js
var require_ObjectSet = __commonJS({
  "node_modules/@aws/dynamodb-auto-marshaller/build/ObjectSet.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var ObjectSet = function() {
      function ObjectSet2(iterable) {
        var e_1, _a;
        this[Symbol.toStringTag] = "Set";
        this._values = [];
        if (iterable) {
          try {
            for (var iterable_1 = tslib_1.__values(iterable), iterable_1_1 = iterable_1.next(); !iterable_1_1.done; iterable_1_1 = iterable_1.next()) {
              var item = iterable_1_1.value;
              this.add(item);
            }
          } catch (e_1_1) {
            e_1 = { error: e_1_1 };
          } finally {
            try {
              if (iterable_1_1 && !iterable_1_1.done && (_a = iterable_1.return))
                _a.call(iterable_1);
            } finally {
              if (e_1)
                throw e_1.error;
            }
          }
        }
      }
      ObjectSet2.prototype.add = function(value) {
        if (!this.has(value)) {
          this._values.push(value);
        }
        return this;
      };
      ObjectSet2.prototype.clear = function() {
        this._values = [];
      };
      ObjectSet2.prototype.entries = function() {
        return this._values.map(function(value) {
          return [value, value];
        })[Symbol.iterator]();
      };
      ObjectSet2.prototype.forEach = function(callback, thisArg) {
        var _this = this;
        this._values.forEach(function(value, index, array) {
          callback.call(thisArg, value, value, _this);
        }, thisArg);
      };
      ObjectSet2.prototype.keys = function() {
        return this[Symbol.iterator]();
      };
      Object.defineProperty(ObjectSet2.prototype, "size", {
        get: function() {
          return this._values.length;
        },
        enumerable: true,
        configurable: true
      });
      ObjectSet2.prototype.values = function() {
        return this[Symbol.iterator]();
      };
      ObjectSet2.prototype[Symbol.iterator] = function() {
        return this._values[Symbol.iterator]();
      };
      return ObjectSet2;
    }();
    exports.ObjectSet = ObjectSet;
  }
});

// node_modules/@aws/dynamodb-auto-marshaller/build/BinarySet.js
var require_BinarySet = __commonJS({
  "node_modules/@aws/dynamodb-auto-marshaller/build/BinarySet.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var ObjectSet_1 = require_ObjectSet();
    var BinarySet = function(_super) {
      tslib_1.__extends(BinarySet2, _super);
      function BinarySet2() {
        return _super !== null && _super.apply(this, arguments) || this;
      }
      BinarySet2.prototype.delete = function(value) {
        var valueView = getBinaryView(value);
        var scrubbedValues = this._values.filter(function(item) {
          return !binaryEquals(getBinaryView(item), valueView);
        });
        var numRemoved = this._values.length - scrubbedValues.length;
        this._values = scrubbedValues;
        return numRemoved > 0;
      };
      BinarySet2.prototype.has = function(value) {
        var e_1, _a;
        var valueView = getBinaryView(value);
        try {
          for (var _b = tslib_1.__values(this), _c = _b.next(); !_c.done; _c = _b.next()) {
            var item = _c.value;
            if (binaryEquals(getBinaryView(item), valueView)) {
              return true;
            }
          }
        } catch (e_1_1) {
          e_1 = { error: e_1_1 };
        } finally {
          try {
            if (_c && !_c.done && (_a = _b.return))
              _a.call(_b);
          } finally {
            if (e_1)
              throw e_1.error;
          }
        }
        return false;
      };
      return BinarySet2;
    }(ObjectSet_1.ObjectSet);
    exports.BinarySet = BinarySet;
    function binaryEquals(a, b) {
      if (a.byteLength !== b.byteLength) {
        return false;
      }
      for (var i = 0; i < a.byteLength; i++) {
        if (a.getUint8(i) !== b.getUint8(i)) {
          return false;
        }
      }
      return true;
    }
    function getBinaryView(value) {
      return ArrayBuffer.isView(value) ? new DataView(value.buffer, value.byteOffset, value.byteLength) : new DataView(value);
    }
  }
});

// node_modules/@aws/dynamodb-auto-marshaller/build/isArrayBuffer.js
var require_isArrayBuffer = __commonJS({
  "node_modules/@aws/dynamodb-auto-marshaller/build/isArrayBuffer.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function isArrayBuffer(arg) {
      return typeof ArrayBuffer === "function" && arg instanceof ArrayBuffer || Object.prototype.toString.call(arg) === "[object ArrayBuffer]";
    }
    exports.isArrayBuffer = isArrayBuffer;
  }
});

// node_modules/@aws/dynamodb-auto-marshaller/build/NumberValue.js
var require_NumberValue = __commonJS({
  "node_modules/@aws/dynamodb-auto-marshaller/build/NumberValue.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var NUMBER_VALUE_TAG = "DynamoDbNumberValue";
    var EXPECTED_TAG = "[object " + NUMBER_VALUE_TAG + "]";
    var NumberValue = function() {
      function NumberValue2(value) {
        this[Symbol.toStringTag] = NUMBER_VALUE_TAG;
        this.value = value.toString().trim();
      }
      NumberValue2.prototype.toJSON = function() {
        return this.valueOf();
      };
      NumberValue2.prototype.toString = function() {
        return this.value;
      };
      NumberValue2.prototype.valueOf = function() {
        return Number(this.value);
      };
      NumberValue2.isNumberValue = function(arg) {
        return typeof NumberValue2 === "function" && arg instanceof NumberValue2 || Object.prototype.toString.call(arg) === EXPECTED_TAG;
      };
      return NumberValue2;
    }();
    exports.NumberValue = NumberValue;
  }
});

// node_modules/@aws/dynamodb-auto-marshaller/build/NumberValueSet.js
var require_NumberValueSet = __commonJS({
  "node_modules/@aws/dynamodb-auto-marshaller/build/NumberValueSet.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var ObjectSet_1 = require_ObjectSet();
    var NumberValue_1 = require_NumberValue();
    var NumberValueSet = function(_super) {
      tslib_1.__extends(NumberValueSet2, _super);
      function NumberValueSet2() {
        return _super !== null && _super.apply(this, arguments) || this;
      }
      NumberValueSet2.prototype.add = function(value) {
        if (typeof value === "number" || typeof value === "string") {
          value = new NumberValue_1.NumberValue(value);
        }
        _super.prototype.add.call(this, value);
        return this;
      };
      NumberValueSet2.prototype.delete = function(value) {
        var valueString = value.toString();
        var scrubbedValues = this._values.filter(function(item) {
          return item.toString() !== valueString;
        });
        var numRemoved = this._values.length - scrubbedValues.length;
        this._values = scrubbedValues;
        return numRemoved > 0;
      };
      NumberValueSet2.prototype.has = function(value) {
        var e_1, _a;
        var valueString = value.toString();
        try {
          for (var _b = tslib_1.__values(this), _c = _b.next(); !_c.done; _c = _b.next()) {
            var item = _c.value;
            if (item.toString() === valueString) {
              return true;
            }
          }
        } catch (e_1_1) {
          e_1 = { error: e_1_1 };
        } finally {
          try {
            if (_c && !_c.done && (_a = _b.return))
              _a.call(_b);
          } finally {
            if (e_1)
              throw e_1.error;
          }
        }
        return false;
      };
      return NumberValueSet2;
    }(ObjectSet_1.ObjectSet);
    exports.NumberValueSet = NumberValueSet;
  }
});

// node_modules/@aws/dynamodb-auto-marshaller/build/Marshaller.js
var require_Marshaller = __commonJS({
  "node_modules/@aws/dynamodb-auto-marshaller/build/Marshaller.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var BinarySet_1 = require_BinarySet();
    var isArrayBuffer_1 = require_isArrayBuffer();
    var NumberValue_1 = require_NumberValue();
    var NumberValueSet_1 = require_NumberValueSet();
    exports.EmptyHandlingStrategies = {
      omit: "omit",
      nullify: "nullify",
      leave: "leave"
    };
    exports.InvalidHandlingStrategies = {
      omit: "omit",
      throw: "throw"
    };
    var Marshaller = function() {
      function Marshaller2(_a) {
        var _b = _a === void 0 ? {} : _a, _c = _b.onEmpty, onEmpty = _c === void 0 ? "leave" : _c, _d = _b.onInvalid, onInvalid = _d === void 0 ? "throw" : _d, _e = _b.unwrapNumbers, unwrapNumbers = _e === void 0 ? false : _e;
        this.onEmpty = onEmpty;
        this.onInvalid = onInvalid;
        this.unwrapNumbers = unwrapNumbers;
      }
      Marshaller2.prototype.marshallItem = function(item) {
        var value = this.marshallValue(item);
        if (!(value && value.M) && this.onInvalid === "throw") {
          throw new Error("Cannot serialize " + typeof item + " as an attribute map");
        }
        return value && value.M ? value.M : {};
      };
      Marshaller2.prototype.marshallValue = function(value) {
        switch (typeof value) {
          case "boolean":
            return { BOOL: value };
          case "number":
            return { N: value.toString(10) };
          case "object":
            return this.marshallComplexType(value);
          case "string":
            return value ? { S: value } : this.handleEmptyString(value);
          case "undefined":
            return void 0;
          case "function":
          case "symbol":
          default:
            if (this.onInvalid === "throw") {
              throw new Error("Cannot serialize values of the " + typeof value + " type");
            }
        }
      };
      Marshaller2.prototype.unmarshallItem = function(item) {
        return this.unmarshallValue({ M: item });
      };
      Marshaller2.prototype.unmarshallValue = function(item) {
        var _this = this;
        var e_1, _a, e_2, _b;
        if (item.S !== void 0) {
          return item.S;
        }
        if (item.N !== void 0) {
          return this.unwrapNumbers ? Number(item.N) : new NumberValue_1.NumberValue(item.N);
        }
        if (item.B !== void 0) {
          return item.B;
        }
        if (item.BOOL !== void 0) {
          return item.BOOL;
        }
        if (item.NULL !== void 0) {
          return null;
        }
        if (item.SS !== void 0) {
          var set = /* @__PURE__ */ new Set();
          try {
            for (var _c = tslib_1.__values(item.SS), _d = _c.next(); !_d.done; _d = _c.next()) {
              var member = _d.value;
              set.add(member);
            }
          } catch (e_1_1) {
            e_1 = { error: e_1_1 };
          } finally {
            try {
              if (_d && !_d.done && (_a = _c.return))
                _a.call(_c);
            } finally {
              if (e_1)
                throw e_1.error;
            }
          }
          return set;
        }
        if (item.NS !== void 0) {
          if (this.unwrapNumbers) {
            var set = /* @__PURE__ */ new Set();
            try {
              for (var _e = tslib_1.__values(item.NS), _f = _e.next(); !_f.done; _f = _e.next()) {
                var member = _f.value;
                set.add(Number(member));
              }
            } catch (e_2_1) {
              e_2 = { error: e_2_1 };
            } finally {
              try {
                if (_f && !_f.done && (_b = _e.return))
                  _b.call(_e);
              } finally {
                if (e_2)
                  throw e_2.error;
              }
            }
            return set;
          }
          return new NumberValueSet_1.NumberValueSet(item.NS.map(function(numberString) {
            return new NumberValue_1.NumberValue(numberString);
          }));
        }
        if (item.BS !== void 0) {
          return new BinarySet_1.BinarySet(item.BS);
        }
        if (item.L !== void 0) {
          return item.L.map(this.unmarshallValue.bind(this));
        }
        var _g = item.M, M = _g === void 0 ? {} : _g;
        return Object.keys(M).reduce(function(map, key) {
          map[key] = _this.unmarshallValue(M[key]);
          return map;
        }, {});
      };
      Marshaller2.prototype.marshallComplexType = function(value) {
        if (value === null) {
          return { NULL: true };
        }
        if (NumberValue_1.NumberValue.isNumberValue(value)) {
          return { N: value.toString() };
        }
        if (isBinaryValue(value)) {
          return this.marshallBinaryValue(value);
        }
        if (isSet(value)) {
          return this.marshallSet(value);
        }
        if (isMap(value)) {
          return this.marshallMap(value);
        }
        if (isIterable(value)) {
          return this.marshallList(value);
        }
        return this.marshallObject(value);
      };
      Marshaller2.prototype.marshallBinaryValue = function(binary) {
        if (binary.byteLength > 0 || this.onEmpty === "leave") {
          return { B: binary };
        }
        if (this.onEmpty === "nullify") {
          return { NULL: true };
        }
      };
      Marshaller2.prototype.marshallList = function(list) {
        var e_3, _a;
        var values = [];
        try {
          for (var list_1 = tslib_1.__values(list), list_1_1 = list_1.next(); !list_1_1.done; list_1_1 = list_1.next()) {
            var value = list_1_1.value;
            var marshalled = this.marshallValue(value);
            if (marshalled) {
              values.push(marshalled);
            }
          }
        } catch (e_3_1) {
          e_3 = { error: e_3_1 };
        } finally {
          try {
            if (list_1_1 && !list_1_1.done && (_a = list_1.return))
              _a.call(list_1);
          } finally {
            if (e_3)
              throw e_3.error;
          }
        }
        return { L: values };
      };
      Marshaller2.prototype.marshallMap = function(map) {
        var e_4, _a;
        var members = {};
        try {
          for (var map_1 = tslib_1.__values(map), map_1_1 = map_1.next(); !map_1_1.done; map_1_1 = map_1.next()) {
            var _b = tslib_1.__read(map_1_1.value, 2), key = _b[0], value = _b[1];
            if (typeof key !== "string") {
              if (this.onInvalid === "omit") {
                continue;
              }
              throw new Error("MapAttributeValues must have strings as keys; " + typeof key + " received instead");
            }
            var marshalled = this.marshallValue(value);
            if (marshalled) {
              members[key] = marshalled;
            }
          }
        } catch (e_4_1) {
          e_4 = { error: e_4_1 };
        } finally {
          try {
            if (map_1_1 && !map_1_1.done && (_a = map_1.return))
              _a.call(map_1);
          } finally {
            if (e_4)
              throw e_4.error;
          }
        }
        return { M: members };
      };
      Marshaller2.prototype.marshallObject = function(object) {
        var _this = this;
        return {
          M: Object.keys(object).reduce(function(map, key) {
            var marshalled = _this.marshallValue(object[key]);
            if (marshalled) {
              map[key] = marshalled;
            }
            return map;
          }, {})
        };
      };
      Marshaller2.prototype.marshallSet = function(arg) {
        switch (getSetType(arg[Symbol.iterator]().next().value)) {
          case "binary":
            return this.collectSet(arg, isBinaryEmpty, "BS", "binary");
          case "number":
            return this.collectSet(arg, isNumberEmpty, "NS", "number", stringifyNumber);
          case "string":
            return this.collectSet(arg, isStringEmpty, "SS", "string");
          case "unknown":
            if (this.onInvalid === "throw") {
              throw new Error("Sets must be composed of strings, binary values, or numbers");
            }
            return void 0;
          case "undefined":
            if (this.onEmpty === "nullify") {
              return { NULL: true };
            }
        }
      };
      Marshaller2.prototype.collectSet = function(set, isEmpty, tag, elementType, transform) {
        var e_5, _a, _b;
        var values = [];
        try {
          for (var set_1 = tslib_1.__values(set), set_1_1 = set_1.next(); !set_1_1.done; set_1_1 = set_1.next()) {
            var element = set_1_1.value;
            if (getSetType(element) !== elementType) {
              if (this.onInvalid === "omit") {
                continue;
              }
              throw new Error("Unable to serialize " + typeof element + " as a member of a " + elementType + " set");
            }
            if (!isEmpty(element) || this.onEmpty === "leave") {
              values.push(transform ? transform(element) : element);
            }
          }
        } catch (e_5_1) {
          e_5 = { error: e_5_1 };
        } finally {
          try {
            if (set_1_1 && !set_1_1.done && (_a = set_1.return))
              _a.call(set_1);
          } finally {
            if (e_5)
              throw e_5.error;
          }
        }
        if (values.length > 0 || this.onEmpty === "leave") {
          return _b = {}, _b[tag] = values, _b;
        }
        if (this.onEmpty === "nullify") {
          return { NULL: true };
        }
      };
      Marshaller2.prototype.handleEmptyString = function(value) {
        switch (this.onEmpty) {
          case "leave":
            return { S: value };
          case "nullify":
            return { NULL: true };
        }
      };
      return Marshaller2;
    }();
    exports.Marshaller = Marshaller;
    function getSetType(arg) {
      var type = typeof arg;
      if (type === "string" || type === "number" || type === "undefined") {
        return type;
      }
      if (NumberValue_1.NumberValue.isNumberValue(arg)) {
        return "number";
      }
      if (ArrayBuffer.isView(arg) || isArrayBuffer_1.isArrayBuffer(arg)) {
        return "binary";
      }
      return "unknown";
    }
    function isBinaryEmpty(arg) {
      return arg.byteLength === 0;
    }
    function isBinaryValue(arg) {
      return ArrayBuffer.isView(arg) || isArrayBuffer_1.isArrayBuffer(arg);
    }
    function isIterable(arg) {
      return Boolean(arg) && typeof arg[Symbol.iterator] === "function";
    }
    function isMap(arg) {
      return Boolean(arg) && Object.prototype.toString.call(arg) === "[object Map]";
    }
    function isNumberEmpty() {
      return false;
    }
    function isSet(arg) {
      return Boolean(arg) && Object.prototype.toString.call(arg) === "[object Set]";
    }
    function isStringEmpty(arg) {
      return arg.length === 0;
    }
    function stringifyNumber(arg) {
      return arg.toString();
    }
  }
});

// node_modules/@aws/dynamodb-auto-marshaller/build/index.js
var require_build = __commonJS({
  "node_modules/@aws/dynamodb-auto-marshaller/build/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_BinarySet(), exports);
    tslib_1.__exportStar(require_Marshaller(), exports);
    tslib_1.__exportStar(require_NumberValue(), exports);
    tslib_1.__exportStar(require_NumberValueSet(), exports);
  }
});

// node_modules/@aws/dynamodb-expressions/build/ExpressionAttributes.js
var require_ExpressionAttributes = __commonJS({
  "node_modules/@aws/dynamodb-expressions/build/ExpressionAttributes.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var AttributePath_1 = require_AttributePath();
    var AttributeValue_1 = require_AttributeValue();
    var dynamodb_auto_marshaller_1 = require_build();
    var ExpressionAttributes = function() {
      function ExpressionAttributes2() {
        this.names = {};
        this.values = {};
        this.marshaller = new dynamodb_auto_marshaller_1.Marshaller();
        this.nameMap = {};
        this._ctr = 0;
      }
      ExpressionAttributes2.prototype.addName = function(path) {
        var e_1, _a;
        if (AttributePath_1.AttributePath.isAttributePath(path)) {
          var escapedPath = "";
          try {
            for (var _b = tslib_1.__values(path.elements), _c = _b.next(); !_c.done; _c = _b.next()) {
              var element = _c.value;
              if (element.type === "AttributeName") {
                escapedPath += "." + this.addAttributeName(element.name);
              } else {
                escapedPath += "[" + element.index + "]";
              }
            }
          } catch (e_1_1) {
            e_1 = { error: e_1_1 };
          } finally {
            try {
              if (_c && !_c.done && (_a = _b.return))
                _a.call(_b);
            } finally {
              if (e_1)
                throw e_1.error;
            }
          }
          return escapedPath.substring(1);
        }
        return this.addName(new AttributePath_1.AttributePath(path));
      };
      ExpressionAttributes2.prototype.addValue = function(value) {
        var modeledAttrValue = AttributeValue_1.AttributeValue.isAttributeValue(value) ? value.marshalled : this.marshaller.marshallValue(value);
        var substitution = ":val" + this._ctr++;
        this.values[substitution] = modeledAttrValue;
        return substitution;
      };
      ExpressionAttributes2.prototype.addAttributeName = function(attributeName) {
        if (!(attributeName in this.nameMap)) {
          this.nameMap[attributeName] = "#attr" + this._ctr++;
          this.names[this.nameMap[attributeName]] = attributeName;
        }
        return this.nameMap[attributeName];
      };
      return ExpressionAttributes2;
    }();
    exports.ExpressionAttributes = ExpressionAttributes;
  }
});

// node_modules/@aws/dynamodb-expressions/build/MathematicalExpression.js
var require_MathematicalExpression = __commonJS({
  "node_modules/@aws/dynamodb-expressions/build/MathematicalExpression.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var AttributePath_1 = require_AttributePath();
    var MATHEMATICAL_EXPRESSION_TAG = "AmazonDynamoDbMathematicalExpression";
    var EXPECTED_TOSTRING = "[object " + MATHEMATICAL_EXPRESSION_TAG + "]";
    var MathematicalExpression = function() {
      function MathematicalExpression2(lhs, operator, rhs) {
        this.lhs = lhs;
        this.operator = operator;
        this.rhs = rhs;
        this[Symbol.toStringTag] = MATHEMATICAL_EXPRESSION_TAG;
      }
      MathematicalExpression2.prototype.serialize = function(attributes) {
        var safeArgs = [this.lhs, this.rhs].map(function(arg) {
          return AttributePath_1.AttributePath.isAttributePath(arg) || typeof arg === "string" ? attributes.addName(arg) : attributes.addValue(arg);
        });
        return safeArgs[0] + " " + this.operator + " " + safeArgs[1];
      };
      MathematicalExpression2.isMathematicalExpression = function(arg) {
        return arg instanceof MathematicalExpression2 || Object.prototype.toString.call(arg) === EXPECTED_TOSTRING;
      };
      return MathematicalExpression2;
    }();
    exports.MathematicalExpression = MathematicalExpression;
  }
});

// node_modules/@aws/dynamodb-expressions/build/ProjectionExpression.js
var require_ProjectionExpression = __commonJS({
  "node_modules/@aws/dynamodb-expressions/build/ProjectionExpression.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    function serializeProjectionExpression(projection, attributes) {
      var e_1, _a;
      var serialized = [];
      try {
        for (var projection_1 = tslib_1.__values(projection), projection_1_1 = projection_1.next(); !projection_1_1.done; projection_1_1 = projection_1.next()) {
          var projected = projection_1_1.value;
          serialized.push(attributes.addName(projected));
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (projection_1_1 && !projection_1_1.done && (_a = projection_1.return))
            _a.call(projection_1);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return serialized.join(", ");
    }
    exports.serializeProjectionExpression = serializeProjectionExpression;
  }
});

// node_modules/@aws/dynamodb-expressions/build/UpdateExpression.js
var require_UpdateExpression = __commonJS({
  "node_modules/@aws/dynamodb-expressions/build/UpdateExpression.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var AttributePath_1 = require_AttributePath();
    var FunctionExpression_1 = require_FunctionExpression();
    var MathematicalExpression_1 = require_MathematicalExpression();
    var UpdateExpression = function() {
      function UpdateExpression2() {
        this.toAdd = /* @__PURE__ */ new Map();
        this.toDelete = /* @__PURE__ */ new Map();
        this.toRemove = /* @__PURE__ */ new Set();
        this.toSet = /* @__PURE__ */ new Map();
      }
      UpdateExpression2.prototype.add = function(path, value) {
        this.toAdd.set(AttributePath_1.AttributePath.isAttributePath(path) ? path : new AttributePath_1.AttributePath(path), value);
      };
      UpdateExpression2.prototype.delete = function(path, value) {
        this.toDelete.set(AttributePath_1.AttributePath.isAttributePath(path) ? path : new AttributePath_1.AttributePath(path), value);
      };
      UpdateExpression2.prototype.remove = function(path) {
        this.toRemove.add(AttributePath_1.AttributePath.isAttributePath(path) ? path : new AttributePath_1.AttributePath(path));
      };
      UpdateExpression2.prototype.set = function(path, value) {
        this.toSet.set(AttributePath_1.AttributePath.isAttributePath(path) ? path : new AttributePath_1.AttributePath(path), value);
      };
      UpdateExpression2.prototype.serialize = function(attributes) {
        var e_1, _a, e_2, _b, e_3, _c, e_4, _d;
        var clauses = [];
        var phrases = [];
        try {
          for (var _e = tslib_1.__values([
            [this.toAdd, "ADD"],
            [this.toDelete, "DELETE"]
          ]), _f = _e.next(); !_f.done; _f = _e.next()) {
            var _g = tslib_1.__read(_f.value, 2), mapping = _g[0], verb = _g[1];
            try {
              for (var _h = tslib_1.__values(mapping.entries()), _j = _h.next(); !_j.done; _j = _h.next()) {
                var _k = tslib_1.__read(_j.value, 2), key = _k[0], value = _k[1];
                phrases.push(attributes.addName(key) + " " + attributes.addValue(value));
              }
            } catch (e_2_1) {
              e_2 = { error: e_2_1 };
            } finally {
              try {
                if (_j && !_j.done && (_b = _h.return))
                  _b.call(_h);
              } finally {
                if (e_2)
                  throw e_2.error;
              }
            }
            if (phrases.length > 0) {
              clauses.push(verb + " " + phrases.join(", "));
              phrases.length = 0;
            }
          }
        } catch (e_1_1) {
          e_1 = { error: e_1_1 };
        } finally {
          try {
            if (_f && !_f.done && (_a = _e.return))
              _a.call(_e);
          } finally {
            if (e_1)
              throw e_1.error;
          }
        }
        try {
          for (var _l = tslib_1.__values(this.toSet.entries()), _m = _l.next(); !_m.done; _m = _l.next()) {
            var _o = tslib_1.__read(_m.value, 2), key = _o[0], value = _o[1];
            phrases.push(attributes.addName(key) + " = " + (FunctionExpression_1.FunctionExpression.isFunctionExpression(value) || MathematicalExpression_1.MathematicalExpression.isMathematicalExpression(value) ? value.serialize(attributes) : attributes.addValue(value)));
          }
        } catch (e_3_1) {
          e_3 = { error: e_3_1 };
        } finally {
          try {
            if (_m && !_m.done && (_c = _l.return))
              _c.call(_l);
          } finally {
            if (e_3)
              throw e_3.error;
          }
        }
        if (phrases.length > 0) {
          clauses.push("SET " + phrases.join(", "));
          phrases.length = 0;
        }
        try {
          for (var _p = tslib_1.__values(this.toRemove), _q = _p.next(); !_q.done; _q = _p.next()) {
            var keyToRemove = _q.value;
            phrases.push(attributes.addName(keyToRemove));
          }
        } catch (e_4_1) {
          e_4 = { error: e_4_1 };
        } finally {
          try {
            if (_q && !_q.done && (_d = _p.return))
              _d.call(_p);
          } finally {
            if (e_4)
              throw e_4.error;
          }
        }
        if (phrases.length > 0) {
          clauses.push("REMOVE " + phrases.join(", "));
          phrases.length = 0;
        }
        return clauses.join(" ");
      };
      return UpdateExpression2;
    }();
    exports.UpdateExpression = UpdateExpression;
  }
});

// node_modules/@aws/dynamodb-expressions/build/index.js
var require_build2 = __commonJS({
  "node_modules/@aws/dynamodb-expressions/build/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_AttributePath(), exports);
    tslib_1.__exportStar(require_AttributeValue(), exports);
    tslib_1.__exportStar(require_ConditionExpression(), exports);
    tslib_1.__exportStar(require_ExpressionAttributes(), exports);
    tslib_1.__exportStar(require_FunctionExpression(), exports);
    tslib_1.__exportStar(require_MathematicalExpression(), exports);
    tslib_1.__exportStar(require_ProjectionExpression(), exports);
    tslib_1.__exportStar(require_UpdateExpression(), exports);
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/toSchemaName.js
var require_toSchemaName = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/toSchemaName.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var dynamodb_expressions_1 = require_build2();
    function toSchemaName(path, schema) {
      var e_1, _a;
      if (typeof path === "string") {
        path = new dynamodb_expressions_1.AttributePath(path);
      }
      var elements = path.elements.map(function(el) {
        return tslib_1.__assign({}, el);
      });
      var cursor = {
        type: "Document",
        members: schema
      };
      try {
        for (var elements_1 = tslib_1.__values(elements), elements_1_1 = elements_1.next(); !elements_1_1.done; elements_1_1 = elements_1.next()) {
          var element = elements_1_1.value;
          if (element.type === "AttributeName" && cursor && cursor.type === "Document") {
            var name = element.name;
            element.name = getSchemaName(name, cursor.members);
            cursor = cursor.members[name];
          } else if (element.type === "ListIndex" && cursor && cursor.type === "List") {
            cursor = cursor.memberType;
          } else {
            break;
          }
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (elements_1_1 && !elements_1_1.done && (_a = elements_1.return))
            _a.call(elements_1);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return new dynamodb_expressions_1.AttributePath(elements);
    }
    exports.toSchemaName = toSchemaName;
    function getSchemaName(propertyName, schema) {
      var fieldSchema = schema[propertyName];
      if (fieldSchema) {
        var _a = fieldSchema.attributeName, attributeName = _a === void 0 ? propertyName : _a;
        return attributeName;
      }
      return propertyName;
    }
    exports.getSchemaName = getSchemaName;
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/marshallExpression.js
var require_marshallExpression = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/marshallExpression.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var toSchemaName_1 = require_toSchemaName();
    var dynamodb_expressions_1 = require_build2();
    function marshallConditionExpression(expression, schema, attributes) {
      if (attributes === void 0) {
        attributes = new dynamodb_expressions_1.ExpressionAttributes();
      }
      var serialized = dynamodb_expressions_1.serializeConditionExpression(normalizeConditionExpression(expression, schema), attributes);
      return {
        expression: serialized,
        ExpressionAttributeNames: attributes.names,
        ExpressionAttributeValues: attributes.values
      };
    }
    exports.marshallConditionExpression = marshallConditionExpression;
    function marshallFunctionExpression(expression, schema, attributes) {
      if (attributes === void 0) {
        attributes = new dynamodb_expressions_1.ExpressionAttributes();
      }
      var serialized = normalizeFunctionExpression(expression, schema).serialize(attributes);
      return {
        expression: serialized,
        ExpressionAttributeNames: attributes.names,
        ExpressionAttributeValues: attributes.values
      };
    }
    exports.marshallFunctionExpression = marshallFunctionExpression;
    function marshallMathematicalExpression(expression, schema, attributes) {
      if (attributes === void 0) {
        attributes = new dynamodb_expressions_1.ExpressionAttributes();
      }
      var serialized = normalizeMathematicalExpression(expression, schema).serialize(attributes);
      return {
        expression: serialized,
        ExpressionAttributeNames: attributes.names,
        ExpressionAttributeValues: attributes.values
      };
    }
    exports.marshallMathematicalExpression = marshallMathematicalExpression;
    function marshallProjectionExpression(expression, schema, attributes) {
      if (attributes === void 0) {
        attributes = new dynamodb_expressions_1.ExpressionAttributes();
      }
      var serialized = dynamodb_expressions_1.serializeProjectionExpression(expression.map(function(el) {
        return toSchemaName_1.toSchemaName(el, schema);
      }), attributes);
      return {
        expression: serialized,
        ExpressionAttributeNames: attributes.names,
        ExpressionAttributeValues: attributes.values
      };
    }
    exports.marshallProjectionExpression = marshallProjectionExpression;
    function marshallUpdateExpression(expression, schema, attributes) {
      if (attributes === void 0) {
        attributes = new dynamodb_expressions_1.ExpressionAttributes();
      }
      var serialized = normalizeUpdateExpression(expression, schema).serialize(attributes);
      return {
        expression: serialized,
        ExpressionAttributeNames: attributes.names,
        ExpressionAttributeValues: attributes.values
      };
    }
    exports.marshallUpdateExpression = marshallUpdateExpression;
    function normalizeConditionExpression(expression, schema) {
      if (dynamodb_expressions_1.FunctionExpression.isFunctionExpression(expression)) {
        return normalizeFunctionExpression(expression, schema);
      }
      switch (expression.type) {
        case "Equals":
        case "NotEquals":
        case "LessThan":
        case "LessThanOrEqualTo":
        case "GreaterThan":
        case "GreaterThanOrEqualTo":
          return tslib_1.__assign({}, expression, { subject: toSchemaName_1.toSchemaName(expression.subject, schema), object: normalizeIfPath(expression.object, schema) });
        case "Function":
          switch (expression.name) {
            case "attribute_exists":
            case "attribute_not_exists":
              return tslib_1.__assign({}, expression, { subject: toSchemaName_1.toSchemaName(expression.subject, schema) });
            case "attribute_type":
            case "begins_with":
            case "contains":
              return tslib_1.__assign({}, expression, { subject: toSchemaName_1.toSchemaName(expression.subject, schema) });
          }
        case "Between":
          return tslib_1.__assign({}, expression, { subject: toSchemaName_1.toSchemaName(expression.subject, schema), lowerBound: normalizeIfPath(expression.lowerBound, schema), upperBound: normalizeIfPath(expression.upperBound, schema) });
        case "Membership":
          return tslib_1.__assign({}, expression, { subject: toSchemaName_1.toSchemaName(expression.subject, schema), values: expression.values.map(function(arg) {
            return normalizeIfPath(arg, schema);
          }) });
        case "Not":
          return tslib_1.__assign({}, expression, { condition: normalizeConditionExpression(expression.condition, schema) });
        case "And":
        case "Or":
          return tslib_1.__assign({}, expression, { conditions: expression.conditions.map(function(condition) {
            return normalizeConditionExpression(condition, schema);
          }) });
      }
    }
    function normalizeFunctionExpression(expression, schema) {
      return new (dynamodb_expressions_1.FunctionExpression.bind.apply(dynamodb_expressions_1.FunctionExpression, tslib_1.__spread([void 0, expression.name], expression.args.map(function(arg) {
        return normalizeIfPath(arg, schema);
      }))))();
    }
    function normalizeMathematicalExpression(expression, schema) {
      return new dynamodb_expressions_1.MathematicalExpression(dynamodb_expressions_1.AttributePath.isAttributePath(expression.lhs) || typeof expression.lhs === "string" ? toSchemaName_1.toSchemaName(expression.lhs, schema) : expression.lhs, expression.operator, dynamodb_expressions_1.AttributePath.isAttributePath(expression.rhs) || typeof expression.rhs === "string" ? toSchemaName_1.toSchemaName(expression.rhs, schema) : expression.rhs);
    }
    var mapsToTransform = [
      ["toAdd", "add"],
      ["toDelete", "delete"],
      ["toSet", "set"]
    ];
    function normalizeUpdateExpression(expression, schema) {
      var e_1, _a, e_2, _b;
      var normalized = new dynamodb_expressions_1.UpdateExpression();
      try {
        for (var mapsToTransform_1 = tslib_1.__values(mapsToTransform), mapsToTransform_1_1 = mapsToTransform_1.next(); !mapsToTransform_1_1.done; mapsToTransform_1_1 = mapsToTransform_1.next()) {
          var _c = tslib_1.__read(mapsToTransform_1_1.value, 2), dataSet = _c[0], exprMethod = _c[1];
          try {
            for (var _d = tslib_1.__values(expression[dataSet]), _e = _d.next(); !_e.done; _e = _d.next()) {
              var _f = tslib_1.__read(_e.value, 2), path = _f[0], value = _f[1];
              normalized[exprMethod](toSchemaName_1.toSchemaName(path, schema), value);
            }
          } catch (e_2_1) {
            e_2 = { error: e_2_1 };
          } finally {
            try {
              if (_e && !_e.done && (_b = _d.return))
                _b.call(_d);
            } finally {
              if (e_2)
                throw e_2.error;
            }
          }
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (mapsToTransform_1_1 && !mapsToTransform_1_1.done && (_a = mapsToTransform_1.return))
            _a.call(mapsToTransform_1);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      expression.toRemove.forEach(function(el) {
        return normalized.remove(toSchemaName_1.toSchemaName(el, schema));
      });
      return normalized;
    }
    function normalizeIfPath(path, schema) {
      if (dynamodb_expressions_1.AttributePath.isAttributePath(path)) {
        return toSchemaName_1.toSchemaName(path, schema);
      }
      return path;
    }
  }
});

// node_modules/utf8-bytes/index.js
var require_utf8_bytes = __commonJS({
  "node_modules/utf8-bytes/index.js"(exports, module2) {
    module2.exports = function(str) {
      var bytes = [];
      for (var i = 0; i < str.length; i++) {
        var c = str.charCodeAt(i);
        if (c >= 55296 && c <= 56319 && i + 1 < str.length) {
          var cn = str.charCodeAt(i + 1);
          if (cn >= 56320 && cn <= 57343) {
            var pt = (c - 55296) * 1024 + cn - 56320 + 65536;
            bytes.push(240 + Math.floor(pt / 64 / 64 / 64), 128 + Math.floor(pt / 64 / 64) % 64, 128 + Math.floor(pt / 64) % 64, 128 + pt % 64);
            i += 1;
            continue;
          }
        }
        if (c >= 2048) {
          bytes.push(224 + Math.floor(c / 64 / 64), 128 + Math.floor(c / 64) % 64, 128 + c % 64);
        } else if (c >= 128) {
          bytes.push(192 + Math.floor(c / 64), 128 + c % 64);
        } else
          bytes.push(c);
      }
      return bytes;
    };
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/marshallItem.js
var require_marshallItem = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/marshallItem.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var InvalidValueError_1 = require_InvalidValueError();
    var InvalidSchemaError_1 = require_InvalidSchemaError();
    var dynamodb_auto_marshaller_1 = require_build();
    var bytes = require_utf8_bytes();
    function marshallItem(schema, input) {
      var e_1, _a;
      var marshalled = {};
      try {
        for (var _b = tslib_1.__values(Object.keys(schema)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var key = _c.value;
          var value = input[key];
          var _d = schema[key].attributeName, attributeName = _d === void 0 ? key : _d;
          var marshalledValue = marshallValue(schema[key], value);
          if (marshalledValue) {
            marshalled[attributeName] = marshalledValue;
          }
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return marshalled;
    }
    exports.marshallItem = marshallItem;
    function marshallValue(schemaType, input) {
      var e_2, _a, e_3, _b, e_4, _c, e_5, _d, e_6, _e, e_7, _f;
      if (input === void 0) {
        var defaultProvider = schemaType.defaultProvider;
        if (typeof defaultProvider === "function") {
          input = defaultProvider();
        } else {
          return void 0;
        }
      }
      if (schemaType.type === "Any") {
        var _g = schemaType.onEmpty, onEmpty = _g === void 0 ? "nullify" : _g, _h = schemaType.onInvalid, onInvalid = _h === void 0 ? "omit" : _h, _j = schemaType.unwrapNumbers, unwrapNumbers = _j === void 0 ? false : _j;
        var marshaller = new dynamodb_auto_marshaller_1.Marshaller({ onEmpty, onInvalid, unwrapNumbers });
        return marshaller.marshallValue(input);
      }
      if (schemaType.type === "Binary") {
        if (!input || input.length === 0 || input.byteLength === 0) {
          return { NULL: true };
        }
        return { B: marshallBinary(input) };
      }
      if (schemaType.type === "Boolean") {
        return { BOOL: Boolean(input) };
      }
      if (schemaType.type === "Custom") {
        return schemaType.marshall(input);
      }
      if (schemaType.type === "Collection") {
        var _k = schemaType.onEmpty, onEmpty = _k === void 0 ? "nullify" : _k, _l = schemaType.onInvalid, onInvalid = _l === void 0 ? "omit" : _l, _m = schemaType.unwrapNumbers, unwrapNumbers = _m === void 0 ? false : _m;
        var marshaller = new dynamodb_auto_marshaller_1.Marshaller({ onEmpty, onInvalid, unwrapNumbers });
        var collected = [];
        try {
          for (var input_1 = tslib_1.__values(input), input_1_1 = input_1.next(); !input_1_1.done; input_1_1 = input_1.next()) {
            var element = input_1_1.value;
            var marshalled = marshaller.marshallValue(element);
            if (marshalled) {
              collected.push(marshalled);
            }
          }
        } catch (e_2_1) {
          e_2 = { error: e_2_1 };
        } finally {
          try {
            if (input_1_1 && !input_1_1.done && (_a = input_1.return))
              _a.call(input_1);
          } finally {
            if (e_2)
              throw e_2.error;
          }
        }
        return { L: collected };
      }
      if (schemaType.type === "Date") {
        var date = void 0;
        if (typeof input === "string") {
          date = new Date(input);
        } else if (typeof input === "number") {
          date = new Date(input * 1e3);
        } else if (isDate(input)) {
          date = input;
        } else {
          throw new InvalidValueError_1.InvalidValueError(input, "Unable to convert value to date");
        }
        return { N: marshallNumber(Math.floor(date.valueOf() / 1e3)) };
      }
      if (schemaType.type === "Document") {
        return { M: marshallItem(schemaType.members, input) };
      }
      if (schemaType.type === "Hash") {
        var _o = schemaType.onEmpty, onEmpty = _o === void 0 ? "nullify" : _o, _p = schemaType.onInvalid, onInvalid = _p === void 0 ? "omit" : _p, _q = schemaType.unwrapNumbers, unwrapNumbers = _q === void 0 ? false : _q;
        var marshaller = new dynamodb_auto_marshaller_1.Marshaller({ onEmpty, onInvalid, unwrapNumbers });
        return { M: marshaller.marshallItem(input) };
      }
      if (schemaType.type === "List") {
        var elements = [];
        try {
          for (var input_2 = tslib_1.__values(input), input_2_1 = input_2.next(); !input_2_1.done; input_2_1 = input_2.next()) {
            var member = input_2_1.value;
            var marshalled = marshallValue(schemaType.memberType, member);
            if (marshalled) {
              elements.push(marshalled);
            }
          }
        } catch (e_3_1) {
          e_3 = { error: e_3_1 };
        } finally {
          try {
            if (input_2_1 && !input_2_1.done && (_b = input_2.return))
              _b.call(input_2);
          } finally {
            if (e_3)
              throw e_3.error;
          }
        }
        return { L: elements };
      }
      if (schemaType.type === "Map") {
        var marshalled = {};
        if (typeof input[Symbol.iterator] === "function") {
          try {
            for (var input_3 = tslib_1.__values(input), input_3_1 = input_3.next(); !input_3_1.done; input_3_1 = input_3.next()) {
              var _r = tslib_1.__read(input_3_1.value, 2), key = _r[0], value = _r[1];
              var marshalledValue = marshallValue(schemaType.memberType, value);
              if (marshalledValue) {
                marshalled[key] = marshalledValue;
              }
            }
          } catch (e_4_1) {
            e_4 = { error: e_4_1 };
          } finally {
            try {
              if (input_3_1 && !input_3_1.done && (_c = input_3.return))
                _c.call(input_3);
            } finally {
              if (e_4)
                throw e_4.error;
            }
          }
        } else if (typeof input === "object") {
          try {
            for (var _s = tslib_1.__values(Object.keys(input)), _t = _s.next(); !_t.done; _t = _s.next()) {
              var key = _t.value;
              var marshalledValue = marshallValue(schemaType.memberType, input[key]);
              if (marshalledValue) {
                marshalled[key] = marshalledValue;
              }
            }
          } catch (e_5_1) {
            e_5 = { error: e_5_1 };
          } finally {
            try {
              if (_t && !_t.done && (_d = _s.return))
                _d.call(_s);
            } finally {
              if (e_5)
                throw e_5.error;
            }
          }
        } else {
          throw new InvalidValueError_1.InvalidValueError(input, "Unable to convert value to map");
        }
        return { M: marshalled };
      }
      if (schemaType.type === "Null") {
        return { NULL: true };
      }
      if (schemaType.type === "Number") {
        return { N: marshallNumber(input) };
      }
      if (schemaType.type === "Set") {
        if (schemaType.memberType === "Binary") {
          if (!(input instanceof dynamodb_auto_marshaller_1.BinarySet)) {
            var set = new dynamodb_auto_marshaller_1.BinarySet();
            try {
              for (var input_4 = tslib_1.__values(input), input_4_1 = input_4.next(); !input_4_1.done; input_4_1 = input_4.next()) {
                var item = input_4_1.value;
                set.add(marshallBinary(item));
              }
            } catch (e_6_1) {
              e_6 = { error: e_6_1 };
            } finally {
              try {
                if (input_4_1 && !input_4_1.done && (_e = input_4.return))
                  _e.call(input_4);
              } finally {
                if (e_6)
                  throw e_6.error;
              }
            }
            input = set;
          }
          return marshallSet(input, marshallBinary, function(bin) {
            return bin.byteLength === 0;
          }, "BS");
        }
        if (schemaType.memberType === "Number") {
          if (!(input instanceof Set)) {
            input = new dynamodb_auto_marshaller_1.NumberValueSet(input);
          }
          return marshallSet(input, marshallNumber, function() {
            return false;
          }, "NS");
        }
        if (schemaType.memberType === "String") {
          if (!(input instanceof Set)) {
            var original = input;
            input = /* @__PURE__ */ new Set();
            try {
              for (var original_1 = tslib_1.__values(original), original_1_1 = original_1.next(); !original_1_1.done; original_1_1 = original_1.next()) {
                var el = original_1_1.value;
                input.add(el);
              }
            } catch (e_7_1) {
              e_7 = { error: e_7_1 };
            } finally {
              try {
                if (original_1_1 && !original_1_1.done && (_f = original_1.return))
                  _f.call(original_1);
              } finally {
                if (e_7)
                  throw e_7.error;
              }
            }
          }
          return marshallSet(input, marshallString, function(string2) {
            return string2.length === 0;
          }, "SS");
        }
        throw new InvalidSchemaError_1.InvalidSchemaError(schemaType, "Unrecognized set member type: " + schemaType.memberType);
      }
      if (schemaType.type === "String") {
        var string = marshallString(input);
        if (string.length === 0) {
          return { NULL: true };
        }
        return { S: string };
      }
      if (schemaType.type === "Tuple") {
        return {
          L: schemaType.members.map(function(type, index) {
            return marshallValue(type, input[index]);
          }).filter(function(val) {
            return val !== void 0;
          })
        };
      }
      throw new InvalidSchemaError_1.InvalidSchemaError(schemaType, "Unrecognized schema node");
    }
    exports.marshallValue = marshallValue;
    function marshallBinary(input) {
      if (ArrayBuffer.isView(input)) {
        return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
      }
      if (isArrayBuffer(input)) {
        return new Uint8Array(input);
      }
      return Uint8Array.from(bytes(input));
    }
    function marshallNumber(input) {
      return input.toString(10);
    }
    function marshallString(input) {
      return input.toString();
    }
    function marshallSet(value, marshaller, isEmpty, setTag) {
      var e_8, _a, _b;
      var collected = [];
      try {
        for (var value_1 = tslib_1.__values(value), value_1_1 = value_1.next(); !value_1_1.done; value_1_1 = value_1.next()) {
          var member = value_1_1.value;
          var marshalled = marshaller(member);
          if (isEmpty(marshalled)) {
            continue;
          }
          collected.push(marshalled);
        }
      } catch (e_8_1) {
        e_8 = { error: e_8_1 };
      } finally {
        try {
          if (value_1_1 && !value_1_1.done && (_a = value_1.return))
            _a.call(value_1);
        } finally {
          if (e_8)
            throw e_8.error;
        }
      }
      if (collected.length === 0) {
        return { NULL: true };
      }
      return _b = {}, _b[setTag] = collected, _b;
    }
    function isArrayBuffer(arg) {
      return typeof ArrayBuffer === "function" && (arg instanceof ArrayBuffer || Object.prototype.toString.call(arg) === "[object ArrayBuffer]");
    }
    function isDate(arg) {
      return arg instanceof Date || Object.prototype.toString.call(arg) === "[object Date]";
    }
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/marshallKey.js
var require_marshallKey = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/marshallKey.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var isKey_1 = require_isKey();
    var marshallItem_1 = require_marshallItem();
    function marshallKey(schema, input, indexName) {
      var e_1, _a;
      var marshalled = {};
      try {
        for (var _b = tslib_1.__values(Object.keys(schema)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var propertyKey = _c.value;
          var fieldSchema = schema[propertyKey];
          if (isKey_1.isKey(fieldSchema, indexName)) {
            var _d = fieldSchema.attributeName, attributeName = _d === void 0 ? propertyKey : _d;
            var value = marshallItem_1.marshallValue(fieldSchema, input[propertyKey]);
            if (value) {
              marshalled[attributeName] = value;
            }
          }
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return marshalled;
    }
    exports.marshallKey = marshallKey;
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/SchemaType.js
var require_SchemaType = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/SchemaType.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    exports.TypeTags = {
      Any: "Any",
      Binary: "Binary",
      Boolean: "Boolean",
      Collection: "Collection",
      Custom: "Custom",
      Date: "Date",
      Document: "Document",
      Hash: "Hash",
      List: "List",
      Map: "Map",
      Null: "Null",
      Number: "Number",
      Set: "Set",
      String: "String",
      Tuple: "Tuple"
    };
    function isBaseType(arg) {
      return Boolean(arg) && typeof arg === "object" && typeof arg.type === "string" && arg.type in exports.TypeTags && ["string", "undefined"].indexOf(typeof arg.attributeName) > -1;
    }
    exports.KeyTypes = {
      HASH: "HASH",
      RANGE: "RANGE"
    };
    function isKeyableType(arg) {
      var e_1, _a;
      var _b = arg, keyType = _b.keyType, indexKeyConfigurations = _b.indexKeyConfigurations;
      if (!(keyType === void 0 || keyType in exports.KeyTypes)) {
        return false;
      }
      var idxKeysType = typeof indexKeyConfigurations;
      if (indexKeyConfigurations && idxKeysType === "object") {
        try {
          for (var _c = tslib_1.__values(Object.keys(indexKeyConfigurations)), _d = _c.next(); !_d.done; _d = _c.next()) {
            var indexName = _d.value;
            if (!(indexKeyConfigurations[indexName] in exports.KeyTypes)) {
              return false;
            }
          }
        } catch (e_1_1) {
          e_1 = { error: e_1_1 };
        } finally {
          try {
            if (_d && !_d.done && (_a = _c.return))
              _a.call(_c);
          } finally {
            if (e_1)
              throw e_1.error;
          }
        }
        return true;
      }
      return idxKeysType === "undefined";
    }
    function isSchemaType(arg, alreadyVisited) {
      if (alreadyVisited === void 0) {
        alreadyVisited = /* @__PURE__ */ new Set();
      }
      if (isBaseType(arg)) {
        if (alreadyVisited.has(arg)) {
          return true;
        }
        alreadyVisited.add(arg);
        switch (arg.type) {
          case "Binary":
          case "Date":
          case "String":
            return isKeyableType(arg);
          case "Custom":
            return isKeyableType(arg) && typeof arg.marshall === "function" && typeof arg.unmarshall === "function" && [
              void 0,
              "S",
              "N",
              "B"
            ].indexOf(arg.attributeType) > -1;
          case "Document":
            return isDocumentType(arg, alreadyVisited);
          case "List":
          case "Map":
            return isSchemaType(arg.memberType, alreadyVisited);
          case "Number":
            return isKeyableType(arg) && ["boolean", "undefined"].indexOf(typeof arg.versionAttribute) > -1;
          case "Tuple":
            return isTupleType(arg, alreadyVisited);
          default:
            return true;
        }
      }
      return false;
    }
    exports.isSchemaType = isSchemaType;
    function isDocumentType(arg, alreadyVisited) {
      var e_2, _a;
      var _b = arg, valueConstructor = _b.valueConstructor, members = _b.members;
      if (!members || typeof members !== "object") {
        return false;
      }
      try {
        for (var _c = tslib_1.__values(Object.keys(members)), _d = _c.next(); !_d.done; _d = _c.next()) {
          var key = _d.value;
          if (!isSchemaType(members[key], alreadyVisited)) {
            return false;
          }
        }
      } catch (e_2_1) {
        e_2 = { error: e_2_1 };
      } finally {
        try {
          if (_d && !_d.done && (_a = _c.return))
            _a.call(_c);
        } finally {
          if (e_2)
            throw e_2.error;
        }
      }
      return ["function", "undefined"].indexOf(typeof valueConstructor) > -1;
    }
    function isTupleType(arg, alreadyVisited) {
      var e_3, _a;
      var members = arg.members;
      if (!Array.isArray(members)) {
        return false;
      }
      try {
        for (var members_1 = tslib_1.__values(members), members_1_1 = members_1.next(); !members_1_1.done; members_1_1 = members_1.next()) {
          var member = members_1_1.value;
          if (!isSchemaType(member, alreadyVisited)) {
            return false;
          }
        }
      } catch (e_3_1) {
        e_3 = { error: e_3_1 };
      } finally {
        try {
          if (members_1_1 && !members_1_1.done && (_a = members_1.return))
            _a.call(members_1);
        } finally {
          if (e_3)
            throw e_3.error;
        }
      }
      return true;
    }
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/Schema.js
var require_Schema = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/Schema.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var SchemaType_1 = require_SchemaType();
    function isSchema(arg) {
      var e_1, _a;
      if (!Boolean(arg) || typeof arg !== "object") {
        return false;
      }
      try {
        for (var _b = tslib_1.__values(Object.keys(arg)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var key = _c.value;
          if (!SchemaType_1.isSchemaType(arg[key])) {
            return false;
          }
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return true;
    }
    exports.isSchema = isSchema;
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/unmarshallItem.js
var require_unmarshallItem = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/unmarshallItem.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var InvalidSchemaError_1 = require_InvalidSchemaError();
    var dynamodb_auto_marshaller_1 = require_build();
    function unmarshallItem(schema, input, valueConstructor) {
      var e_1, _a;
      var unmarshalled = valueConstructor ? new valueConstructor() : /* @__PURE__ */ Object.create(null);
      try {
        for (var _b = tslib_1.__values(Object.keys(schema)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var key = _c.value;
          var _d = schema[key].attributeName, attributeName = _d === void 0 ? key : _d;
          if (attributeName in input) {
            unmarshalled[key] = unmarshallValue(schema[key], input[attributeName]);
          }
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return unmarshalled;
    }
    exports.unmarshallItem = unmarshallItem;
    function unmarshallValue(schemaType, input) {
      switch (schemaType.type) {
        case "Any":
        case "Collection":
        case "Hash":
          var autoMarshaller = new dynamodb_auto_marshaller_1.Marshaller();
          return autoMarshaller.unmarshallValue(input);
        case "Binary":
          if (input.NULL) {
            return new Uint8Array(0);
          }
          return input.B;
        case "Boolean":
          return input.BOOL;
        case "Custom":
          return schemaType.unmarshall(input);
        case "Date":
          return input.N ? new Date(Number(input.N) * 1e3) : void 0;
        case "Document":
          return input.M ? unmarshallItem(schemaType.members, input.M, schemaType.valueConstructor) : void 0;
        case "List":
          return input.L ? unmarshallList(schemaType, input.L) : void 0;
        case "Map":
          return input.M ? unmarshallMap(schemaType, input.M) : void 0;
        case "Null":
          return input.NULL ? null : void 0;
        case "Number":
          return typeof input.N === "string" ? Number(input.N) : void 0;
        case "Set":
          switch (schemaType.memberType) {
            case "Binary":
              if (input.NULL) {
                return new dynamodb_auto_marshaller_1.BinarySet();
              }
              return typeof input.BS !== "undefined" ? new dynamodb_auto_marshaller_1.BinarySet(input.BS) : void 0;
            case "Number":
              if (input.NULL) {
                return /* @__PURE__ */ new Set();
              }
              return input.NS ? unmarshallNumberSet(input.NS) : void 0;
            case "String":
              if (input.NULL) {
                return /* @__PURE__ */ new Set();
              }
              return input.SS ? unmarshallStringSet(input.SS) : void 0;
            default:
              throw new InvalidSchemaError_1.InvalidSchemaError(schemaType, "Unrecognized set member type: " + schemaType.memberType);
          }
        case "String":
          return input.NULL ? "" : input.S;
        case "Tuple":
          return input.L ? unmarshallTuple(schemaType, input.L) : void 0;
      }
      throw new InvalidSchemaError_1.InvalidSchemaError(schemaType, "Unrecognized schema node");
    }
    function unmarshallList(schemaType, input) {
      var e_2, _a;
      var list = [];
      try {
        for (var input_1 = tslib_1.__values(input), input_1_1 = input_1.next(); !input_1_1.done; input_1_1 = input_1.next()) {
          var element = input_1_1.value;
          list.push(unmarshallValue(schemaType.memberType, element));
        }
      } catch (e_2_1) {
        e_2 = { error: e_2_1 };
      } finally {
        try {
          if (input_1_1 && !input_1_1.done && (_a = input_1.return))
            _a.call(input_1);
        } finally {
          if (e_2)
            throw e_2.error;
        }
      }
      return list;
    }
    function unmarshallMap(schemaType, input) {
      var e_3, _a;
      var map = /* @__PURE__ */ new Map();
      try {
        for (var _b = tslib_1.__values(Object.keys(input)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var key = _c.value;
          map.set(key, unmarshallValue(schemaType.memberType, input[key]));
        }
      } catch (e_3_1) {
        e_3 = { error: e_3_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_3)
            throw e_3.error;
        }
      }
      return map;
    }
    function unmarshallNumberSet(input) {
      var e_4, _a;
      var set = /* @__PURE__ */ new Set();
      try {
        for (var input_2 = tslib_1.__values(input), input_2_1 = input_2.next(); !input_2_1.done; input_2_1 = input_2.next()) {
          var number = input_2_1.value;
          set.add(Number(number));
        }
      } catch (e_4_1) {
        e_4 = { error: e_4_1 };
      } finally {
        try {
          if (input_2_1 && !input_2_1.done && (_a = input_2.return))
            _a.call(input_2);
        } finally {
          if (e_4)
            throw e_4.error;
        }
      }
      return set;
    }
    function unmarshallStringSet(input) {
      var e_5, _a;
      var set = /* @__PURE__ */ new Set();
      try {
        for (var input_3 = tslib_1.__values(input), input_3_1 = input_3.next(); !input_3_1.done; input_3_1 = input_3.next()) {
          var string = input_3_1.value;
          set.add(string);
        }
      } catch (e_5_1) {
        e_5 = { error: e_5_1 };
      } finally {
        try {
          if (input_3_1 && !input_3_1.done && (_a = input_3.return))
            _a.call(input_3);
        } finally {
          if (e_5)
            throw e_5.error;
        }
      }
      return set;
    }
    function unmarshallTuple(schemaType, input) {
      var members = schemaType.members;
      var tuple = [];
      for (var i = 0; i < members.length; i++) {
        tuple.push(unmarshallValue(members[i], input[i]));
      }
      return tuple;
    }
  }
});

// node_modules/@aws/dynamodb-data-marshaller/build/index.js
var require_build3 = __commonJS({
  "node_modules/@aws/dynamodb-data-marshaller/build/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_InvalidSchemaError(), exports);
    tslib_1.__exportStar(require_InvalidValueError(), exports);
    tslib_1.__exportStar(require_isKey(), exports);
    tslib_1.__exportStar(require_keysFromSchema(), exports);
    tslib_1.__exportStar(require_marshallExpression(), exports);
    tslib_1.__exportStar(require_marshallItem(), exports);
    tslib_1.__exportStar(require_marshallKey(), exports);
    tslib_1.__exportStar(require_Schema(), exports);
    tslib_1.__exportStar(require_SchemaType(), exports);
    tslib_1.__exportStar(require_toSchemaName(), exports);
    tslib_1.__exportStar(require_unmarshallItem(), exports);
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/marshallStartKey.js
var require_marshallStartKey = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/marshallStartKey.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var dynamodb_data_marshaller_1 = require_build3();
    function marshallStartKey(schema, startKey) {
      var e_1, _a;
      var key = {};
      try {
        for (var _b = tslib_1.__values(Object.keys(startKey)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var propertyName = _c.value;
          var propSchema = schema[propertyName];
          var _d = propSchema.attributeName, attributeName = _d === void 0 ? propertyName : _d;
          if (propSchema) {
            key[attributeName] = dynamodb_data_marshaller_1.marshallValue(propSchema, startKey[propertyName]);
          }
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return key;
    }
    exports.marshallStartKey = marshallStartKey;
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/protocols.js
var require_protocols = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/protocols.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.DynamoDbSchema = Symbol("DynamoDbSchema");
    function getSchema(item) {
      if (item) {
        var schema = item[exports.DynamoDbSchema];
        if (schema && typeof schema === "object") {
          return schema;
        }
      }
      throw new Error("The provided item did not adhere to the DynamoDbDocument protocol. No object property was found at the `DynamoDbSchema` symbol");
    }
    exports.getSchema = getSchema;
    exports.DynamoDbTable = Symbol("DynamoDbTableName");
    function getTableName(item, tableNamePrefix) {
      if (tableNamePrefix === void 0) {
        tableNamePrefix = "";
      }
      if (item) {
        var tableName = item[exports.DynamoDbTable];
        if (typeof tableName === "string") {
          return tableNamePrefix + tableName;
        }
      }
      throw new Error("The provided item did not adhere to the DynamoDbTable protocol. No string property was found at the `DynamoDbTable` symbol");
    }
    exports.getTableName = getTableName;
    exports.DynamoDbDirtyFields = Symbol("DynamoDbDirtyFields");
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/buildScanInput.js
var require_buildScanInput = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/buildScanInput.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var marshallStartKey_1 = require_marshallStartKey();
    var protocols_1 = require_protocols();
    var dynamodb_data_marshaller_1 = require_build3();
    var dynamodb_expressions_1 = require_build2();
    function buildScanInput(valueConstructor, options) {
      if (options === void 0) {
        options = {};
      }
      var filter = options.filter, indexName = options.indexName, pageSize = options.pageSize, projection = options.projection, readConsistency = options.readConsistency, segment = options.segment, startKey = options.startKey, prefix = options.tableNamePrefix, totalSegments = options.totalSegments;
      var req = {
        TableName: protocols_1.getTableName(valueConstructor.prototype, prefix),
        Limit: pageSize,
        IndexName: indexName,
        Segment: segment,
        TotalSegments: totalSegments
      };
      if (readConsistency === "strong") {
        req.ConsistentRead = true;
      }
      var schema = protocols_1.getSchema(valueConstructor.prototype);
      var attributes = new dynamodb_expressions_1.ExpressionAttributes();
      if (filter) {
        req.FilterExpression = dynamodb_data_marshaller_1.marshallConditionExpression(filter, schema, attributes).expression;
      }
      if (projection) {
        req.ProjectionExpression = dynamodb_data_marshaller_1.marshallProjectionExpression(projection, schema, attributes).expression;
      }
      if (Object.keys(attributes.names).length > 0) {
        req.ExpressionAttributeNames = attributes.names;
      }
      if (Object.keys(attributes.values).length > 0) {
        req.ExpressionAttributeValues = attributes.values;
      }
      if (startKey) {
        req.ExclusiveStartKey = marshallStartKey_1.marshallStartKey(schema, startKey);
      }
      return req;
    }
    exports.buildScanInput = buildScanInput;
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/Paginator.js
var require_Paginator = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/Paginator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var protocols_1 = require_protocols();
    var dynamodb_data_marshaller_1 = require_build3();
    require_asyncIteratorSymbolPolyfill();
    var Paginator = function() {
      function Paginator2(paginator, valueConstructor) {
        this.paginator = paginator;
        this.valueConstructor = valueConstructor;
        this.lastResolved = Promise.resolve();
        this.itemSchema = protocols_1.getSchema(valueConstructor.prototype);
      }
      Paginator2.prototype[Symbol.asyncIterator] = function() {
        return this;
      };
      Paginator2.prototype.next = function() {
        var _this = this;
        this.lastResolved = this.lastResolved.then(function() {
          return _this.getNext();
        });
        return this.lastResolved;
      };
      Paginator2.prototype.return = function() {
        this.lastResolved = Promise.reject(new Error("Iteration has been manually interrupted and may not be resumed"));
        this.lastResolved.catch(function() {
        });
        return this.paginator.return();
      };
      Object.defineProperty(Paginator2.prototype, "consumedCapacity", {
        get: function() {
          return this.paginator.consumedCapacity;
        },
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(Paginator2.prototype, "count", {
        get: function() {
          return this.paginator.count;
        },
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(Paginator2.prototype, "lastEvaluatedKey", {
        get: function() {
          return this.lastKey;
        },
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(Paginator2.prototype, "scannedCount", {
        get: function() {
          return this.paginator.scannedCount;
        },
        enumerable: true,
        configurable: true
      });
      Paginator2.prototype.getNext = function() {
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var _this = this;
          return tslib_1.__generator(this, function(_a) {
            return [2, this.paginator.next().then(function(_a2) {
              var _b = _a2.value, value = _b === void 0 ? {} : _b, done = _a2.done;
              if (!done) {
                _this.lastKey = value.LastEvaluatedKey && dynamodb_data_marshaller_1.unmarshallItem(_this.itemSchema, value.LastEvaluatedKey, _this.valueConstructor);
                return {
                  value: (value.Items || []).map(function(item) {
                    return dynamodb_data_marshaller_1.unmarshallItem(_this.itemSchema, item, _this.valueConstructor);
                  }),
                  done: false
                };
              }
              return { done: true };
            })];
          });
        });
      };
      return Paginator2;
    }();
    exports.Paginator = Paginator;
  }
});

// node_modules/@aws/dynamodb-query-iterator/build/ItemIterator.js
var require_ItemIterator = __commonJS({
  "node_modules/@aws/dynamodb-query-iterator/build/ItemIterator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    if (Symbol && !Symbol.asyncIterator) {
      Symbol.asyncIterator = Symbol.for("__@@asyncIterator__");
    }
    var ItemIterator = function() {
      function ItemIterator2(paginator) {
        this.paginator = paginator;
        this._iteratedCount = 0;
        this.lastResolved = Promise.resolve();
        this.pending = [];
      }
      ItemIterator2.prototype[Symbol.asyncIterator] = function() {
        return this;
      };
      Object.defineProperty(ItemIterator2.prototype, "consumedCapacity", {
        get: function() {
          return this.paginator.consumedCapacity;
        },
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(ItemIterator2.prototype, "count", {
        get: function() {
          return this._iteratedCount;
        },
        enumerable: true,
        configurable: true
      });
      ItemIterator2.prototype.next = function() {
        var _this = this;
        this.lastResolved = this.lastResolved.then(function() {
          return _this.getNext();
        });
        return this.lastResolved;
      };
      ItemIterator2.prototype.pages = function() {
        this.lastResolved = Promise.reject(new Error("The underlying paginator has been detached from this iterator."));
        this.lastResolved.catch(function() {
        });
        return this.paginator;
      };
      ItemIterator2.prototype.return = function() {
        this.lastResolved = Promise.reject(new Error("Iteration has been manually interrupted and may not be resumed"));
        this.lastResolved.catch(function() {
        });
        this.pending.length = 0;
        return this.paginator.return().then(doneSigil);
      };
      Object.defineProperty(ItemIterator2.prototype, "scannedCount", {
        get: function() {
          return this.paginator.scannedCount;
        },
        enumerable: true,
        configurable: true
      });
      ItemIterator2.prototype.getNext = function() {
        var _this = this;
        if (this.pending.length > 0) {
          this._iteratedCount++;
          return Promise.resolve({
            value: this.pending.shift(),
            done: false
          });
        }
        return this.paginator.next().then(function(_a) {
          var done = _a.done, value = _a.value;
          var _b;
          if (done) {
            return { done };
          }
          (_b = _this.pending).push.apply(_b, tslib_1.__spread(value.Items || []));
          return _this.getNext();
        });
      };
      return ItemIterator2;
    }();
    exports.ItemIterator = ItemIterator;
    function doneSigil() {
      return { done: true };
    }
  }
});

// node_modules/@aws/dynamodb-query-iterator/build/mergeConsumedCapacities.js
var require_mergeConsumedCapacities = __commonJS({
  "node_modules/@aws/dynamodb-query-iterator/build/mergeConsumedCapacities.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    function mergeConsumedCapacities(a, b) {
      if (a || b) {
        a = a || {};
        b = b || {};
        if (a.TableName && b.TableName && a.TableName !== b.TableName) {
          throw new Error("Consumed capacity reports may only be merged if they describe the same table");
        }
        return {
          TableName: a.TableName || b.TableName,
          CapacityUnits: (a.CapacityUnits || 0) + (b.CapacityUnits || 0),
          Table: mergeCapacities(a.Table, b.Table),
          LocalSecondaryIndexes: mergeCapacityMaps(a.LocalSecondaryIndexes, b.LocalSecondaryIndexes),
          GlobalSecondaryIndexes: mergeCapacityMaps(a.GlobalSecondaryIndexes, b.GlobalSecondaryIndexes)
        };
      }
    }
    exports.mergeConsumedCapacities = mergeConsumedCapacities;
    function mergeCapacities(a, b) {
      if (a || b) {
        return {
          CapacityUnits: (a && a.CapacityUnits || 0) + (b && b.CapacityUnits || 0)
        };
      }
    }
    function mergeCapacityMaps(a, b) {
      var e_1, _a, e_2, _b, e_3, _c;
      if (a || b) {
        var out = {};
        a = a || {};
        b = b || {};
        var keys = /* @__PURE__ */ new Set();
        try {
          for (var _d = tslib_1.__values([a, b]), _e = _d.next(); !_e.done; _e = _d.next()) {
            var map = _e.value;
            try {
              for (var _f = tslib_1.__values(Object.keys(map)), _g = _f.next(); !_g.done; _g = _f.next()) {
                var indexName = _g.value;
                keys.add(indexName);
              }
            } catch (e_2_1) {
              e_2 = { error: e_2_1 };
            } finally {
              try {
                if (_g && !_g.done && (_b = _f.return))
                  _b.call(_f);
              } finally {
                if (e_2)
                  throw e_2.error;
              }
            }
          }
        } catch (e_1_1) {
          e_1 = { error: e_1_1 };
        } finally {
          try {
            if (_e && !_e.done && (_a = _d.return))
              _a.call(_d);
          } finally {
            if (e_1)
              throw e_1.error;
          }
        }
        try {
          for (var keys_1 = tslib_1.__values(keys), keys_1_1 = keys_1.next(); !keys_1_1.done; keys_1_1 = keys_1.next()) {
            var key = keys_1_1.value;
            out[key] = mergeCapacities(a[key], b[key]);
          }
        } catch (e_3_1) {
          e_3 = { error: e_3_1 };
        } finally {
          try {
            if (keys_1_1 && !keys_1_1.done && (_c = keys_1.return))
              _c.call(keys_1);
          } finally {
            if (e_3)
              throw e_3.error;
          }
        }
        return out;
      }
    }
  }
});

// node_modules/@aws/dynamodb-query-iterator/build/DynamoDbPaginator.js
var require_DynamoDbPaginator = __commonJS({
  "node_modules/@aws/dynamodb-query-iterator/build/DynamoDbPaginator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var mergeConsumedCapacities_1 = require_mergeConsumedCapacities();
    if (Symbol && !Symbol.asyncIterator) {
      Symbol.asyncIterator = Symbol.for("__@@asyncIterator__");
    }
    var DynamoDbPaginator = function() {
      function DynamoDbPaginator2(limit) {
        this.limit = limit;
        this._count = 0;
        this._scannedCount = 0;
        this.lastResolved = Promise.resolve();
      }
      DynamoDbPaginator2.prototype[Symbol.asyncIterator] = function() {
        return this;
      };
      Object.defineProperty(DynamoDbPaginator2.prototype, "consumedCapacity", {
        get: function() {
          return this._consumedCapacity;
        },
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(DynamoDbPaginator2.prototype, "count", {
        get: function() {
          return this._count;
        },
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(DynamoDbPaginator2.prototype, "lastEvaluatedKey", {
        get: function() {
          return this._lastKey;
        },
        enumerable: true,
        configurable: true
      });
      DynamoDbPaginator2.prototype.next = function() {
        var _this = this;
        this.lastResolved = this.lastResolved.then(function() {
          if (_this.count >= (_this.limit === void 0 ? Infinity : _this.limit)) {
            return { done: true };
          }
          return _this.getNext().then(function(_a) {
            var done = _a.done, value = _a.value;
            if (value && !done) {
              _this._lastKey = value.LastEvaluatedKey;
              _this._count += (value.Items || []).length;
              _this._scannedCount += value.ScannedCount || 0;
              _this._consumedCapacity = mergeConsumedCapacities_1.mergeConsumedCapacities(_this._consumedCapacity, value.ConsumedCapacity);
            }
            return { value, done };
          });
        });
        return this.lastResolved;
      };
      DynamoDbPaginator2.prototype.return = function() {
        this.lastResolved = Promise.reject(new Error("Iteration has been manually interrupted and may not be resumed"));
        this.lastResolved.catch(function() {
        });
        return Promise.resolve({ done: true });
      };
      Object.defineProperty(DynamoDbPaginator2.prototype, "scannedCount", {
        get: function() {
          return this._scannedCount;
        },
        enumerable: true,
        configurable: true
      });
      DynamoDbPaginator2.prototype.getNextPageSize = function(requestedPageSize) {
        if (this.limit === void 0) {
          return requestedPageSize;
        }
        return Math.min(requestedPageSize === void 0 ? Infinity : requestedPageSize, this.limit - this.count);
      };
      return DynamoDbPaginator2;
    }();
    exports.DynamoDbPaginator = DynamoDbPaginator;
  }
});

// node_modules/@aws/dynamodb-query-iterator/build/ScanPaginator.js
var require_ScanPaginator = __commonJS({
  "node_modules/@aws/dynamodb-query-iterator/build/ScanPaginator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var DynamoDbPaginator_1 = require_DynamoDbPaginator();
    var ScanPaginator = function(_super) {
      tslib_1.__extends(ScanPaginator2, _super);
      function ScanPaginator2(client, input, limit) {
        var _this = _super.call(this, limit) || this;
        _this.client = client;
        _this.nextRequest = tslib_1.__assign({}, input, { Limit: _this.getNextPageSize(input.Limit) });
        return _this;
      }
      ScanPaginator2.prototype.getNext = function() {
        var _this = this;
        if (this.nextRequest) {
          return this.client.scan(tslib_1.__assign({}, this.nextRequest, { Limit: this.getNextPageSize(this.nextRequest.Limit) })).promise().then(function(output) {
            if (_this.nextRequest && output.LastEvaluatedKey) {
              _this.nextRequest = tslib_1.__assign({}, _this.nextRequest, { ExclusiveStartKey: output.LastEvaluatedKey });
            } else {
              _this.nextRequest = void 0;
            }
            return Promise.resolve({
              value: output,
              done: false
            });
          });
        }
        return Promise.resolve({ done: true });
      };
      return ScanPaginator2;
    }(DynamoDbPaginator_1.DynamoDbPaginator);
    exports.ScanPaginator = ScanPaginator;
  }
});

// node_modules/@aws/dynamodb-query-iterator/build/ParallelScanPaginator.js
var require_ParallelScanPaginator = __commonJS({
  "node_modules/@aws/dynamodb-query-iterator/build/ParallelScanPaginator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var mergeConsumedCapacities_1 = require_mergeConsumedCapacities();
    var ScanPaginator_1 = require_ScanPaginator();
    if (Symbol && !Symbol.asyncIterator) {
      Symbol.asyncIterator = Symbol.for("__@@asyncIterator__");
    }
    var ParallelScanPaginator = function() {
      function ParallelScanPaginator2(client, input, scanState) {
        if (scanState === void 0) {
          scanState = nullScanState(input.TotalSegments);
        }
        this.pending = [];
        this.lastResolved = Promise.resolve();
        var TotalSegments = input.TotalSegments;
        if (scanState.length !== TotalSegments) {
          throw new Error("Parallel scan state must have a length equal to the number of " + ("scan segments. Expected an array of " + TotalSegments + " but") + ("received an array with " + scanState.length + " elements."));
        }
        this.iterators = new Array(TotalSegments);
        for (var i = 0; i < TotalSegments; i++) {
          var iterator = new ScanPaginator_1.ScanPaginator(client, tslib_1.__assign({}, input, { Segment: i, ExclusiveStartKey: scanState[i].LastEvaluatedKey }));
          this.iterators[i] = iterator;
          if (!scanState[i].initialized || scanState[i].LastEvaluatedKey) {
            this.refillPending(iterator, i);
          }
        }
        this._scanState = tslib_1.__spread(scanState);
      }
      ParallelScanPaginator2.prototype[Symbol.asyncIterator] = function() {
        return this;
      };
      Object.defineProperty(ParallelScanPaginator2.prototype, "consumedCapacity", {
        get: function() {
          return this.iterators.reduce(function(merged, paginator) {
            return mergeConsumedCapacities_1.mergeConsumedCapacities(merged, paginator.consumedCapacity);
          }, void 0);
        },
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(ParallelScanPaginator2.prototype, "count", {
        get: function() {
          return this.iterators.reduce(function(sum, paginator) {
            return sum + paginator.count;
          }, 0);
        },
        enumerable: true,
        configurable: true
      });
      ParallelScanPaginator2.prototype.next = function() {
        var _this = this;
        this.lastResolved = this.lastResolved.then(function() {
          return _this.getNext();
        });
        return this.lastResolved;
      };
      ParallelScanPaginator2.prototype.getNext = function() {
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var _a, iterator, _b, value, done, segment, i;
          return tslib_1.__generator(this, function(_c) {
            switch (_c.label) {
              case 0:
                if (this.pending.length === 0) {
                  return [2, doneSigil()];
                }
                return [4, Promise.race(this.pending.map(function(pending) {
                  return pending.result;
                }))];
              case 1:
                _a = _c.sent(), iterator = _a.iterator, _b = _a.result, value = _b.value, done = _b.done, segment = _a.segment;
                this._scanState[segment] = {
                  initialized: true,
                  LastEvaluatedKey: value && value.LastEvaluatedKey
                };
                for (i = this.pending.length - 1; i >= 0; i--) {
                  if (this.pending[i].iterator === iterator) {
                    this.pending.splice(i, 1);
                  }
                }
                if (!done) {
                  this.refillPending(iterator, segment);
                  return [2, { value, done }];
                } else {
                  return [2, this.getNext()];
                }
                return [2];
            }
          });
        });
      };
      ParallelScanPaginator2.prototype.return = function() {
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          return tslib_1.__generator(this, function(_a) {
            this.pending.length = 0;
            return [2, Promise.all(this.iterators.map(function(iterator) {
              return iterator.return();
            })).then(doneSigil)];
          });
        });
      };
      Object.defineProperty(ParallelScanPaginator2.prototype, "scannedCount", {
        get: function() {
          return this.iterators.reduce(function(sum, paginator) {
            return sum + paginator.scannedCount;
          }, 0);
        },
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(ParallelScanPaginator2.prototype, "scanState", {
        get: function() {
          return tslib_1.__spread(this._scanState);
        },
        enumerable: true,
        configurable: true
      });
      ParallelScanPaginator2.prototype.refillPending = function(iterator, segment) {
        this.pending.push({
          iterator,
          result: iterator.next().then(function(result) {
            return { iterator, result, segment };
          })
        });
      };
      return ParallelScanPaginator2;
    }();
    exports.ParallelScanPaginator = ParallelScanPaginator;
    function doneSigil() {
      return { done: true };
    }
    function nullScanState(length) {
      var target = new Array(length);
      for (var i = 0; i < length; i++) {
        target[i] = { initialized: false };
      }
      return target;
    }
  }
});

// node_modules/@aws/dynamodb-query-iterator/build/ParallelScanIterator.js
var require_ParallelScanIterator = __commonJS({
  "node_modules/@aws/dynamodb-query-iterator/build/ParallelScanIterator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var ItemIterator_1 = require_ItemIterator();
    var ParallelScanPaginator_1 = require_ParallelScanPaginator();
    var ParallelScanIterator = function(_super) {
      tslib_1.__extends(ParallelScanIterator2, _super);
      function ParallelScanIterator2(client, input, scanState) {
        return _super.call(this, new ParallelScanPaginator_1.ParallelScanPaginator(client, input, scanState)) || this;
      }
      return ParallelScanIterator2;
    }(ItemIterator_1.ItemIterator);
    exports.ParallelScanIterator = ParallelScanIterator;
  }
});

// node_modules/@aws/dynamodb-query-iterator/build/QueryPaginator.js
var require_QueryPaginator = __commonJS({
  "node_modules/@aws/dynamodb-query-iterator/build/QueryPaginator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var DynamoDbPaginator_1 = require_DynamoDbPaginator();
    var QueryPaginator = function(_super) {
      tslib_1.__extends(QueryPaginator2, _super);
      function QueryPaginator2(client, input, limit) {
        var _this = _super.call(this, limit) || this;
        _this.client = client;
        _this.nextRequest = tslib_1.__assign({}, input);
        return _this;
      }
      QueryPaginator2.prototype.getNext = function() {
        var _this = this;
        if (this.nextRequest) {
          return this.client.query(tslib_1.__assign({}, this.nextRequest, { Limit: this.getNextPageSize(this.nextRequest.Limit) })).promise().then(function(output) {
            if (_this.nextRequest && output.LastEvaluatedKey) {
              _this.nextRequest = tslib_1.__assign({}, _this.nextRequest, { ExclusiveStartKey: output.LastEvaluatedKey });
            } else {
              _this.nextRequest = void 0;
            }
            return Promise.resolve({
              value: output,
              done: false
            });
          });
        }
        return Promise.resolve({ done: true });
      };
      return QueryPaginator2;
    }(DynamoDbPaginator_1.DynamoDbPaginator);
    exports.QueryPaginator = QueryPaginator;
  }
});

// node_modules/@aws/dynamodb-query-iterator/build/QueryIterator.js
var require_QueryIterator = __commonJS({
  "node_modules/@aws/dynamodb-query-iterator/build/QueryIterator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var ItemIterator_1 = require_ItemIterator();
    var QueryPaginator_1 = require_QueryPaginator();
    var QueryIterator = function(_super) {
      tslib_1.__extends(QueryIterator2, _super);
      function QueryIterator2(client, input, limit) {
        return _super.call(this, new QueryPaginator_1.QueryPaginator(client, input, limit)) || this;
      }
      return QueryIterator2;
    }(ItemIterator_1.ItemIterator);
    exports.QueryIterator = QueryIterator;
  }
});

// node_modules/@aws/dynamodb-query-iterator/build/ScanIterator.js
var require_ScanIterator = __commonJS({
  "node_modules/@aws/dynamodb-query-iterator/build/ScanIterator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var ItemIterator_1 = require_ItemIterator();
    var ScanPaginator_1 = require_ScanPaginator();
    var ScanIterator = function(_super) {
      tslib_1.__extends(ScanIterator2, _super);
      function ScanIterator2(client, input, limit) {
        return _super.call(this, new ScanPaginator_1.ScanPaginator(client, input, limit)) || this;
      }
      return ScanIterator2;
    }(ItemIterator_1.ItemIterator);
    exports.ScanIterator = ScanIterator;
  }
});

// node_modules/@aws/dynamodb-query-iterator/build/index.js
var require_build4 = __commonJS({
  "node_modules/@aws/dynamodb-query-iterator/build/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_ParallelScanIterator(), exports);
    tslib_1.__exportStar(require_ParallelScanPaginator(), exports);
    tslib_1.__exportStar(require_QueryIterator(), exports);
    tslib_1.__exportStar(require_QueryPaginator(), exports);
    tslib_1.__exportStar(require_ScanIterator(), exports);
    tslib_1.__exportStar(require_ScanPaginator(), exports);
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/ParallelScanPaginator.js
var require_ParallelScanPaginator2 = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/ParallelScanPaginator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var buildScanInput_1 = require_buildScanInput();
    var Paginator_1 = require_Paginator();
    var protocols_1 = require_protocols();
    var dynamodb_query_iterator_1 = require_build4();
    var dynamodb_data_marshaller_1 = require_build3();
    var ParallelScanPaginator = function(_super) {
      tslib_1.__extends(ParallelScanPaginator2, _super);
      function ParallelScanPaginator2(client, itemConstructor, segments, options) {
        if (options === void 0) {
          options = {};
        }
        var _this = this;
        var schema = protocols_1.getSchema(itemConstructor.prototype);
        var input = tslib_1.__assign({}, buildScanInput_1.buildScanInput(itemConstructor, options), { TotalSegments: segments, ExclusiveStartKey: void 0, Segment: void 0 });
        var scanState;
        if (options.scanState) {
          scanState = options.scanState.map(function(_a) {
            var initialized = _a.initialized, lastKey = _a.lastEvaluatedKey;
            return {
              initialized,
              LastEvaluatedKey: lastKey ? dynamodb_data_marshaller_1.marshallKey(schema, lastKey, options.indexName) : void 0
            };
          });
        }
        var paginator = new dynamodb_query_iterator_1.ParallelScanPaginator(client, input, scanState);
        _this = _super.call(this, paginator, itemConstructor) || this;
        _this._paginator = paginator;
        _this._ctor = itemConstructor;
        _this._schema = schema;
        return _this;
      }
      Object.defineProperty(ParallelScanPaginator2.prototype, "lastEvaluatedKey", {
        get: function() {
          return void 0;
        },
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(ParallelScanPaginator2.prototype, "scanState", {
        get: function() {
          var _this = this;
          return this._paginator.scanState.map(function(_a) {
            var initialized = _a.initialized, LastEvaluatedKey = _a.LastEvaluatedKey;
            return {
              initialized,
              lastEvaluatedKey: LastEvaluatedKey ? dynamodb_data_marshaller_1.unmarshallItem(_this._schema, LastEvaluatedKey, _this._ctor) : void 0
            };
          });
        },
        enumerable: true,
        configurable: true
      });
      return ParallelScanPaginator2;
    }(Paginator_1.Paginator);
    exports.ParallelScanPaginator = ParallelScanPaginator;
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/ParallelScanIterator.js
var require_ParallelScanIterator2 = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/ParallelScanIterator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var Iterator_1 = require_Iterator();
    var ParallelScanPaginator_1 = require_ParallelScanPaginator2();
    var ParallelScanIterator = function(_super) {
      tslib_1.__extends(ParallelScanIterator2, _super);
      function ParallelScanIterator2(client, itemConstructor, segments, options) {
        if (options === void 0) {
          options = {};
        }
        return _super.call(this, new ParallelScanPaginator_1.ParallelScanPaginator(client, itemConstructor, segments, options)) || this;
      }
      return ParallelScanIterator2;
    }(Iterator_1.Iterator);
    exports.ParallelScanIterator = ParallelScanIterator;
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/QueryPaginator.js
var require_QueryPaginator2 = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/QueryPaginator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var marshallStartKey_1 = require_marshallStartKey();
    var Paginator_1 = require_Paginator();
    var protocols_1 = require_protocols();
    var dynamodb_query_iterator_1 = require_build4();
    var dynamodb_data_marshaller_1 = require_build3();
    var dynamodb_expressions_1 = require_build2();
    var QueryPaginator = function(_super) {
      tslib_1.__extends(QueryPaginator2, _super);
      function QueryPaginator2(client, valueConstructor, keyCondition, options) {
        if (options === void 0) {
          options = {};
        }
        var _this = this;
        var itemSchema = protocols_1.getSchema(valueConstructor.prototype);
        var filter = options.filter, indexName = options.indexName, limit = options.limit, pageSize = options.pageSize, projection = options.projection, readConsistency = options.readConsistency, scanIndexForward = options.scanIndexForward, startKey = options.startKey, prefix = options.tableNamePrefix;
        var req = {
          TableName: protocols_1.getTableName(valueConstructor.prototype, prefix),
          ScanIndexForward: scanIndexForward,
          Limit: pageSize,
          IndexName: indexName
        };
        if (readConsistency === "strong") {
          req.ConsistentRead = true;
        }
        var attributes = new dynamodb_expressions_1.ExpressionAttributes();
        req.KeyConditionExpression = dynamodb_data_marshaller_1.marshallConditionExpression(normalizeKeyCondition(keyCondition), itemSchema, attributes).expression;
        if (filter) {
          req.FilterExpression = dynamodb_data_marshaller_1.marshallConditionExpression(filter, itemSchema, attributes).expression;
        }
        if (projection) {
          req.ProjectionExpression = dynamodb_data_marshaller_1.marshallProjectionExpression(projection, itemSchema, attributes).expression;
        }
        if (Object.keys(attributes.names).length > 0) {
          req.ExpressionAttributeNames = attributes.names;
        }
        if (Object.keys(attributes.values).length > 0) {
          req.ExpressionAttributeValues = attributes.values;
        }
        if (startKey) {
          req.ExclusiveStartKey = marshallStartKey_1.marshallStartKey(itemSchema, startKey);
        }
        _this = _super.call(this, new dynamodb_query_iterator_1.QueryPaginator(client, req, limit), valueConstructor) || this;
        return _this;
      }
      return QueryPaginator2;
    }(Paginator_1.Paginator);
    exports.QueryPaginator = QueryPaginator;
    function normalizeKeyCondition(keyCondition) {
      var e_1, _a;
      if (dynamodb_expressions_1.isConditionExpression(keyCondition)) {
        return keyCondition;
      }
      var conditions = [];
      try {
        for (var _b = tslib_1.__values(Object.keys(keyCondition)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var property = _c.value;
          var predicate = keyCondition[property];
          if (dynamodb_expressions_1.isConditionExpressionPredicate(predicate)) {
            conditions.push(tslib_1.__assign({}, predicate, { subject: property }));
          } else {
            conditions.push({
              type: "Equals",
              subject: property,
              object: predicate
            });
          }
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      if (conditions.length === 1) {
        return conditions[0];
      }
      return { type: "And", conditions };
    }
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/QueryIterator.js
var require_QueryIterator2 = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/QueryIterator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var Iterator_1 = require_Iterator();
    var QueryPaginator_1 = require_QueryPaginator2();
    var QueryIterator = function(_super) {
      tslib_1.__extends(QueryIterator2, _super);
      function QueryIterator2(client, valueConstructor, keyCondition, options) {
        return _super.call(this, new QueryPaginator_1.QueryPaginator(client, valueConstructor, keyCondition, options)) || this;
      }
      return QueryIterator2;
    }(Iterator_1.Iterator);
    exports.QueryIterator = QueryIterator;
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/ScanPaginator.js
var require_ScanPaginator2 = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/ScanPaginator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var buildScanInput_1 = require_buildScanInput();
    var Paginator_1 = require_Paginator();
    var dynamodb_query_iterator_1 = require_build4();
    var ScanPaginator = function(_super) {
      tslib_1.__extends(ScanPaginator2, _super);
      function ScanPaginator2(client, itemConstructor, options) {
        if (options === void 0) {
          options = {};
        }
        return _super.call(this, new dynamodb_query_iterator_1.ScanPaginator(client, buildScanInput_1.buildScanInput(itemConstructor, options), options.limit), itemConstructor) || this;
      }
      return ScanPaginator2;
    }(Paginator_1.Paginator);
    exports.ScanPaginator = ScanPaginator;
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/ScanIterator.js
var require_ScanIterator2 = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/ScanIterator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var Iterator_1 = require_Iterator();
    var ScanPaginator_1 = require_ScanPaginator2();
    var ScanIterator = function(_super) {
      tslib_1.__extends(ScanIterator2, _super);
      function ScanIterator2(client, valueConstructor, options) {
        return _super.call(this, new ScanPaginator_1.ScanPaginator(client, valueConstructor, options)) || this;
      }
      return ScanIterator2;
    }(Iterator_1.Iterator);
    exports.ScanIterator = ScanIterator;
  }
});

// node_modules/@aws/dynamodb-batch-iterator/build/BatchOperation.js
var require_BatchOperation = __commonJS({
  "node_modules/@aws/dynamodb-batch-iterator/build/BatchOperation.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    if (Symbol && !Symbol.asyncIterator) {
      Symbol.asyncIterator = Symbol.for("__@@asyncIterator__");
    }
    var BatchOperation = function() {
      function BatchOperation2(client, items) {
        this.client = client;
        this.pending = [];
        this.state = {};
        this.toSend = [];
        this.throttled = /* @__PURE__ */ new Set();
        this.sourceDone = false;
        if (isIterable(items)) {
          this.iterator = items[Symbol.iterator]();
        } else {
          this.iterator = items[Symbol.asyncIterator]();
        }
        this.sourceNext = this.iterator.next();
      }
      BatchOperation2.prototype.next = function() {
        var _this = this;
        if (this.lastResolved) {
          this.lastResolved = this.lastResolved.then(function() {
            return _this.getNext();
          });
        } else {
          this.lastResolved = this.getNext();
        }
        return this.lastResolved;
      };
      BatchOperation2.prototype[Symbol.asyncIterator] = function() {
        return this;
      };
      BatchOperation2.prototype.getInitialTableState = function(tableName) {
        return {
          backoffFactor: 0,
          name: tableName
        };
      };
      BatchOperation2.prototype.handleThrottled = function(tableName, unprocessed) {
        var tableState = this.state[tableName];
        tableState.backoffFactor++;
        if (tableState.tableThrottling) {
          this.throttled.delete(tableState.tableThrottling.backoffWaiter);
          unprocessed.unshift.apply(unprocessed, tslib_1.__spread(tableState.tableThrottling.unprocessed));
        }
        tableState.tableThrottling = {
          unprocessed,
          backoffWaiter: new Promise(function(resolve) {
            setTimeout(resolve, exponentialBackoff(tableState.backoffFactor), tableState);
          })
        };
        this.throttled.add(tableState.tableThrottling.backoffWaiter);
      };
      BatchOperation2.prototype.movePendingToThrottled = function(unprocessedTables) {
        for (var i = this.toSend.length - 1; i > -1; i--) {
          var _a = tslib_1.__read(this.toSend[i], 2), table4 = _a[0], attributes = _a[1];
          if (unprocessedTables.has(table4)) {
            this.state[table4].tableThrottling.unprocessed.push(attributes);
            this.toSend.splice(i, 1);
          }
        }
      };
      BatchOperation2.prototype.addToSendQueue = function(_a) {
        var _b = tslib_1.__read(_a, 2), tableName = _b[0], attributes = _b[1];
        if (!this.state[tableName]) {
          this.state[tableName] = this.getInitialTableState(tableName);
        }
        var tableState = this.state[tableName];
        if (tableState.tableThrottling) {
          tableState.tableThrottling.unprocessed.push(attributes);
        } else {
          this.toSend.push([tableName, attributes]);
        }
      };
      BatchOperation2.prototype.enqueueThrottled = function(table4) {
        var _a;
        var _b = table4.tableThrottling, backoffWaiter = _b.backoffWaiter, unprocessed = _b.unprocessed;
        if (unprocessed.length > 0) {
          (_a = this.toSend).push.apply(_a, tslib_1.__spread(unprocessed.map(function(attr) {
            return [table4.name, attr];
          })));
        }
        this.throttled.delete(backoffWaiter);
        delete table4.tableThrottling;
      };
      BatchOperation2.prototype.getNext = function() {
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          return tslib_1.__generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                if (this.sourceDone && this.pending.length === 0 && this.toSend.length === 0 && this.throttled.size === 0) {
                  return [2, { done: true }];
                }
                if (this.pending.length > 0) {
                  return [2, {
                    done: false,
                    value: this.pending.shift()
                  }];
                }
                return [4, this.refillPending()];
              case 1:
                _a.sent();
                return [2, this.getNext()];
            }
          });
        });
      };
      BatchOperation2.prototype.refillPending = function() {
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var toProcess, _a, _b;
          return tslib_1.__generator(this, function(_c) {
            switch (_c.label) {
              case 0:
                if (!(!this.sourceDone && this.toSend.length < this.batchSize))
                  return [3, 4];
                if (!isIteratorResult(this.sourceNext))
                  return [3, 1];
                _a = this.sourceNext;
                return [3, 3];
              case 1:
                return [4, Promise.race([
                  this.sourceNext,
                  Promise.race(this.throttled)
                ])];
              case 2:
                _a = _c.sent();
                _c.label = 3;
              case 3:
                toProcess = _a;
                if (isIteratorResult(toProcess)) {
                  this.sourceDone = toProcess.done;
                  if (!this.sourceDone) {
                    this.addToSendQueue(toProcess.value);
                    this.sourceNext = this.iterator.next();
                  }
                } else {
                  this.enqueueThrottled(toProcess);
                }
                return [3, 0];
              case 4:
                if (!(this.toSend.length < this.batchSize && this.throttled.size > 0))
                  return [3, 6];
                _b = this.enqueueThrottled;
                return [4, Promise.race(this.throttled)];
              case 5:
                _b.apply(this, [_c.sent()]);
                return [3, 4];
              case 6:
                if (!(this.toSend.length > 0))
                  return [3, 8];
                return [4, this.doBatchRequest()];
              case 7:
                _c.sent();
                _c.label = 8;
              case 8:
                return [2];
            }
          });
        });
      };
      return BatchOperation2;
    }();
    exports.BatchOperation = BatchOperation;
    function exponentialBackoff(attempts) {
      return Math.floor(Math.random() * Math.pow(2, attempts));
    }
    function isIterable(arg) {
      return Boolean(arg) && typeof arg[Symbol.iterator] === "function";
    }
    function isIteratorResult(arg) {
      return Boolean(arg) && typeof arg.done === "boolean";
    }
  }
});

// node_modules/@aws/dynamodb-batch-iterator/build/BatchGet.js
var require_BatchGet = __commonJS({
  "node_modules/@aws/dynamodb-batch-iterator/build/BatchGet.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var BatchOperation_1 = require_BatchOperation();
    exports.MAX_READ_BATCH_SIZE = 100;
    var BatchGet = function(_super) {
      tslib_1.__extends(BatchGet2, _super);
      function BatchGet2(client, items, _a) {
        var _b = _a === void 0 ? {} : _a, ConsistentRead = _b.ConsistentRead, _c = _b.PerTableOptions, PerTableOptions = _c === void 0 ? {} : _c;
        var _this = _super.call(this, client, items) || this;
        _this.batchSize = exports.MAX_READ_BATCH_SIZE;
        _this.consistentRead = ConsistentRead;
        _this.options = PerTableOptions;
        return _this;
      }
      BatchGet2.prototype.doBatchRequest = function() {
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var e_1, _a, e_2, _b, e_3, _c, operationInput, batchSize, _d, tableName, item, _e, projection, consistentRead, attributeNames, _f, _g, Responses, _h, UnprocessedKeys, unprocessedTables, _j, _k, table4, _l, _m, table4, tableData, _o, _p, item;
          return tslib_1.__generator(this, function(_q) {
            switch (_q.label) {
              case 0:
                operationInput = { RequestItems: {} };
                batchSize = 0;
                while (this.toSend.length > 0) {
                  _d = tslib_1.__read(this.toSend.shift(), 2), tableName = _d[0], item = _d[1];
                  if (operationInput.RequestItems[tableName] === void 0) {
                    _e = this.state[tableName], projection = _e.projection, consistentRead = _e.consistentRead, attributeNames = _e.attributeNames;
                    operationInput.RequestItems[tableName] = {
                      Keys: [],
                      ConsistentRead: consistentRead,
                      ProjectionExpression: projection,
                      ExpressionAttributeNames: attributeNames
                    };
                  }
                  operationInput.RequestItems[tableName].Keys.push(item);
                  if (++batchSize === this.batchSize) {
                    break;
                  }
                }
                return [4, this.client.batchGetItem(operationInput).promise()];
              case 1:
                _f = _q.sent(), _g = _f.Responses, Responses = _g === void 0 ? {} : _g, _h = _f.UnprocessedKeys, UnprocessedKeys = _h === void 0 ? {} : _h;
                unprocessedTables = /* @__PURE__ */ new Set();
                try {
                  for (_j = tslib_1.__values(Object.keys(UnprocessedKeys)), _k = _j.next(); !_k.done; _k = _j.next()) {
                    table4 = _k.value;
                    unprocessedTables.add(table4);
                    this.handleThrottled(table4, UnprocessedKeys[table4].Keys);
                  }
                } catch (e_1_1) {
                  e_1 = { error: e_1_1 };
                } finally {
                  try {
                    if (_k && !_k.done && (_a = _j.return))
                      _a.call(_j);
                  } finally {
                    if (e_1)
                      throw e_1.error;
                  }
                }
                this.movePendingToThrottled(unprocessedTables);
                try {
                  for (_l = tslib_1.__values(Object.keys(Responses)), _m = _l.next(); !_m.done; _m = _l.next()) {
                    table4 = _m.value;
                    tableData = this.state[table4];
                    tableData.backoffFactor = Math.max(0, tableData.backoffFactor - 1);
                    try {
                      for (_o = tslib_1.__values(Responses[table4]), _p = _o.next(); !_p.done; _p = _o.next()) {
                        item = _p.value;
                        this.pending.push([table4, item]);
                      }
                    } catch (e_3_1) {
                      e_3 = { error: e_3_1 };
                    } finally {
                      try {
                        if (_p && !_p.done && (_c = _o.return))
                          _c.call(_o);
                      } finally {
                        if (e_3)
                          throw e_3.error;
                      }
                    }
                  }
                } catch (e_2_1) {
                  e_2 = { error: e_2_1 };
                } finally {
                  try {
                    if (_m && !_m.done && (_b = _l.return))
                      _b.call(_l);
                  } finally {
                    if (e_2)
                      throw e_2.error;
                  }
                }
                return [2];
            }
          });
        });
      };
      BatchGet2.prototype.getInitialTableState = function(tableName) {
        var _a = this.options[tableName] || {}, ExpressionAttributeNames = _a.ExpressionAttributeNames, ProjectionExpression = _a.ProjectionExpression, _b = _a.ConsistentRead, ConsistentRead = _b === void 0 ? this.consistentRead : _b;
        return tslib_1.__assign({}, _super.prototype.getInitialTableState.call(this, tableName), { attributeNames: ExpressionAttributeNames, projection: ProjectionExpression, consistentRead: ConsistentRead });
      };
      return BatchGet2;
    }(BatchOperation_1.BatchOperation);
    exports.BatchGet = BatchGet;
  }
});

// node_modules/@aws/dynamodb-batch-iterator/build/itemIdentifier.js
var require_itemIdentifier = __commonJS({
  "node_modules/@aws/dynamodb-batch-iterator/build/itemIdentifier.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var bytes = require_utf8_bytes();
    function itemIdentifier(tableName, _a) {
      var DeleteRequest = _a.DeleteRequest, PutRequest = _a.PutRequest;
      if (DeleteRequest) {
        return tableName + "::delete::" + serializeKeyTypeAttributes(DeleteRequest.Key);
      } else if (PutRequest) {
        return tableName + "::put::" + serializeKeyTypeAttributes(PutRequest.Item);
      }
      throw new Error("Invalid write request provided");
    }
    exports.itemIdentifier = itemIdentifier;
    function serializeKeyTypeAttributes(attributes) {
      var e_1, _a;
      var keyTypeProperties = [];
      try {
        for (var _b = tslib_1.__values(Object.keys(attributes).sort()), _c = _b.next(); !_c.done; _c = _b.next()) {
          var property = _c.value;
          var attribute3 = attributes[property];
          if (attribute3.B) {
            keyTypeProperties.push(property + "=" + toByteArray(attribute3.B));
          } else if (attribute3.N) {
            keyTypeProperties.push(property + "=" + attribute3.N);
          } else if (attribute3.S) {
            keyTypeProperties.push(property + "=" + attribute3.S);
          }
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return keyTypeProperties.join("&");
    }
    function toByteArray(value) {
      if (ArrayBuffer.isView(value)) {
        return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
      }
      if (typeof value === "string") {
        return Uint8Array.from(bytes(value));
      }
      if (isArrayBuffer(value)) {
        return new Uint8Array(value);
      }
      throw new Error("Unrecognized binary type");
    }
    function isArrayBuffer(arg) {
      return typeof ArrayBuffer === "function" && arg instanceof ArrayBuffer || Object.prototype.toString.call(arg) === "[object ArrayBuffer]";
    }
  }
});

// node_modules/@aws/dynamodb-batch-iterator/build/BatchWrite.js
var require_BatchWrite = __commonJS({
  "node_modules/@aws/dynamodb-batch-iterator/build/BatchWrite.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var BatchOperation_1 = require_BatchOperation();
    var itemIdentifier_1 = require_itemIdentifier();
    exports.MAX_WRITE_BATCH_SIZE = 25;
    var BatchWrite = function(_super) {
      tslib_1.__extends(BatchWrite2, _super);
      function BatchWrite2() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.batchSize = exports.MAX_WRITE_BATCH_SIZE;
        return _this;
      }
      BatchWrite2.prototype.doBatchRequest = function() {
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var e_1, _a, e_2, _b, e_3, _c, e_4, _d, inFlight, operationInput, batchSize, _e, tableName, marshalled, _f, UnprocessedItems, unprocessedTables, _g, _h, table4, unprocessed, _j, _k, item, identifier, i, _l, tableName, attributes, processedTables, inFlight_1, inFlight_1_1, _m, tableName, marshalled, processedTables_1, processedTables_1_1, tableName;
          return tslib_1.__generator(this, function(_o) {
            switch (_o.label) {
              case 0:
                inFlight = [];
                operationInput = { RequestItems: {} };
                batchSize = 0;
                while (this.toSend.length > 0) {
                  _e = tslib_1.__read(this.toSend.shift(), 2), tableName = _e[0], marshalled = _e[1];
                  inFlight.push([tableName, marshalled]);
                  if (operationInput.RequestItems[tableName] === void 0) {
                    operationInput.RequestItems[tableName] = [];
                  }
                  operationInput.RequestItems[tableName].push(marshalled);
                  if (++batchSize === this.batchSize) {
                    break;
                  }
                }
                return [4, this.client.batchWriteItem(operationInput).promise()];
              case 1:
                _f = _o.sent().UnprocessedItems, UnprocessedItems = _f === void 0 ? {} : _f;
                unprocessedTables = /* @__PURE__ */ new Set();
                try {
                  for (_g = tslib_1.__values(Object.keys(UnprocessedItems)), _h = _g.next(); !_h.done; _h = _g.next()) {
                    table4 = _h.value;
                    unprocessedTables.add(table4);
                    unprocessed = [];
                    try {
                      for (_j = tslib_1.__values(UnprocessedItems[table4]), _k = _j.next(); !_k.done; _k = _j.next()) {
                        item = _k.value;
                        if (item.DeleteRequest || item.PutRequest) {
                          unprocessed.push(item);
                          identifier = itemIdentifier_1.itemIdentifier(table4, item);
                          for (i = inFlight.length - 1; i >= 0; i--) {
                            _l = tslib_1.__read(inFlight[i], 2), tableName = _l[0], attributes = _l[1];
                            if (tableName === table4 && itemIdentifier_1.itemIdentifier(tableName, attributes) === identifier) {
                              inFlight.splice(i, 1);
                            }
                          }
                        }
                      }
                    } catch (e_2_1) {
                      e_2 = { error: e_2_1 };
                    } finally {
                      try {
                        if (_k && !_k.done && (_b = _j.return))
                          _b.call(_j);
                      } finally {
                        if (e_2)
                          throw e_2.error;
                      }
                    }
                    this.handleThrottled(table4, unprocessed);
                  }
                } catch (e_1_1) {
                  e_1 = { error: e_1_1 };
                } finally {
                  try {
                    if (_h && !_h.done && (_a = _g.return))
                      _a.call(_g);
                  } finally {
                    if (e_1)
                      throw e_1.error;
                  }
                }
                this.movePendingToThrottled(unprocessedTables);
                processedTables = /* @__PURE__ */ new Set();
                try {
                  for (inFlight_1 = tslib_1.__values(inFlight), inFlight_1_1 = inFlight_1.next(); !inFlight_1_1.done; inFlight_1_1 = inFlight_1.next()) {
                    _m = tslib_1.__read(inFlight_1_1.value, 2), tableName = _m[0], marshalled = _m[1];
                    processedTables.add(tableName);
                    this.pending.push([tableName, marshalled]);
                  }
                } catch (e_3_1) {
                  e_3 = { error: e_3_1 };
                } finally {
                  try {
                    if (inFlight_1_1 && !inFlight_1_1.done && (_c = inFlight_1.return))
                      _c.call(inFlight_1);
                  } finally {
                    if (e_3)
                      throw e_3.error;
                  }
                }
                try {
                  for (processedTables_1 = tslib_1.__values(processedTables), processedTables_1_1 = processedTables_1.next(); !processedTables_1_1.done; processedTables_1_1 = processedTables_1.next()) {
                    tableName = processedTables_1_1.value;
                    this.state[tableName].backoffFactor = Math.max(0, this.state[tableName].backoffFactor - 1);
                  }
                } catch (e_4_1) {
                  e_4 = { error: e_4_1 };
                } finally {
                  try {
                    if (processedTables_1_1 && !processedTables_1_1.done && (_d = processedTables_1.return))
                      _d.call(processedTables_1);
                  } finally {
                    if (e_4)
                      throw e_4.error;
                  }
                }
                return [2];
            }
          });
        });
      };
      return BatchWrite2;
    }(BatchOperation_1.BatchOperation);
    exports.BatchWrite = BatchWrite;
  }
});

// node_modules/@aws/dynamodb-batch-iterator/build/index.js
var require_build5 = __commonJS({
  "node_modules/@aws/dynamodb-batch-iterator/build/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_BatchGet(), exports);
    tslib_1.__exportStar(require_BatchWrite(), exports);
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/DataMapper.js
var require_DataMapper = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/DataMapper.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var constants_1 = require_constants();
    var ItemNotFoundException_1 = require_ItemNotFoundException();
    var ParallelScanIterator_1 = require_ParallelScanIterator2();
    var protocols_1 = require_protocols();
    var QueryIterator_1 = require_QueryIterator2();
    var ScanIterator_1 = require_ScanIterator2();
    var dynamodb_batch_iterator_1 = require_build5();
    var dynamodb_data_marshaller_1 = require_build3();
    var dynamodb_expressions_1 = require_build2();
    require_asyncIteratorSymbolPolyfill();
    var DataMapper2 = function() {
      function DataMapper3(_a) {
        var client = _a.client, _b = _a.readConsistency, readConsistency = _b === void 0 ? "eventual" : _b, _c = _a.skipVersionCheck, skipVersionCheck = _c === void 0 ? false : _c, _d = _a.tableNamePrefix, tableNamePrefix = _d === void 0 ? "" : _d;
        client.config.customUserAgent = " dynamodb-data-mapper-js/" + constants_1.VERSION;
        this.client = client;
        this.readConsistency = readConsistency;
        this.skipVersionCheck = skipVersionCheck;
        this.tableNamePrefix = tableNamePrefix;
      }
      DataMapper3.prototype.batchDelete = function(items) {
        return tslib_1.__asyncGenerator(this, arguments, function batchDelete_1() {
          var e_1, _a, iter, iter_1, iter_1_1, written, e_1_1;
          return tslib_1.__generator(this, function(_b) {
            switch (_b.label) {
              case 0:
                iter = this.batchWrite(function mapToDelete() {
                  return tslib_1.__asyncGenerator(this, arguments, function mapToDelete_1() {
                    var e_2, _a2, items_1, items_1_1, item, e_2_1;
                    return tslib_1.__generator(this, function(_b2) {
                      switch (_b2.label) {
                        case 0:
                          _b2.trys.push([0, 7, 8, 13]);
                          items_1 = tslib_1.__asyncValues(items);
                          _b2.label = 1;
                        case 1:
                          return [4, tslib_1.__await(items_1.next())];
                        case 2:
                          if (!(items_1_1 = _b2.sent(), !items_1_1.done))
                            return [3, 6];
                          item = items_1_1.value;
                          return [4, tslib_1.__await(["delete", item])];
                        case 3:
                          return [4, _b2.sent()];
                        case 4:
                          _b2.sent();
                          _b2.label = 5;
                        case 5:
                          return [3, 1];
                        case 6:
                          return [3, 13];
                        case 7:
                          e_2_1 = _b2.sent();
                          e_2 = { error: e_2_1 };
                          return [3, 13];
                        case 8:
                          _b2.trys.push([8, , 11, 12]);
                          if (!(items_1_1 && !items_1_1.done && (_a2 = items_1.return)))
                            return [3, 10];
                          return [4, tslib_1.__await(_a2.call(items_1))];
                        case 9:
                          _b2.sent();
                          _b2.label = 10;
                        case 10:
                          return [3, 12];
                        case 11:
                          if (e_2)
                            throw e_2.error;
                          return [7];
                        case 12:
                          return [7];
                        case 13:
                          return [2];
                      }
                    });
                  });
                }());
                _b.label = 1;
              case 1:
                _b.trys.push([1, 8, 9, 14]);
                iter_1 = tslib_1.__asyncValues(iter);
                _b.label = 2;
              case 2:
                return [4, tslib_1.__await(iter_1.next())];
              case 3:
                if (!(iter_1_1 = _b.sent(), !iter_1_1.done))
                  return [3, 7];
                written = iter_1_1.value;
                return [4, tslib_1.__await(written[1])];
              case 4:
                return [4, _b.sent()];
              case 5:
                _b.sent();
                _b.label = 6;
              case 6:
                return [3, 2];
              case 7:
                return [3, 14];
              case 8:
                e_1_1 = _b.sent();
                e_1 = { error: e_1_1 };
                return [3, 14];
              case 9:
                _b.trys.push([9, , 12, 13]);
                if (!(iter_1_1 && !iter_1_1.done && (_a = iter_1.return)))
                  return [3, 11];
                return [4, tslib_1.__await(_a.call(iter_1))];
              case 10:
                _b.sent();
                _b.label = 11;
              case 11:
                return [3, 13];
              case 12:
                if (e_1)
                  throw e_1.error;
                return [7];
              case 13:
                return [7];
              case 14:
                return [2];
            }
          });
        });
      };
      DataMapper3.prototype.batchGet = function(items, _a) {
        var _b = _a === void 0 ? {} : _a, _c = _b.readConsistency, readConsistency = _c === void 0 ? this.readConsistency : _c, _d = _b.perTableOptions, perTableOptions = _d === void 0 ? {} : _d;
        return tslib_1.__asyncGenerator(this, arguments, function batchGet_1() {
          var e_3, _a2, state, options, batch, batch_1, batch_1_1, _b2, tableName, marshalled, _c2, keyProperties, itemSchemata, _d2, constructor, schema, e_3_1;
          return tslib_1.__generator(this, function(_e) {
            switch (_e.label) {
              case 0:
                state = {};
                options = {};
                batch = new dynamodb_batch_iterator_1.BatchGet(this.client, this.mapGetBatch(items, state, perTableOptions, options), {
                  ConsistentRead: readConsistency === "strong" ? true : void 0,
                  PerTableOptions: options
                });
                _e.label = 1;
              case 1:
                _e.trys.push([1, 8, 9, 14]);
                batch_1 = tslib_1.__asyncValues(batch);
                _e.label = 2;
              case 2:
                return [4, tslib_1.__await(batch_1.next())];
              case 3:
                if (!(batch_1_1 = _e.sent(), !batch_1_1.done))
                  return [3, 7];
                _b2 = tslib_1.__read(batch_1_1.value, 2), tableName = _b2[0], marshalled = _b2[1];
                _c2 = state[tableName], keyProperties = _c2.keyProperties, itemSchemata = _c2.itemSchemata;
                _d2 = itemSchemata[itemIdentifier(marshalled, keyProperties)], constructor = _d2.constructor, schema = _d2.schema;
                return [4, tslib_1.__await(dynamodb_data_marshaller_1.unmarshallItem(schema, marshalled, constructor))];
              case 4:
                return [4, _e.sent()];
              case 5:
                _e.sent();
                _e.label = 6;
              case 6:
                return [3, 2];
              case 7:
                return [3, 14];
              case 8:
                e_3_1 = _e.sent();
                e_3 = { error: e_3_1 };
                return [3, 14];
              case 9:
                _e.trys.push([9, , 12, 13]);
                if (!(batch_1_1 && !batch_1_1.done && (_a2 = batch_1.return)))
                  return [3, 11];
                return [4, tslib_1.__await(_a2.call(batch_1))];
              case 10:
                _e.sent();
                _e.label = 11;
              case 11:
                return [3, 13];
              case 12:
                if (e_3)
                  throw e_3.error;
                return [7];
              case 13:
                return [7];
              case 14:
                return [2];
            }
          });
        });
      };
      DataMapper3.prototype.batchPut = function(items) {
        return tslib_1.__asyncGenerator(this, arguments, function batchPut_1() {
          var e_4, _a, generator, _b, _c, written, e_4_1;
          return tslib_1.__generator(this, function(_d) {
            switch (_d.label) {
              case 0:
                generator = isIterable(items) ? function mapToPut() {
                  var e_5, _a2, items_2, items_2_1, item, e_5_1;
                  return tslib_1.__generator(this, function(_b2) {
                    switch (_b2.label) {
                      case 0:
                        _b2.trys.push([0, 5, 6, 7]);
                        items_2 = tslib_1.__values(items), items_2_1 = items_2.next();
                        _b2.label = 1;
                      case 1:
                        if (!!items_2_1.done)
                          return [3, 4];
                        item = items_2_1.value;
                        return [4, ["put", item]];
                      case 2:
                        _b2.sent();
                        _b2.label = 3;
                      case 3:
                        items_2_1 = items_2.next();
                        return [3, 1];
                      case 4:
                        return [3, 7];
                      case 5:
                        e_5_1 = _b2.sent();
                        e_5 = { error: e_5_1 };
                        return [3, 7];
                      case 6:
                        try {
                          if (items_2_1 && !items_2_1.done && (_a2 = items_2.return))
                            _a2.call(items_2);
                        } finally {
                          if (e_5)
                            throw e_5.error;
                        }
                        return [7];
                      case 7:
                        return [2];
                    }
                  });
                }() : function mapToPut() {
                  return tslib_1.__asyncGenerator(this, arguments, function mapToPut_1() {
                    var e_6, _a2, items_3, items_3_1, item, e_6_1;
                    return tslib_1.__generator(this, function(_b2) {
                      switch (_b2.label) {
                        case 0:
                          _b2.trys.push([0, 7, 8, 13]);
                          items_3 = tslib_1.__asyncValues(items);
                          _b2.label = 1;
                        case 1:
                          return [4, tslib_1.__await(items_3.next())];
                        case 2:
                          if (!(items_3_1 = _b2.sent(), !items_3_1.done))
                            return [3, 6];
                          item = items_3_1.value;
                          return [4, tslib_1.__await(["put", item])];
                        case 3:
                          return [4, _b2.sent()];
                        case 4:
                          _b2.sent();
                          _b2.label = 5;
                        case 5:
                          return [3, 1];
                        case 6:
                          return [3, 13];
                        case 7:
                          e_6_1 = _b2.sent();
                          e_6 = { error: e_6_1 };
                          return [3, 13];
                        case 8:
                          _b2.trys.push([8, , 11, 12]);
                          if (!(items_3_1 && !items_3_1.done && (_a2 = items_3.return)))
                            return [3, 10];
                          return [4, tslib_1.__await(_a2.call(items_3))];
                        case 9:
                          _b2.sent();
                          _b2.label = 10;
                        case 10:
                          return [3, 12];
                        case 11:
                          if (e_6)
                            throw e_6.error;
                          return [7];
                        case 12:
                          return [7];
                        case 13:
                          return [2];
                      }
                    });
                  });
                }();
                _d.label = 1;
              case 1:
                _d.trys.push([1, 8, 9, 14]);
                _b = tslib_1.__asyncValues(this.batchWrite(generator));
                _d.label = 2;
              case 2:
                return [4, tslib_1.__await(_b.next())];
              case 3:
                if (!(_c = _d.sent(), !_c.done))
                  return [3, 7];
                written = _c.value;
                return [4, tslib_1.__await(written[1])];
              case 4:
                return [4, _d.sent()];
              case 5:
                _d.sent();
                _d.label = 6;
              case 6:
                return [3, 2];
              case 7:
                return [3, 14];
              case 8:
                e_4_1 = _d.sent();
                e_4 = { error: e_4_1 };
                return [3, 14];
              case 9:
                _d.trys.push([9, , 12, 13]);
                if (!(_c && !_c.done && (_a = _b.return)))
                  return [3, 11];
                return [4, tslib_1.__await(_a.call(_b))];
              case 10:
                _d.sent();
                _d.label = 11;
              case 11:
                return [3, 13];
              case 12:
                if (e_4)
                  throw e_4.error;
                return [7];
              case 13:
                return [7];
              case 14:
                return [2];
            }
          });
        });
      };
      DataMapper3.prototype.batchWrite = function(items) {
        return tslib_1.__asyncGenerator(this, arguments, function batchWrite_1() {
          var e_7, _a, state, batch, batch_2, batch_2_1, _b, tableName, _c, DeleteRequest, PutRequest, _d, keyProperties, itemSchemata, attributes, _e, constructor, schema, e_7_1;
          return tslib_1.__generator(this, function(_f) {
            switch (_f.label) {
              case 0:
                state = {};
                batch = new dynamodb_batch_iterator_1.BatchWrite(this.client, this.mapWriteBatch(items, state));
                _f.label = 1;
              case 1:
                _f.trys.push([1, 8, 9, 14]);
                batch_2 = tslib_1.__asyncValues(batch);
                _f.label = 2;
              case 2:
                return [4, tslib_1.__await(batch_2.next())];
              case 3:
                if (!(batch_2_1 = _f.sent(), !batch_2_1.done))
                  return [3, 7];
                _b = tslib_1.__read(batch_2_1.value, 2), tableName = _b[0], _c = _b[1], DeleteRequest = _c.DeleteRequest, PutRequest = _c.PutRequest;
                _d = state[tableName], keyProperties = _d.keyProperties, itemSchemata = _d.itemSchemata;
                attributes = PutRequest ? PutRequest.Item : (DeleteRequest || { Key: {} }).Key;
                _e = itemSchemata[itemIdentifier(attributes, keyProperties)], constructor = _e.constructor, schema = _e.schema;
                return [4, tslib_1.__await([
                  PutRequest ? "put" : "delete",
                  dynamodb_data_marshaller_1.unmarshallItem(schema, attributes, constructor)
                ])];
              case 4:
                return [4, _f.sent()];
              case 5:
                _f.sent();
                _f.label = 6;
              case 6:
                return [3, 2];
              case 7:
                return [3, 14];
              case 8:
                e_7_1 = _f.sent();
                e_7 = { error: e_7_1 };
                return [3, 14];
              case 9:
                _f.trys.push([9, , 12, 13]);
                if (!(batch_2_1 && !batch_2_1.done && (_a = batch_2.return)))
                  return [3, 11];
                return [4, tslib_1.__await(_a.call(batch_2))];
              case 10:
                _f.sent();
                _f.label = 11;
              case 11:
                return [3, 13];
              case 12:
                if (e_7)
                  throw e_7.error;
                return [7];
              case 13:
                return [7];
              case 14:
                return [2];
            }
          });
        });
      };
      DataMapper3.prototype.createTable = function(valueConstructor, _a) {
        var readCapacityUnits = _a.readCapacityUnits, _b = _a.streamViewType, streamViewType = _b === void 0 ? "NONE" : _b, writeCapacityUnits = _a.writeCapacityUnits, _c = _a.indexOptions, indexOptions = _c === void 0 ? {} : _c;
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var schema, _d, attributes, indexKeys, tableKeys, TableName, _e, TableStatus;
          return tslib_1.__generator(this, function(_f) {
            switch (_f.label) {
              case 0:
                schema = protocols_1.getSchema(valueConstructor.prototype);
                _d = dynamodb_data_marshaller_1.keysFromSchema(schema), attributes = _d.attributes, indexKeys = _d.indexKeys, tableKeys = _d.tableKeys;
                TableName = this.getTableName(valueConstructor.prototype);
                return [4, this.client.createTable(tslib_1.__assign({}, indexDefinitions(indexKeys, indexOptions, schema), { TableName, ProvisionedThroughput: {
                  ReadCapacityUnits: readCapacityUnits,
                  WriteCapacityUnits: writeCapacityUnits
                }, AttributeDefinitions: attributeDefinitionList(attributes), KeySchema: keyTypesToElementList(tableKeys), StreamSpecification: streamViewType === "NONE" ? { StreamEnabled: false } : { StreamEnabled: true, StreamViewType: streamViewType } })).promise()];
              case 1:
                _e = _f.sent().TableDescription, TableStatus = (_e === void 0 ? { TableStatus: "CREATING" } : _e).TableStatus;
                if (!(TableStatus !== "ACTIVE"))
                  return [3, 3];
                return [4, this.client.waitFor("tableExists", { TableName }).promise()];
              case 2:
                _f.sent();
                _f.label = 3;
              case 3:
                return [2];
            }
          });
        });
      };
      DataMapper3.prototype.delete = function(itemOrParameters, options) {
        if (options === void 0) {
          options = {};
        }
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var e_8, _a, item, condition, _b, returnValues, _c, skipVersionCheck, schema, req, _d, _e, prop, inputMember, fieldSchema, versionCondition, attributes, Attributes;
          return tslib_1.__generator(this, function(_f) {
            switch (_f.label) {
              case 0:
                if ("item" in itemOrParameters && itemOrParameters.item[protocols_1.DynamoDbTable]) {
                  item = itemOrParameters.item;
                  options = itemOrParameters;
                } else {
                  item = itemOrParameters;
                }
                condition = options.condition, _b = options.returnValues, returnValues = _b === void 0 ? "ALL_OLD" : _b, _c = options.skipVersionCheck, skipVersionCheck = _c === void 0 ? this.skipVersionCheck : _c;
                schema = protocols_1.getSchema(item);
                req = {
                  TableName: this.getTableName(item),
                  Key: dynamodb_data_marshaller_1.marshallKey(schema, item),
                  ReturnValues: returnValues
                };
                if (!skipVersionCheck) {
                  try {
                    for (_d = tslib_1.__values(Object.keys(schema)), _e = _d.next(); !_e.done; _e = _d.next()) {
                      prop = _e.value;
                      inputMember = item[prop];
                      fieldSchema = schema[prop];
                      if (isVersionAttribute(fieldSchema) && inputMember !== void 0) {
                        versionCondition = handleVersionAttribute(prop, inputMember).condition;
                        condition = condition ? { type: "And", conditions: [condition, versionCondition] } : versionCondition;
                      }
                    }
                  } catch (e_8_1) {
                    e_8 = { error: e_8_1 };
                  } finally {
                    try {
                      if (_e && !_e.done && (_a = _d.return))
                        _a.call(_d);
                    } finally {
                      if (e_8)
                        throw e_8.error;
                    }
                  }
                }
                if (condition) {
                  attributes = new dynamodb_expressions_1.ExpressionAttributes();
                  req.ConditionExpression = dynamodb_data_marshaller_1.marshallConditionExpression(condition, schema, attributes).expression;
                  if (Object.keys(attributes.names).length > 0) {
                    req.ExpressionAttributeNames = attributes.names;
                  }
                  if (Object.keys(attributes.values).length > 0) {
                    req.ExpressionAttributeValues = attributes.values;
                  }
                }
                return [4, this.client.deleteItem(req).promise()];
              case 1:
                Attributes = _f.sent().Attributes;
                if (Attributes) {
                  return [2, dynamodb_data_marshaller_1.unmarshallItem(schema, Attributes, item.constructor)];
                }
                return [2];
            }
          });
        });
      };
      DataMapper3.prototype.deleteTable = function(valueConstructor) {
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var TableName;
          return tslib_1.__generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                TableName = this.getTableName(valueConstructor.prototype);
                return [4, this.client.deleteTable({ TableName }).promise()];
              case 1:
                _a.sent();
                return [4, this.client.waitFor("tableNotExists", { TableName }).promise()];
              case 2:
                _a.sent();
                return [2];
            }
          });
        });
      };
      DataMapper3.prototype.ensureTableExists = function(valueConstructor, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var TableName, _a, TableStatus, err_1;
          return tslib_1.__generator(this, function(_b) {
            switch (_b.label) {
              case 0:
                TableName = this.getTableName(valueConstructor.prototype);
                _b.label = 1;
              case 1:
                _b.trys.push([1, 5, , 9]);
                return [4, this.client.describeTable({ TableName }).promise()];
              case 2:
                _a = _b.sent().Table, TableStatus = (_a === void 0 ? { TableStatus: "CREATING" } : _a).TableStatus;
                if (!(TableStatus !== "ACTIVE"))
                  return [3, 4];
                return [4, this.client.waitFor("tableExists", { TableName }).promise()];
              case 3:
                _b.sent();
                _b.label = 4;
              case 4:
                return [3, 9];
              case 5:
                err_1 = _b.sent();
                if (!(err_1.name === "ResourceNotFoundException"))
                  return [3, 7];
                return [4, this.createTable(valueConstructor, options)];
              case 6:
                _b.sent();
                return [3, 8];
              case 7:
                throw err_1;
              case 8:
                return [3, 9];
              case 9:
                return [2];
            }
          });
        });
      };
      DataMapper3.prototype.ensureTableNotExists = function(valueConstructor) {
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var TableName, _a, status, err_2;
          return tslib_1.__generator(this, function(_b) {
            switch (_b.label) {
              case 0:
                TableName = this.getTableName(valueConstructor.prototype);
                _b.label = 1;
              case 1:
                _b.trys.push([1, 8, , 9]);
                return [4, this.client.describeTable({ TableName }).promise()];
              case 2:
                _a = _b.sent().Table, status = (_a === void 0 ? { TableStatus: "CREATING" } : _a).TableStatus;
                if (!(status === "DELETING"))
                  return [3, 4];
                return [4, this.client.waitFor("tableNotExists", { TableName }).promise()];
              case 3:
                _b.sent();
                return [2];
              case 4:
                if (!(status === "CREATING" || status === "UPDATING"))
                  return [3, 6];
                return [4, this.client.waitFor("tableExists", { TableName }).promise()];
              case 5:
                _b.sent();
                _b.label = 6;
              case 6:
                return [4, this.deleteTable(valueConstructor)];
              case 7:
                _b.sent();
                return [3, 9];
              case 8:
                err_2 = _b.sent();
                if (err_2.name !== "ResourceNotFoundException") {
                  throw err_2;
                }
                return [3, 9];
              case 9:
                return [2];
            }
          });
        });
      };
      DataMapper3.prototype.get = function(itemOrParameters, options) {
        if (options === void 0) {
          options = {};
        }
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var item, projection, _a, readConsistency, schema, req, attributes, Item;
          return tslib_1.__generator(this, function(_b) {
            switch (_b.label) {
              case 0:
                if ("item" in itemOrParameters && itemOrParameters.item[protocols_1.DynamoDbTable]) {
                  item = itemOrParameters.item;
                  options = itemOrParameters;
                } else {
                  item = itemOrParameters;
                }
                projection = options.projection, _a = options.readConsistency, readConsistency = _a === void 0 ? this.readConsistency : _a;
                schema = protocols_1.getSchema(item);
                req = {
                  TableName: this.getTableName(item),
                  Key: dynamodb_data_marshaller_1.marshallKey(schema, item)
                };
                if (readConsistency === "strong") {
                  req.ConsistentRead = true;
                }
                if (projection) {
                  attributes = new dynamodb_expressions_1.ExpressionAttributes();
                  req.ProjectionExpression = dynamodb_expressions_1.serializeProjectionExpression(projection.map(function(propName) {
                    return dynamodb_data_marshaller_1.toSchemaName(propName, schema);
                  }), attributes);
                  if (Object.keys(attributes.names).length > 0) {
                    req.ExpressionAttributeNames = attributes.names;
                  }
                }
                return [4, this.client.getItem(req).promise()];
              case 1:
                Item = _b.sent().Item;
                if (Item) {
                  return [2, dynamodb_data_marshaller_1.unmarshallItem(schema, Item, item.constructor)];
                }
                throw new ItemNotFoundException_1.ItemNotFoundException(req);
            }
          });
        });
      };
      DataMapper3.prototype.parallelScan = function(ctorOrParams, segments, options) {
        if (options === void 0) {
          options = {};
        }
        var valueConstructor;
        if (typeof segments !== "number") {
          valueConstructor = ctorOrParams.valueConstructor;
          segments = ctorOrParams.segments;
          options = ctorOrParams;
        } else {
          valueConstructor = ctorOrParams;
        }
        return new ParallelScanIterator_1.ParallelScanIterator(this.client, valueConstructor, segments, tslib_1.__assign({ readConsistency: this.readConsistency }, options, { tableNamePrefix: this.tableNamePrefix }));
      };
      DataMapper3.prototype.put = function(itemOrParameters, options) {
        if (options === void 0) {
          options = {};
        }
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var e_9, _a, item, condition, _b, skipVersionCheck, schema, req, _c, _d, key, inputMember, fieldSchema, _e, attributeName, versionCond, attributes;
          return tslib_1.__generator(this, function(_f) {
            switch (_f.label) {
              case 0:
                if ("item" in itemOrParameters && itemOrParameters.item[protocols_1.DynamoDbTable]) {
                  item = itemOrParameters.item;
                  options = itemOrParameters;
                } else {
                  item = itemOrParameters;
                }
                condition = options.condition, _b = options.skipVersionCheck, skipVersionCheck = _b === void 0 ? this.skipVersionCheck : _b;
                schema = protocols_1.getSchema(item);
                req = {
                  TableName: this.getTableName(item),
                  Item: dynamodb_data_marshaller_1.marshallItem(schema, item)
                };
                if (!skipVersionCheck) {
                  try {
                    for (_c = tslib_1.__values(Object.keys(schema)), _d = _c.next(); !_d.done; _d = _c.next()) {
                      key = _d.value;
                      inputMember = item[key];
                      fieldSchema = schema[key];
                      _e = fieldSchema.attributeName, attributeName = _e === void 0 ? key : _e;
                      if (isVersionAttribute(fieldSchema)) {
                        versionCond = handleVersionAttribute(key, inputMember).condition;
                        if (req.Item[attributeName]) {
                          req.Item[attributeName].N = (Number(req.Item[attributeName].N) + 1).toString();
                        } else {
                          req.Item[attributeName] = { N: "0" };
                        }
                        condition = condition ? { type: "And", conditions: [condition, versionCond] } : versionCond;
                      }
                    }
                  } catch (e_9_1) {
                    e_9 = { error: e_9_1 };
                  } finally {
                    try {
                      if (_d && !_d.done && (_a = _c.return))
                        _a.call(_c);
                    } finally {
                      if (e_9)
                        throw e_9.error;
                    }
                  }
                }
                if (condition) {
                  attributes = new dynamodb_expressions_1.ExpressionAttributes();
                  req.ConditionExpression = dynamodb_data_marshaller_1.marshallConditionExpression(condition, schema, attributes).expression;
                  if (Object.keys(attributes.names).length > 0) {
                    req.ExpressionAttributeNames = attributes.names;
                  }
                  if (Object.keys(attributes.values).length > 0) {
                    req.ExpressionAttributeValues = attributes.values;
                  }
                }
                return [4, this.client.putItem(req).promise()];
              case 1:
                _f.sent();
                return [2, dynamodb_data_marshaller_1.unmarshallItem(schema, req.Item, item.constructor)];
            }
          });
        });
      };
      DataMapper3.prototype.query = function(valueConstructorOrParameters, keyCondition, options) {
        if (options === void 0) {
          options = {};
        }
        var valueConstructor;
        if (!keyCondition) {
          valueConstructor = valueConstructorOrParameters.valueConstructor;
          keyCondition = valueConstructorOrParameters.keyCondition;
          options = valueConstructorOrParameters;
        } else {
          valueConstructor = valueConstructorOrParameters;
        }
        return new QueryIterator_1.QueryIterator(this.client, valueConstructor, keyCondition, tslib_1.__assign({ readConsistency: this.readConsistency }, options, { tableNamePrefix: this.tableNamePrefix }));
      };
      DataMapper3.prototype.scan = function(ctorOrParams, options) {
        if (options === void 0) {
          options = {};
        }
        var valueConstructor;
        if ("valueConstructor" in ctorOrParams && ctorOrParams.valueConstructor.prototype && ctorOrParams.valueConstructor.prototype[protocols_1.DynamoDbTable]) {
          valueConstructor = ctorOrParams.valueConstructor;
          options = ctorOrParams;
        } else {
          valueConstructor = ctorOrParams;
        }
        return new ScanIterator_1.ScanIterator(this.client, valueConstructor, tslib_1.__assign({ readConsistency: this.readConsistency }, options, { tableNamePrefix: this.tableNamePrefix }));
      };
      DataMapper3.prototype.update = function(itemOrParameters, options) {
        if (options === void 0) {
          options = {};
        }
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var e_10, _a, item, condition, _b, onMissing, _c, skipVersionCheck, schema, expr, itemKey, _d, _e, key, inputMember, fieldSchema, _f, versionCond, value, marshalled;
          return tslib_1.__generator(this, function(_g) {
            if ("item" in itemOrParameters && itemOrParameters.item[protocols_1.DynamoDbTable]) {
              item = itemOrParameters.item;
              options = itemOrParameters;
            } else {
              item = itemOrParameters;
            }
            condition = options.condition, _b = options.onMissing, onMissing = _b === void 0 ? "remove" : _b, _c = options.skipVersionCheck, skipVersionCheck = _c === void 0 ? this.skipVersionCheck : _c;
            schema = protocols_1.getSchema(item);
            expr = new dynamodb_expressions_1.UpdateExpression();
            itemKey = {};
            try {
              for (_d = tslib_1.__values(Object.keys(schema)), _e = _d.next(); !_e.done; _e = _d.next()) {
                key = _e.value;
                inputMember = item[key];
                fieldSchema = schema[key];
                if (dynamodb_data_marshaller_1.isKey(fieldSchema)) {
                  itemKey[key] = inputMember;
                } else if (isVersionAttribute(fieldSchema)) {
                  _f = handleVersionAttribute(key, inputMember), versionCond = _f.condition, value = _f.value;
                  expr.set(key, value);
                  if (!skipVersionCheck) {
                    condition = condition ? { type: "And", conditions: [condition, versionCond] } : versionCond;
                  }
                } else if (inputMember === void 0) {
                  if (onMissing === "remove") {
                    expr.remove(key);
                  }
                } else {
                  marshalled = dynamodb_data_marshaller_1.marshallValue(fieldSchema, inputMember);
                  if (marshalled) {
                    expr.set(key, new dynamodb_expressions_1.AttributeValue(marshalled));
                  }
                }
              }
            } catch (e_10_1) {
              e_10 = { error: e_10_1 };
            } finally {
              try {
                if (_e && !_e.done && (_a = _d.return))
                  _a.call(_d);
              } finally {
                if (e_10)
                  throw e_10.error;
              }
            }
            return [2, this.doExecuteUpdateExpression(expr, itemKey, protocols_1.getSchema(item), protocols_1.getTableName(item), item.constructor, { condition })];
          });
        });
      };
      DataMapper3.prototype.executeUpdateExpression = function(expression, key, valueConstructor, options) {
        if (options === void 0) {
          options = {};
        }
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          return tslib_1.__generator(this, function(_a) {
            return [2, this.doExecuteUpdateExpression(expression, key, protocols_1.getSchema(valueConstructor.prototype), protocols_1.getTableName(valueConstructor.prototype), valueConstructor, options)];
          });
        });
      };
      DataMapper3.prototype.doExecuteUpdateExpression = function(expression, key, schema, tableName, valueConstructor, options) {
        if (options === void 0) {
          options = {};
        }
        return tslib_1.__awaiter(this, void 0, void 0, function() {
          var req, attributes, rawResponse;
          return tslib_1.__generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                req = {
                  TableName: this.tableNamePrefix + tableName,
                  ReturnValues: "ALL_NEW",
                  Key: dynamodb_data_marshaller_1.marshallKey(schema, key)
                };
                attributes = new dynamodb_expressions_1.ExpressionAttributes();
                if (options.condition) {
                  req.ConditionExpression = dynamodb_data_marshaller_1.marshallConditionExpression(options.condition, schema, attributes).expression;
                }
                req.UpdateExpression = dynamodb_data_marshaller_1.marshallUpdateExpression(expression, schema, attributes).expression;
                if (Object.keys(attributes.names).length > 0) {
                  req.ExpressionAttributeNames = attributes.names;
                }
                if (Object.keys(attributes.values).length > 0) {
                  req.ExpressionAttributeValues = attributes.values;
                }
                return [4, this.client.updateItem(req).promise()];
              case 1:
                rawResponse = _a.sent();
                if (rawResponse.Attributes) {
                  return [2, dynamodb_data_marshaller_1.unmarshallItem(schema, rawResponse.Attributes, valueConstructor)];
                }
                throw new Error("Update operation completed successfully, but the updated value was not returned");
            }
          });
        });
      };
      DataMapper3.prototype.getTableName = function(item) {
        return protocols_1.getTableName(item, this.tableNamePrefix);
      };
      DataMapper3.prototype.mapGetBatch = function(items, state, options, convertedOptions) {
        return tslib_1.__asyncGenerator(this, arguments, function mapGetBatch_1() {
          var e_11, _a, items_4, items_4_1, item, unprefixed, tableName, schema, _b, keyProperties, itemSchemata, marshalled, e_11_1;
          return tslib_1.__generator(this, function(_c) {
            switch (_c.label) {
              case 0:
                _c.trys.push([0, 7, 8, 13]);
                items_4 = tslib_1.__asyncValues(items);
                _c.label = 1;
              case 1:
                return [4, tslib_1.__await(items_4.next())];
              case 2:
                if (!(items_4_1 = _c.sent(), !items_4_1.done))
                  return [3, 6];
                item = items_4_1.value;
                unprefixed = protocols_1.getTableName(item);
                tableName = this.tableNamePrefix + unprefixed;
                schema = protocols_1.getSchema(item);
                if (unprefixed in options && !(tableName in convertedOptions)) {
                  convertedOptions[tableName] = convertBatchGetOptions(options[unprefixed], schema);
                }
                if (!(tableName in state)) {
                  state[tableName] = {
                    keyProperties: getKeyProperties(schema),
                    itemSchemata: {}
                  };
                }
                _b = state[tableName], keyProperties = _b.keyProperties, itemSchemata = _b.itemSchemata;
                marshalled = dynamodb_data_marshaller_1.marshallKey(schema, item);
                itemSchemata[itemIdentifier(marshalled, keyProperties)] = {
                  constructor: item.constructor,
                  schema
                };
                return [4, tslib_1.__await([tableName, marshalled])];
              case 3:
                return [4, _c.sent()];
              case 4:
                _c.sent();
                _c.label = 5;
              case 5:
                return [3, 1];
              case 6:
                return [3, 13];
              case 7:
                e_11_1 = _c.sent();
                e_11 = { error: e_11_1 };
                return [3, 13];
              case 8:
                _c.trys.push([8, , 11, 12]);
                if (!(items_4_1 && !items_4_1.done && (_a = items_4.return)))
                  return [3, 10];
                return [4, tslib_1.__await(_a.call(items_4))];
              case 9:
                _c.sent();
                _c.label = 10;
              case 10:
                return [3, 12];
              case 11:
                if (e_11)
                  throw e_11.error;
                return [7];
              case 12:
                return [7];
              case 13:
                return [2];
            }
          });
        });
      };
      DataMapper3.prototype.mapWriteBatch = function(items, state) {
        return tslib_1.__asyncGenerator(this, arguments, function mapWriteBatch_1() {
          var e_12, _a, items_5, items_5_1, _b, type, item, unprefixed, tableName, schema, _c, keyProperties, itemSchemata, attributes, marshalled, e_12_1;
          return tslib_1.__generator(this, function(_d) {
            switch (_d.label) {
              case 0:
                _d.trys.push([0, 7, 8, 13]);
                items_5 = tslib_1.__asyncValues(items);
                _d.label = 1;
              case 1:
                return [4, tslib_1.__await(items_5.next())];
              case 2:
                if (!(items_5_1 = _d.sent(), !items_5_1.done))
                  return [3, 6];
                _b = tslib_1.__read(items_5_1.value, 2), type = _b[0], item = _b[1];
                unprefixed = protocols_1.getTableName(item);
                tableName = this.tableNamePrefix + unprefixed;
                schema = protocols_1.getSchema(item);
                if (!(tableName in state)) {
                  state[tableName] = {
                    keyProperties: getKeyProperties(schema),
                    itemSchemata: {}
                  };
                }
                _c = state[tableName], keyProperties = _c.keyProperties, itemSchemata = _c.itemSchemata;
                attributes = type === "delete" ? dynamodb_data_marshaller_1.marshallKey(schema, item) : dynamodb_data_marshaller_1.marshallItem(schema, item);
                marshalled = type === "delete" ? { DeleteRequest: { Key: attributes } } : { PutRequest: { Item: attributes } };
                itemSchemata[itemIdentifier(attributes, keyProperties)] = {
                  constructor: item.constructor,
                  schema
                };
                return [4, tslib_1.__await([tableName, marshalled])];
              case 3:
                return [4, _d.sent()];
              case 4:
                _d.sent();
                _d.label = 5;
              case 5:
                return [3, 1];
              case 6:
                return [3, 13];
              case 7:
                e_12_1 = _d.sent();
                e_12 = { error: e_12_1 };
                return [3, 13];
              case 8:
                _d.trys.push([8, , 11, 12]);
                if (!(items_5_1 && !items_5_1.done && (_a = items_5.return)))
                  return [3, 10];
                return [4, tslib_1.__await(_a.call(items_5))];
              case 9:
                _d.sent();
                _d.label = 10;
              case 10:
                return [3, 12];
              case 11:
                if (e_12)
                  throw e_12.error;
                return [7];
              case 12:
                return [7];
              case 13:
                return [2];
            }
          });
        });
      };
      return DataMapper3;
    }();
    exports.DataMapper = DataMapper2;
    function attributeDefinitionList(attributes) {
      return Object.keys(attributes).map(function(name) {
        return {
          AttributeName: name,
          AttributeType: attributes[name]
        };
      });
    }
    function convertBatchGetOptions(options, itemSchema) {
      var out = {};
      if (options.readConsistency === "strong") {
        out.ConsistentRead = true;
      }
      if (options.projection) {
        var attributes = new dynamodb_expressions_1.ExpressionAttributes();
        out.ProjectionExpression = dynamodb_expressions_1.serializeProjectionExpression(options.projection.map(function(propName) {
          return dynamodb_data_marshaller_1.toSchemaName(propName, options.projectionSchema || itemSchema);
        }), attributes);
        out.ExpressionAttributeNames = attributes.names;
      }
      return out;
    }
    function getKeyProperties(schema) {
      var e_13, _a;
      var keys = [];
      try {
        for (var _b = tslib_1.__values(Object.keys(schema).sort()), _c = _b.next(); !_c.done; _c = _b.next()) {
          var property = _c.value;
          var fieldSchema = schema[property];
          if (dynamodb_data_marshaller_1.isKey(fieldSchema)) {
            keys.push(fieldSchema.attributeName || property);
          }
        }
      } catch (e_13_1) {
        e_13 = { error: e_13_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_13)
            throw e_13.error;
        }
      }
      return keys;
    }
    function handleVersionAttribute(attributeName, inputMember) {
      var condition;
      var value;
      if (inputMember === void 0) {
        condition = new dynamodb_expressions_1.FunctionExpression("attribute_not_exists", new dynamodb_expressions_1.AttributePath([
          { type: "AttributeName", name: attributeName }
        ]));
        value = new dynamodb_expressions_1.AttributeValue({ N: "0" });
      } else {
        condition = {
          type: "Equals",
          subject: attributeName,
          object: inputMember
        };
        value = new dynamodb_expressions_1.MathematicalExpression(new dynamodb_expressions_1.AttributePath(attributeName), "+", 1);
      }
      return { condition, value };
    }
    function indexDefinitions(keys, options, schema) {
      var e_14, _a;
      var globalIndices = [];
      var localIndices = [];
      try {
        for (var _b = tslib_1.__values(Object.keys(keys)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var IndexName = _c.value;
          var KeySchema = keyTypesToElementList(keys[IndexName]);
          var indexOptions = options[IndexName];
          if (!indexOptions) {
            throw new Error("No options provided for " + IndexName + " index");
          }
          var indexInfo = {
            IndexName,
            KeySchema,
            Projection: indexProjection(schema, indexOptions.projection)
          };
          if (indexOptions.type === "local") {
            localIndices.push(indexInfo);
          } else {
            globalIndices.push(tslib_1.__assign({}, indexInfo, { ProvisionedThroughput: {
              ReadCapacityUnits: indexOptions.readCapacityUnits,
              WriteCapacityUnits: indexOptions.writeCapacityUnits
            } }));
          }
        }
      } catch (e_14_1) {
        e_14 = { error: e_14_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_14)
            throw e_14.error;
        }
      }
      return {
        GlobalSecondaryIndexes: globalIndices.length ? globalIndices : void 0,
        LocalSecondaryIndexes: localIndices.length ? localIndices : void 0
      };
    }
    function indexProjection(schema, projection) {
      if (typeof projection === "string") {
        return {
          ProjectionType: projection === "all" ? "ALL" : "KEYS_ONLY"
        };
      }
      return {
        ProjectionType: "INCLUDE",
        NonKeyAttributes: projection.map(function(propName) {
          return dynamodb_data_marshaller_1.getSchemaName(propName, schema);
        })
      };
    }
    function isIterable(arg) {
      return Boolean(arg) && typeof arg[Symbol.iterator] === "function";
    }
    function isVersionAttribute(fieldSchema) {
      return fieldSchema.type === "Number" && Boolean(fieldSchema.versionAttribute);
    }
    function itemIdentifier(marshalled, keyProperties) {
      var e_15, _a;
      var keyAttributes = [];
      try {
        for (var keyProperties_1 = tslib_1.__values(keyProperties), keyProperties_1_1 = keyProperties_1.next(); !keyProperties_1_1.done; keyProperties_1_1 = keyProperties_1.next()) {
          var key = keyProperties_1_1.value;
          var value = marshalled[key];
          key + "=" + (value.B || value.N || value.S);
        }
      } catch (e_15_1) {
        e_15 = { error: e_15_1 };
      } finally {
        try {
          if (keyProperties_1_1 && !keyProperties_1_1.done && (_a = keyProperties_1.return))
            _a.call(keyProperties_1);
        } finally {
          if (e_15)
            throw e_15.error;
        }
      }
      return keyAttributes.join(":");
    }
    function keyTypesToElementList(keys) {
      var elementList = Object.keys(keys).map(function(name) {
        return {
          AttributeName: name,
          KeyType: keys[name]
        };
      });
      elementList.sort(function(a, b) {
        if (a.KeyType === "HASH" && b.KeyType !== "HASH") {
          return -1;
        }
        if (a.KeyType !== "HASH" && b.KeyType === "HASH") {
          return 1;
        }
        return 0;
      });
      return elementList;
    }
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/embed.js
var require_embed = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/embed.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var protocols_1 = require_protocols();
    function embed(documentConstructor, _a) {
      var _b = _a === void 0 ? {} : _a, attributeName = _b.attributeName, defaultProvider = _b.defaultProvider;
      return {
        type: "Document",
        members: documentConstructor.prototype[protocols_1.DynamoDbSchema] || {},
        attributeName,
        defaultProvider,
        valueConstructor: documentConstructor
      };
    }
    exports.embed = embed;
  }
});

// node_modules/@aws/dynamodb-data-mapper/build/index.js
var require_build6 = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper/build/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_constants(), exports);
    tslib_1.__exportStar(require_DataMapper(), exports);
    tslib_1.__exportStar(require_embed(), exports);
    tslib_1.__exportStar(require_ItemNotFoundException(), exports);
    tslib_1.__exportStar(require_ParallelScanIterator2(), exports);
    tslib_1.__exportStar(require_ParallelScanPaginator2(), exports);
    tslib_1.__exportStar(require_protocols(), exports);
    tslib_1.__exportStar(require_QueryIterator2(), exports);
    tslib_1.__exportStar(require_QueryPaginator2(), exports);
    tslib_1.__exportStar(require_ScanIterator2(), exports);
    tslib_1.__exportStar(require_ScanPaginator2(), exports);
  }
});

// node_modules/reflect-metadata/Reflect.js
var require_Reflect = __commonJS({
  "node_modules/reflect-metadata/Reflect.js"() {
    var Reflect2;
    (function(Reflect3) {
      (function(factory) {
        var root = typeof global === "object" ? global : typeof self === "object" ? self : typeof this === "object" ? this : Function("return this;")();
        var exporter = makeExporter(Reflect3);
        if (typeof root.Reflect === "undefined") {
          root.Reflect = Reflect3;
        } else {
          exporter = makeExporter(root.Reflect, exporter);
        }
        factory(exporter);
        function makeExporter(target, previous) {
          return function(key, value) {
            if (typeof target[key] !== "function") {
              Object.defineProperty(target, key, { configurable: true, writable: true, value });
            }
            if (previous)
              previous(key, value);
          };
        }
      })(function(exporter) {
        var hasOwn = Object.prototype.hasOwnProperty;
        var supportsSymbol = typeof Symbol === "function";
        var toPrimitiveSymbol = supportsSymbol && typeof Symbol.toPrimitive !== "undefined" ? Symbol.toPrimitive : "@@toPrimitive";
        var iteratorSymbol = supportsSymbol && typeof Symbol.iterator !== "undefined" ? Symbol.iterator : "@@iterator";
        var supportsCreate = typeof Object.create === "function";
        var supportsProto = { __proto__: [] } instanceof Array;
        var downLevel = !supportsCreate && !supportsProto;
        var HashMap = {
          create: supportsCreate ? function() {
            return MakeDictionary(/* @__PURE__ */ Object.create(null));
          } : supportsProto ? function() {
            return MakeDictionary({ __proto__: null });
          } : function() {
            return MakeDictionary({});
          },
          has: downLevel ? function(map, key) {
            return hasOwn.call(map, key);
          } : function(map, key) {
            return key in map;
          },
          get: downLevel ? function(map, key) {
            return hasOwn.call(map, key) ? map[key] : void 0;
          } : function(map, key) {
            return map[key];
          }
        };
        var functionPrototype = Object.getPrototypeOf(Function);
        var usePolyfill = typeof process === "object" && process.env && process.env["REFLECT_METADATA_USE_MAP_POLYFILL"] === "true";
        var _Map = !usePolyfill && typeof Map === "function" && typeof Map.prototype.entries === "function" ? Map : CreateMapPolyfill();
        var _Set = !usePolyfill && typeof Set === "function" && typeof Set.prototype.entries === "function" ? Set : CreateSetPolyfill();
        var _WeakMap = !usePolyfill && typeof WeakMap === "function" ? WeakMap : CreateWeakMapPolyfill();
        var Metadata = new _WeakMap();
        function decorate(decorators, target, propertyKey, attributes) {
          if (!IsUndefined(propertyKey)) {
            if (!IsArray(decorators))
              throw new TypeError();
            if (!IsObject(target))
              throw new TypeError();
            if (!IsObject(attributes) && !IsUndefined(attributes) && !IsNull(attributes))
              throw new TypeError();
            if (IsNull(attributes))
              attributes = void 0;
            propertyKey = ToPropertyKey(propertyKey);
            return DecorateProperty(decorators, target, propertyKey, attributes);
          } else {
            if (!IsArray(decorators))
              throw new TypeError();
            if (!IsConstructor(target))
              throw new TypeError();
            return DecorateConstructor(decorators, target);
          }
        }
        exporter("decorate", decorate);
        function metadata(metadataKey, metadataValue) {
          function decorator(target, propertyKey) {
            if (!IsObject(target))
              throw new TypeError();
            if (!IsUndefined(propertyKey) && !IsPropertyKey(propertyKey))
              throw new TypeError();
            OrdinaryDefineOwnMetadata(metadataKey, metadataValue, target, propertyKey);
          }
          return decorator;
        }
        exporter("metadata", metadata);
        function defineMetadata(metadataKey, metadataValue, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryDefineOwnMetadata(metadataKey, metadataValue, target, propertyKey);
        }
        exporter("defineMetadata", defineMetadata);
        function hasMetadata(metadataKey, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryHasMetadata(metadataKey, target, propertyKey);
        }
        exporter("hasMetadata", hasMetadata);
        function hasOwnMetadata(metadataKey, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryHasOwnMetadata(metadataKey, target, propertyKey);
        }
        exporter("hasOwnMetadata", hasOwnMetadata);
        function getMetadata(metadataKey, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryGetMetadata(metadataKey, target, propertyKey);
        }
        exporter("getMetadata", getMetadata);
        function getOwnMetadata(metadataKey, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryGetOwnMetadata(metadataKey, target, propertyKey);
        }
        exporter("getOwnMetadata", getOwnMetadata);
        function getMetadataKeys(target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryMetadataKeys(target, propertyKey);
        }
        exporter("getMetadataKeys", getMetadataKeys);
        function getOwnMetadataKeys(target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryOwnMetadataKeys(target, propertyKey);
        }
        exporter("getOwnMetadataKeys", getOwnMetadataKeys);
        function deleteMetadata(metadataKey, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          var metadataMap = GetOrCreateMetadataMap(target, propertyKey, false);
          if (IsUndefined(metadataMap))
            return false;
          if (!metadataMap.delete(metadataKey))
            return false;
          if (metadataMap.size > 0)
            return true;
          var targetMetadata = Metadata.get(target);
          targetMetadata.delete(propertyKey);
          if (targetMetadata.size > 0)
            return true;
          Metadata.delete(target);
          return true;
        }
        exporter("deleteMetadata", deleteMetadata);
        function DecorateConstructor(decorators, target) {
          for (var i = decorators.length - 1; i >= 0; --i) {
            var decorator = decorators[i];
            var decorated = decorator(target);
            if (!IsUndefined(decorated) && !IsNull(decorated)) {
              if (!IsConstructor(decorated))
                throw new TypeError();
              target = decorated;
            }
          }
          return target;
        }
        function DecorateProperty(decorators, target, propertyKey, descriptor) {
          for (var i = decorators.length - 1; i >= 0; --i) {
            var decorator = decorators[i];
            var decorated = decorator(target, propertyKey, descriptor);
            if (!IsUndefined(decorated) && !IsNull(decorated)) {
              if (!IsObject(decorated))
                throw new TypeError();
              descriptor = decorated;
            }
          }
          return descriptor;
        }
        function GetOrCreateMetadataMap(O, P, Create) {
          var targetMetadata = Metadata.get(O);
          if (IsUndefined(targetMetadata)) {
            if (!Create)
              return void 0;
            targetMetadata = new _Map();
            Metadata.set(O, targetMetadata);
          }
          var metadataMap = targetMetadata.get(P);
          if (IsUndefined(metadataMap)) {
            if (!Create)
              return void 0;
            metadataMap = new _Map();
            targetMetadata.set(P, metadataMap);
          }
          return metadataMap;
        }
        function OrdinaryHasMetadata(MetadataKey, O, P) {
          var hasOwn2 = OrdinaryHasOwnMetadata(MetadataKey, O, P);
          if (hasOwn2)
            return true;
          var parent = OrdinaryGetPrototypeOf(O);
          if (!IsNull(parent))
            return OrdinaryHasMetadata(MetadataKey, parent, P);
          return false;
        }
        function OrdinaryHasOwnMetadata(MetadataKey, O, P) {
          var metadataMap = GetOrCreateMetadataMap(O, P, false);
          if (IsUndefined(metadataMap))
            return false;
          return ToBoolean(metadataMap.has(MetadataKey));
        }
        function OrdinaryGetMetadata(MetadataKey, O, P) {
          var hasOwn2 = OrdinaryHasOwnMetadata(MetadataKey, O, P);
          if (hasOwn2)
            return OrdinaryGetOwnMetadata(MetadataKey, O, P);
          var parent = OrdinaryGetPrototypeOf(O);
          if (!IsNull(parent))
            return OrdinaryGetMetadata(MetadataKey, parent, P);
          return void 0;
        }
        function OrdinaryGetOwnMetadata(MetadataKey, O, P) {
          var metadataMap = GetOrCreateMetadataMap(O, P, false);
          if (IsUndefined(metadataMap))
            return void 0;
          return metadataMap.get(MetadataKey);
        }
        function OrdinaryDefineOwnMetadata(MetadataKey, MetadataValue, O, P) {
          var metadataMap = GetOrCreateMetadataMap(O, P, true);
          metadataMap.set(MetadataKey, MetadataValue);
        }
        function OrdinaryMetadataKeys(O, P) {
          var ownKeys = OrdinaryOwnMetadataKeys(O, P);
          var parent = OrdinaryGetPrototypeOf(O);
          if (parent === null)
            return ownKeys;
          var parentKeys = OrdinaryMetadataKeys(parent, P);
          if (parentKeys.length <= 0)
            return ownKeys;
          if (ownKeys.length <= 0)
            return parentKeys;
          var set = new _Set();
          var keys = [];
          for (var _i = 0, ownKeys_1 = ownKeys; _i < ownKeys_1.length; _i++) {
            var key = ownKeys_1[_i];
            var hasKey = set.has(key);
            if (!hasKey) {
              set.add(key);
              keys.push(key);
            }
          }
          for (var _a = 0, parentKeys_1 = parentKeys; _a < parentKeys_1.length; _a++) {
            var key = parentKeys_1[_a];
            var hasKey = set.has(key);
            if (!hasKey) {
              set.add(key);
              keys.push(key);
            }
          }
          return keys;
        }
        function OrdinaryOwnMetadataKeys(O, P) {
          var keys = [];
          var metadataMap = GetOrCreateMetadataMap(O, P, false);
          if (IsUndefined(metadataMap))
            return keys;
          var keysObj = metadataMap.keys();
          var iterator = GetIterator(keysObj);
          var k = 0;
          while (true) {
            var next = IteratorStep(iterator);
            if (!next) {
              keys.length = k;
              return keys;
            }
            var nextValue = IteratorValue(next);
            try {
              keys[k] = nextValue;
            } catch (e) {
              try {
                IteratorClose(iterator);
              } finally {
                throw e;
              }
            }
            k++;
          }
        }
        function Type(x) {
          if (x === null)
            return 1;
          switch (typeof x) {
            case "undefined":
              return 0;
            case "boolean":
              return 2;
            case "string":
              return 3;
            case "symbol":
              return 4;
            case "number":
              return 5;
            case "object":
              return x === null ? 1 : 6;
            default:
              return 6;
          }
        }
        function IsUndefined(x) {
          return x === void 0;
        }
        function IsNull(x) {
          return x === null;
        }
        function IsSymbol(x) {
          return typeof x === "symbol";
        }
        function IsObject(x) {
          return typeof x === "object" ? x !== null : typeof x === "function";
        }
        function ToPrimitive(input, PreferredType) {
          switch (Type(input)) {
            case 0:
              return input;
            case 1:
              return input;
            case 2:
              return input;
            case 3:
              return input;
            case 4:
              return input;
            case 5:
              return input;
          }
          var hint = PreferredType === 3 ? "string" : PreferredType === 5 ? "number" : "default";
          var exoticToPrim = GetMethod(input, toPrimitiveSymbol);
          if (exoticToPrim !== void 0) {
            var result = exoticToPrim.call(input, hint);
            if (IsObject(result))
              throw new TypeError();
            return result;
          }
          return OrdinaryToPrimitive(input, hint === "default" ? "number" : hint);
        }
        function OrdinaryToPrimitive(O, hint) {
          if (hint === "string") {
            var toString_1 = O.toString;
            if (IsCallable(toString_1)) {
              var result = toString_1.call(O);
              if (!IsObject(result))
                return result;
            }
            var valueOf = O.valueOf;
            if (IsCallable(valueOf)) {
              var result = valueOf.call(O);
              if (!IsObject(result))
                return result;
            }
          } else {
            var valueOf = O.valueOf;
            if (IsCallable(valueOf)) {
              var result = valueOf.call(O);
              if (!IsObject(result))
                return result;
            }
            var toString_2 = O.toString;
            if (IsCallable(toString_2)) {
              var result = toString_2.call(O);
              if (!IsObject(result))
                return result;
            }
          }
          throw new TypeError();
        }
        function ToBoolean(argument) {
          return !!argument;
        }
        function ToString(argument) {
          return "" + argument;
        }
        function ToPropertyKey(argument) {
          var key = ToPrimitive(argument, 3);
          if (IsSymbol(key))
            return key;
          return ToString(key);
        }
        function IsArray(argument) {
          return Array.isArray ? Array.isArray(argument) : argument instanceof Object ? argument instanceof Array : Object.prototype.toString.call(argument) === "[object Array]";
        }
        function IsCallable(argument) {
          return typeof argument === "function";
        }
        function IsConstructor(argument) {
          return typeof argument === "function";
        }
        function IsPropertyKey(argument) {
          switch (Type(argument)) {
            case 3:
              return true;
            case 4:
              return true;
            default:
              return false;
          }
        }
        function GetMethod(V, P) {
          var func = V[P];
          if (func === void 0 || func === null)
            return void 0;
          if (!IsCallable(func))
            throw new TypeError();
          return func;
        }
        function GetIterator(obj) {
          var method = GetMethod(obj, iteratorSymbol);
          if (!IsCallable(method))
            throw new TypeError();
          var iterator = method.call(obj);
          if (!IsObject(iterator))
            throw new TypeError();
          return iterator;
        }
        function IteratorValue(iterResult) {
          return iterResult.value;
        }
        function IteratorStep(iterator) {
          var result = iterator.next();
          return result.done ? false : result;
        }
        function IteratorClose(iterator) {
          var f = iterator["return"];
          if (f)
            f.call(iterator);
        }
        function OrdinaryGetPrototypeOf(O) {
          var proto = Object.getPrototypeOf(O);
          if (typeof O !== "function" || O === functionPrototype)
            return proto;
          if (proto !== functionPrototype)
            return proto;
          var prototype = O.prototype;
          var prototypeProto = prototype && Object.getPrototypeOf(prototype);
          if (prototypeProto == null || prototypeProto === Object.prototype)
            return proto;
          var constructor = prototypeProto.constructor;
          if (typeof constructor !== "function")
            return proto;
          if (constructor === O)
            return proto;
          return constructor;
        }
        function CreateMapPolyfill() {
          var cacheSentinel = {};
          var arraySentinel = [];
          var MapIterator = function() {
            function MapIterator2(keys, values, selector) {
              this._index = 0;
              this._keys = keys;
              this._values = values;
              this._selector = selector;
            }
            MapIterator2.prototype["@@iterator"] = function() {
              return this;
            };
            MapIterator2.prototype[iteratorSymbol] = function() {
              return this;
            };
            MapIterator2.prototype.next = function() {
              var index = this._index;
              if (index >= 0 && index < this._keys.length) {
                var result = this._selector(this._keys[index], this._values[index]);
                if (index + 1 >= this._keys.length) {
                  this._index = -1;
                  this._keys = arraySentinel;
                  this._values = arraySentinel;
                } else {
                  this._index++;
                }
                return { value: result, done: false };
              }
              return { value: void 0, done: true };
            };
            MapIterator2.prototype.throw = function(error) {
              if (this._index >= 0) {
                this._index = -1;
                this._keys = arraySentinel;
                this._values = arraySentinel;
              }
              throw error;
            };
            MapIterator2.prototype.return = function(value) {
              if (this._index >= 0) {
                this._index = -1;
                this._keys = arraySentinel;
                this._values = arraySentinel;
              }
              return { value, done: true };
            };
            return MapIterator2;
          }();
          return function() {
            function Map2() {
              this._keys = [];
              this._values = [];
              this._cacheKey = cacheSentinel;
              this._cacheIndex = -2;
            }
            Object.defineProperty(Map2.prototype, "size", {
              get: function() {
                return this._keys.length;
              },
              enumerable: true,
              configurable: true
            });
            Map2.prototype.has = function(key) {
              return this._find(key, false) >= 0;
            };
            Map2.prototype.get = function(key) {
              var index = this._find(key, false);
              return index >= 0 ? this._values[index] : void 0;
            };
            Map2.prototype.set = function(key, value) {
              var index = this._find(key, true);
              this._values[index] = value;
              return this;
            };
            Map2.prototype.delete = function(key) {
              var index = this._find(key, false);
              if (index >= 0) {
                var size = this._keys.length;
                for (var i = index + 1; i < size; i++) {
                  this._keys[i - 1] = this._keys[i];
                  this._values[i - 1] = this._values[i];
                }
                this._keys.length--;
                this._values.length--;
                if (key === this._cacheKey) {
                  this._cacheKey = cacheSentinel;
                  this._cacheIndex = -2;
                }
                return true;
              }
              return false;
            };
            Map2.prototype.clear = function() {
              this._keys.length = 0;
              this._values.length = 0;
              this._cacheKey = cacheSentinel;
              this._cacheIndex = -2;
            };
            Map2.prototype.keys = function() {
              return new MapIterator(this._keys, this._values, getKey);
            };
            Map2.prototype.values = function() {
              return new MapIterator(this._keys, this._values, getValue);
            };
            Map2.prototype.entries = function() {
              return new MapIterator(this._keys, this._values, getEntry);
            };
            Map2.prototype["@@iterator"] = function() {
              return this.entries();
            };
            Map2.prototype[iteratorSymbol] = function() {
              return this.entries();
            };
            Map2.prototype._find = function(key, insert) {
              if (this._cacheKey !== key) {
                this._cacheIndex = this._keys.indexOf(this._cacheKey = key);
              }
              if (this._cacheIndex < 0 && insert) {
                this._cacheIndex = this._keys.length;
                this._keys.push(key);
                this._values.push(void 0);
              }
              return this._cacheIndex;
            };
            return Map2;
          }();
          function getKey(key, _) {
            return key;
          }
          function getValue(_, value) {
            return value;
          }
          function getEntry(key, value) {
            return [key, value];
          }
        }
        function CreateSetPolyfill() {
          return function() {
            function Set2() {
              this._map = new _Map();
            }
            Object.defineProperty(Set2.prototype, "size", {
              get: function() {
                return this._map.size;
              },
              enumerable: true,
              configurable: true
            });
            Set2.prototype.has = function(value) {
              return this._map.has(value);
            };
            Set2.prototype.add = function(value) {
              return this._map.set(value, value), this;
            };
            Set2.prototype.delete = function(value) {
              return this._map.delete(value);
            };
            Set2.prototype.clear = function() {
              this._map.clear();
            };
            Set2.prototype.keys = function() {
              return this._map.keys();
            };
            Set2.prototype.values = function() {
              return this._map.values();
            };
            Set2.prototype.entries = function() {
              return this._map.entries();
            };
            Set2.prototype["@@iterator"] = function() {
              return this.keys();
            };
            Set2.prototype[iteratorSymbol] = function() {
              return this.keys();
            };
            return Set2;
          }();
        }
        function CreateWeakMapPolyfill() {
          var UUID_SIZE = 16;
          var keys = HashMap.create();
          var rootKey = CreateUniqueKey();
          return function() {
            function WeakMap2() {
              this._key = CreateUniqueKey();
            }
            WeakMap2.prototype.has = function(target) {
              var table4 = GetOrCreateWeakMapTable(target, false);
              return table4 !== void 0 ? HashMap.has(table4, this._key) : false;
            };
            WeakMap2.prototype.get = function(target) {
              var table4 = GetOrCreateWeakMapTable(target, false);
              return table4 !== void 0 ? HashMap.get(table4, this._key) : void 0;
            };
            WeakMap2.prototype.set = function(target, value) {
              var table4 = GetOrCreateWeakMapTable(target, true);
              table4[this._key] = value;
              return this;
            };
            WeakMap2.prototype.delete = function(target) {
              var table4 = GetOrCreateWeakMapTable(target, false);
              return table4 !== void 0 ? delete table4[this._key] : false;
            };
            WeakMap2.prototype.clear = function() {
              this._key = CreateUniqueKey();
            };
            return WeakMap2;
          }();
          function CreateUniqueKey() {
            var key;
            do
              key = "@@WeakMap@@" + CreateUUID();
            while (HashMap.has(keys, key));
            keys[key] = true;
            return key;
          }
          function GetOrCreateWeakMapTable(target, create) {
            if (!hasOwn.call(target, rootKey)) {
              if (!create)
                return void 0;
              Object.defineProperty(target, rootKey, { value: HashMap.create() });
            }
            return target[rootKey];
          }
          function FillRandomBytes(buffer, size) {
            for (var i = 0; i < size; ++i)
              buffer[i] = Math.random() * 255 | 0;
            return buffer;
          }
          function GenRandomBytes(size) {
            if (typeof Uint8Array === "function") {
              if (typeof crypto !== "undefined")
                return crypto.getRandomValues(new Uint8Array(size));
              if (typeof msCrypto !== "undefined")
                return msCrypto.getRandomValues(new Uint8Array(size));
              return FillRandomBytes(new Uint8Array(size), size);
            }
            return FillRandomBytes(new Array(size), size);
          }
          function CreateUUID() {
            var data = GenRandomBytes(UUID_SIZE);
            data[6] = data[6] & 79 | 64;
            data[8] = data[8] & 191 | 128;
            var result = "";
            for (var offset = 0; offset < UUID_SIZE; ++offset) {
              var byte = data[offset];
              if (offset === 4 || offset === 6 || offset === 8)
                result += "-";
              if (byte < 16)
                result += "0";
              result += byte.toString(16).toLowerCase();
            }
            return result;
          }
        }
        function MakeDictionary(obj) {
          obj.__ = void 0;
          delete obj.__;
          return obj;
        }
      });
    })(Reflect2 || (Reflect2 = {}));
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/build/constants.js
var require_constants2 = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/build/constants.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.METADATA_TYPE_KEY = "design:type";
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/build/attribute.js
var require_attribute = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/build/attribute.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    require_Reflect();
    var constants_1 = require_constants2();
    var dynamodb_auto_marshaller_1 = require_build();
    var dynamodb_data_mapper_1 = require_build6();
    function attribute3(parameters) {
      if (parameters === void 0) {
        parameters = {};
      }
      return function(target, propertyKey) {
        if (!Object.prototype.hasOwnProperty.call(target, dynamodb_data_mapper_1.DynamoDbSchema)) {
          Object.defineProperty(target, dynamodb_data_mapper_1.DynamoDbSchema, { value: deriveBaseSchema(target) });
        }
        var schemaType = metadataToSchemaType(Reflect.getMetadata(constants_1.METADATA_TYPE_KEY, target, propertyKey), parameters);
        if ((schemaType.keyType || schemaType.indexKeyConfigurations) && [
          "Binary",
          "Custom",
          "Date",
          "Number",
          "String"
        ].indexOf(schemaType.type) < 0) {
          throw new Error("Properties of type " + schemaType.type + " may not be used as index or table keys. If you are relying on automatic type detection and have encountered this error, please ensure that the 'emitDecoratorMetadata' TypeScript compiler option is enabled. Please see https://www.typescriptlang.org/docs/handbook/decorators.html#metadata for more information on this compiler option.");
        }
        target[dynamodb_data_mapper_1.DynamoDbSchema][propertyKey] = schemaType;
      };
    }
    exports.attribute = attribute3;
    function deriveBaseSchema(target) {
      if (target && typeof target === "object") {
        var prototype = Object.getPrototypeOf(target);
        if (prototype) {
          return tslib_1.__assign({}, deriveBaseSchema(prototype), Object.prototype.hasOwnProperty.call(prototype, dynamodb_data_mapper_1.DynamoDbSchema) ? prototype[dynamodb_data_mapper_1.DynamoDbSchema] : {});
        }
      }
      return {};
    }
    function metadataToSchemaType(ctor, declaration) {
      var type = declaration.type, rest = tslib_1.__rest(declaration, ["type"]);
      if (type === void 0) {
        if (ctor) {
          if (ctor === String) {
            type = "String";
          } else if (ctor === Number) {
            type = "Number";
          } else if (ctor === Boolean) {
            type = "Boolean";
          } else if (ctor === Date || ctor.prototype instanceof Date) {
            type = "Date";
          } else if (ctor === dynamodb_auto_marshaller_1.BinarySet || ctor.prototype instanceof dynamodb_auto_marshaller_1.BinarySet) {
            type = "Set";
            rest.memberType = "Binary";
          } else if (ctor === dynamodb_auto_marshaller_1.NumberValueSet || ctor.prototype instanceof dynamodb_auto_marshaller_1.NumberValueSet) {
            type = "Set";
            rest.memberType = "Number";
          } else if (ctor === Set || ctor.prototype instanceof Set) {
            type = "Set";
            if (!("memberType" in rest)) {
              throw new Error("Invalid set declaration. You must specify a memberType");
            }
          } else if (ctor === Map || ctor.prototype instanceof Map) {
            type = "Map";
            if (!("memberType" in rest)) {
              throw new Error("Invalid map declaration. You must specify a memberType");
            }
          } else if (ctor.prototype[dynamodb_data_mapper_1.DynamoDbSchema]) {
            type = "Document";
            rest.members = ctor.prototype[dynamodb_data_mapper_1.DynamoDbSchema];
            rest.valueConstructor = ctor;
          } else if (isBinaryType(ctor)) {
            type = "Binary";
          } else if (ctor === Array || ctor.prototype instanceof Array) {
            if ("members" in declaration) {
              type = "Tuple";
            } else if ("memberType" in declaration) {
              type = "List";
            } else {
              type = "Collection";
            }
          } else {
            type = "Any";
          }
        } else {
          type = "Any";
        }
      }
      return tslib_1.__assign({}, rest, { type });
    }
    function isBinaryType(arg) {
      return arg === Uint8Array || arg.prototype instanceof Uint8Array || arg === Uint8ClampedArray || arg.prototype instanceof Uint8ClampedArray || arg === Uint16Array || arg.prototype instanceof Uint16Array || arg === Uint32Array || arg.prototype instanceof Uint32Array || arg === Int8Array || arg.prototype instanceof Int8Array || arg === Int16Array || arg.prototype instanceof Int16Array || arg === Int32Array || arg.prototype instanceof Int32Array || arg === Float32Array || arg.prototype instanceof Float32Array || arg === Float64Array || arg.prototype instanceof Float64Array || arg === ArrayBuffer || arg.prototype instanceof ArrayBuffer || arg === DataView || arg.prototype instanceof DataView;
    }
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/build/hashKey.js
var require_hashKey = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/build/hashKey.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var attribute_1 = require_attribute();
    function hashKey4(parameters) {
      if (parameters === void 0) {
        parameters = {};
      }
      return attribute_1.attribute(tslib_1.__assign({}, parameters, { keyType: "HASH" }));
    }
    exports.hashKey = hashKey4;
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/node_modules/uuid/lib/rng.js
var require_rng = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/node_modules/uuid/lib/rng.js"(exports, module2) {
    var crypto2 = require("crypto");
    module2.exports = function nodeRNG() {
      return crypto2.randomBytes(16);
    };
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/node_modules/uuid/lib/bytesToUuid.js
var require_bytesToUuid = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/node_modules/uuid/lib/bytesToUuid.js"(exports, module2) {
    var byteToHex = [];
    for (i = 0; i < 256; ++i) {
      byteToHex[i] = (i + 256).toString(16).substr(1);
    }
    var i;
    function bytesToUuid(buf, offset) {
      var i2 = offset || 0;
      var bth = byteToHex;
      return [
        bth[buf[i2++]],
        bth[buf[i2++]],
        bth[buf[i2++]],
        bth[buf[i2++]],
        "-",
        bth[buf[i2++]],
        bth[buf[i2++]],
        "-",
        bth[buf[i2++]],
        bth[buf[i2++]],
        "-",
        bth[buf[i2++]],
        bth[buf[i2++]],
        "-",
        bth[buf[i2++]],
        bth[buf[i2++]],
        bth[buf[i2++]],
        bth[buf[i2++]],
        bth[buf[i2++]],
        bth[buf[i2++]]
      ].join("");
    }
    module2.exports = bytesToUuid;
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/node_modules/uuid/v1.js
var require_v1 = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/node_modules/uuid/v1.js"(exports, module2) {
    var rng = require_rng();
    var bytesToUuid = require_bytesToUuid();
    var _nodeId;
    var _clockseq;
    var _lastMSecs = 0;
    var _lastNSecs = 0;
    function v1(options, buf, offset) {
      var i = buf && offset || 0;
      var b = buf || [];
      options = options || {};
      var node = options.node || _nodeId;
      var clockseq = options.clockseq !== void 0 ? options.clockseq : _clockseq;
      if (node == null || clockseq == null) {
        var seedBytes = rng();
        if (node == null) {
          node = _nodeId = [
            seedBytes[0] | 1,
            seedBytes[1],
            seedBytes[2],
            seedBytes[3],
            seedBytes[4],
            seedBytes[5]
          ];
        }
        if (clockseq == null) {
          clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 16383;
        }
      }
      var msecs = options.msecs !== void 0 ? options.msecs : new Date().getTime();
      var nsecs = options.nsecs !== void 0 ? options.nsecs : _lastNSecs + 1;
      var dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 1e4;
      if (dt < 0 && options.clockseq === void 0) {
        clockseq = clockseq + 1 & 16383;
      }
      if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === void 0) {
        nsecs = 0;
      }
      if (nsecs >= 1e4) {
        throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
      }
      _lastMSecs = msecs;
      _lastNSecs = nsecs;
      _clockseq = clockseq;
      msecs += 122192928e5;
      var tl = ((msecs & 268435455) * 1e4 + nsecs) % 4294967296;
      b[i++] = tl >>> 24 & 255;
      b[i++] = tl >>> 16 & 255;
      b[i++] = tl >>> 8 & 255;
      b[i++] = tl & 255;
      var tmh = msecs / 4294967296 * 1e4 & 268435455;
      b[i++] = tmh >>> 8 & 255;
      b[i++] = tmh & 255;
      b[i++] = tmh >>> 24 & 15 | 16;
      b[i++] = tmh >>> 16 & 255;
      b[i++] = clockseq >>> 8 | 128;
      b[i++] = clockseq & 255;
      for (var n = 0; n < 6; ++n) {
        b[i + n] = node[n];
      }
      return buf ? buf : bytesToUuid(b);
    }
    module2.exports = v1;
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/node_modules/uuid/v4.js
var require_v4 = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/node_modules/uuid/v4.js"(exports, module2) {
    var rng = require_rng();
    var bytesToUuid = require_bytesToUuid();
    function v4(options, buf, offset) {
      var i = buf && offset || 0;
      if (typeof options == "string") {
        buf = options === "binary" ? new Array(16) : null;
        options = null;
      }
      options = options || {};
      var rnds = options.random || (options.rng || rng)();
      rnds[6] = rnds[6] & 15 | 64;
      rnds[8] = rnds[8] & 63 | 128;
      if (buf) {
        for (var ii = 0; ii < 16; ++ii) {
          buf[i + ii] = rnds[ii];
        }
      }
      return buf || bytesToUuid(rnds);
    }
    module2.exports = v4;
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/node_modules/uuid/index.js
var require_uuid = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/node_modules/uuid/index.js"(exports, module2) {
    var v1 = require_v1();
    var v4 = require_v4();
    var uuid = v4;
    uuid.v1 = v1;
    uuid.v4 = v4;
    module2.exports = uuid;
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/build/autoGeneratedHashKey.js
var require_autoGeneratedHashKey = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/build/autoGeneratedHashKey.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var hashKey_1 = require_hashKey();
    var uuid_1 = require_uuid();
    function autoGeneratedHashKey(parameters) {
      if (parameters === void 0) {
        parameters = {};
      }
      return hashKey_1.hashKey(tslib_1.__assign({}, parameters, { type: "String", defaultProvider: uuid_1.v4 }));
    }
    exports.autoGeneratedHashKey = autoGeneratedHashKey;
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/build/rangeKey.js
var require_rangeKey = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/build/rangeKey.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var attribute_1 = require_attribute();
    function rangeKey3(parameters) {
      if (parameters === void 0) {
        parameters = {};
      }
      return attribute_1.attribute(tslib_1.__assign({}, parameters, { keyType: "RANGE" }));
    }
    exports.rangeKey = rangeKey3;
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/build/table.js
var require_table = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/build/table.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var dynamodb_data_mapper_1 = require_build6();
    function table4(tableName) {
      return function(constructor) {
        constructor.prototype[dynamodb_data_mapper_1.DynamoDbTable] = tableName;
      };
    }
    exports.table = table4;
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/build/versionAttribute.js
var require_versionAttribute = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/build/versionAttribute.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    var attribute_1 = require_attribute();
    function versionAttribute(parameters) {
      if (parameters === void 0) {
        parameters = {};
      }
      return attribute_1.attribute(tslib_1.__assign({}, parameters, { type: "Number", versionAttribute: true }));
    }
    exports.versionAttribute = versionAttribute;
  }
});

// node_modules/@aws/dynamodb-data-mapper-annotations/build/index.js
var require_build7 = __commonJS({
  "node_modules/@aws/dynamodb-data-mapper-annotations/build/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_attribute(), exports);
    tslib_1.__exportStar(require_autoGeneratedHashKey(), exports);
    tslib_1.__exportStar(require_hashKey(), exports);
    tslib_1.__exportStar(require_rangeKey(), exports);
    tslib_1.__exportStar(require_table(), exports);
    tslib_1.__exportStar(require_versionAttribute(), exports);
  }
});

// src/functions/specialty/handler.ts
var handler_exports = {};
__export(handler_exports, {
  getBySpecialtyHandler: () => getBySpecialtyHandler,
  getProviderHandler: () => getProviderHandler,
  getSpecialtiesHandler: () => getSpecialtiesHandler
});

// src/libs/apiGateway.ts
var successResponse = (response) => {
  return {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true
    },
    statusCode: 200,
    body: JSON.stringify(response)
  };
};
var failedResponse = (response) => {
  return {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true
    },
    statusCode: 500,
    body: JSON.stringify(response)
  };
};

// src/libs/lambda.ts
var import_core = __toESM(require_core());
var import_http_json_body_parser = __toESM(require_http_json_body_parser());
var middyfy = (handler) => {
  return (0, import_core.default)(handler).use((0, import_http_json_body_parser.default)());
};

// src/libs/utils.ts
var import_aws_sdk = require("aws-sdk");
var import_dynamodb_data_mapper = __toESM(require_build6());
var getDataMapper = () => {
  import_aws_sdk.config.update({ region: process.env.AWS_PROVIDER_REGION });
  const client = new import_aws_sdk.DynamoDB(import_aws_sdk.config);
  return new import_dynamodb_data_mapper.DataMapper({ client });
};

// src/models/ProviderAvailability.ts
var import_dynamodb_data_mapper_annotations = __toESM(require_build7());
var ProviderAvailability = class {
};
__decorateClass([
  (0, import_dynamodb_data_mapper_annotations.hashKey)({
    type: "String"
  })
], ProviderAvailability.prototype, "specialty", 2);
__decorateClass([
  (0, import_dynamodb_data_mapper_annotations.rangeKey)({
    type: "String"
  })
], ProviderAvailability.prototype, "provider", 2);
__decorateClass([
  (0, import_dynamodb_data_mapper_annotations.attribute)()
], ProviderAvailability.prototype, "availability", 2);
ProviderAvailability = __decorateClass([
  (0, import_dynamodb_data_mapper_annotations.table)(process.env.DYNAMO_PROVIDER_AVAILABILITY)
], ProviderAvailability);
var ProviderAvailability_default = ProviderAvailability;

// src/models/SpecialtyData.ts
var import_dynamodb_data_mapper_annotations2 = __toESM(require_build7());
var SpecialtyData = class {
};
__decorateClass([
  (0, import_dynamodb_data_mapper_annotations2.hashKey)({
    type: "String"
  })
], SpecialtyData.prototype, "specialty", 2);
SpecialtyData = __decorateClass([
  (0, import_dynamodb_data_mapper_annotations2.table)(process.env.DYNAMO_SPECIALTY_DATA)
], SpecialtyData);
var SpecialtyData_default = SpecialtyData;

// src/models/SpecialtyProviders.ts
var import_dynamodb_data_mapper_annotations3 = __toESM(require_build7());
var SpecialtyProviders = class {
};
__decorateClass([
  (0, import_dynamodb_data_mapper_annotations3.hashKey)({
    type: "String"
  })
], SpecialtyProviders.prototype, "specialty", 2);
__decorateClass([
  (0, import_dynamodb_data_mapper_annotations3.rangeKey)({
    type: "String"
  })
], SpecialtyProviders.prototype, "provider", 2);
__decorateClass([
  (0, import_dynamodb_data_mapper_annotations3.attribute)()
], SpecialtyProviders.prototype, "address", 2);
SpecialtyProviders = __decorateClass([
  (0, import_dynamodb_data_mapper_annotations3.table)(process.env.DYNAMO_SPECIALTY_PROVIDERS)
], SpecialtyProviders);
var SpecialtyProviders_default = SpecialtyProviders;

// src/functions/specialty/handler.ts
var getSpecialties = async () => {
  try {
    const mapper = getDataMapper();
    const specialties = [];
    for await (const specialty of mapper.scan(SpecialtyData_default)) {
      specialties.push(specialty);
    }
    return successResponse({
      result: specialties
    });
  } catch (error) {
    console.error(error.message);
    return failedResponse({
      result: null,
      error: { message: "Unable to get specialties" }
    });
  }
};
var getBySpecialty = async (event) => {
  try {
    const mapper = getDataMapper();
    const { specialty } = event.queryStringParameters;
    const providers = [];
    const iter = mapper.query(SpecialtyProviders_default, { specialty });
    for await (const provider of iter) {
      providers.push(provider);
    }
    return successResponse({
      result: providers
    });
  } catch (error) {
    console.error(error.message);
    return failedResponse({
      error: { message: "Unable to query providers" }
    });
  }
};
var getProvider = async (event) => {
  try {
    const mapper = getDataMapper();
    const itemToGet = Object.assign(new ProviderAvailability_default(), {
      specialty: "Dentist",
      provider: "Dr. Ervin Howell"
    });
    const item = await mapper.get(Object.assign(new ProviderAvailability_default(), itemToGet));
    return successResponse({
      result: item
    });
  } catch (error) {
    console.error(error.message);
    return failedResponse({
      error: { message: "Unable to query providers" }
    });
  }
};
var getProviderHandler = middyfy(getProvider);
var getSpecialtiesHandler = middyfy(getSpecialties);
var getBySpecialtyHandler = middyfy(getBySpecialty);
module.exports = __toCommonJS(handler_exports);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getBySpecialtyHandler,
  getProviderHandler,
  getSpecialtiesHandler
});
/*! *****************************************************************************
Copyright (C) Microsoft. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
//# sourceMappingURL=handler.js.map
